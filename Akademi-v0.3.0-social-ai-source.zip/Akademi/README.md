# Akademi Android v0.3.0

Akademi is a personal postgraduate opportunity-intelligence app for scholarships, funded research positions, professors, research directions, country/stay planning, application tracking, success stories and optional Gemini guidance.

## v0.3.0 highlights
- Works across academic disciplines; research directions and professor searches adapt to the saved profile.
- Editable CGPA and scale, degree, field, nationality, target level, research interests and experience.
- User-selected profile photo and banner image using Android's document picker.
- LinkedIn-style profile hero with a travel-app visual direction based on the supplied Akademi logo.
- Animated navigation and expandable opportunity, professor, research-direction, story and country cards.
- Akademi Pulse home feed built from the live opportunity feed, including source images when available and an in-app YouTube video radar.
- In-app browser supports popups/new windows and HTML5/YouTube full-screen video.
- Multiple lively accent palettes, system/light/dark themes, notifications and live-feed preferences.
- Optional Gemini Intelligence with an encrypted local API key and local analysis cache.
- Collector can optionally enrich public opportunity metadata with Gemini via the `GEMINI_API_KEY` GitHub secret.

The core app remains usable without Gemini or Firebase.
