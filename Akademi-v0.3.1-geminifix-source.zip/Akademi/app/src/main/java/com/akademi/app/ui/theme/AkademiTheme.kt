package com.akademi.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.akademi.app.settings.AccentPreset
import com.akademi.app.settings.SettingsState
import com.akademi.app.settings.ThemeMode

val Navy = Color(0xFF071B4B)
val ElectricBlue = Color(0xFF1C8DFF)
val Cyan = Color(0xFF14C7E8)
val Violet = Color(0xFF7B3FF2)
val Magenta = Color(0xFFE61E93)
val Coral = Color(0xFFFF5B70)
val Orange = Color(0xFFFF9418)
val Mint = Color(0xFF14B8A6)
val Gold = Color(0xFFF2B633)
val Teal = Color(0xFF0C9BA8)
val Aqua = Color(0xFF77DDE7)
val Mist = Color(0xFFF7F8FC)

fun accentColor(preset: AccentPreset) = when (preset) {
    AccentPreset.AURORA -> Color(0xFF3567F1)
    AccentPreset.OCEAN -> Color(0xFF0789C8)
    AccentPreset.VIOLET -> Color(0xFF7547E8)
    AccentPreset.CORAL -> Color(0xFFFF5B70)
    AccentPreset.SUNSET -> Color(0xFFF47435)
    AccentPreset.MINT -> Color(0xFF10A990)
    AccentPreset.MIDNIGHT -> Navy
}

fun accentGradient(preset: AccentPreset): List<Color> = when (preset) {
    AccentPreset.AURORA -> listOf(ElectricBlue, Color(0xFF4F46E5), Violet, Magenta, Orange)
    AccentPreset.OCEAN -> listOf(Color(0xFF18C8EC), Color(0xFF1688F8), Color(0xFF4258E8))
    AccentPreset.VIOLET -> listOf(Color(0xFF5A67F2), Violet, Magenta)
    AccentPreset.CORAL -> listOf(Color(0xFFFF7C68), Coral, Color(0xFFE9368F))
    AccentPreset.SUNSET -> listOf(Color(0xFFFFB52E), Orange, Color(0xFFFF4F6D), Magenta)
    AccentPreset.MINT -> listOf(Color(0xFF4BE0C4), Mint, Color(0xFF149ED1))
    AccentPreset.MIDNIGHT -> listOf(Navy, Color(0xFF173B78), Color(0xFF335BD7))
}

@Composable
fun AkademiTheme(settings: SettingsState, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val primary = accentColor(settings.accent)
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !dark
        }
    }
    val scheme = if (dark) {
        darkColorScheme(
            primary = if (primary == Navy) Color(0xFF7AA7FF) else primary,
            secondary = Cyan,
            tertiary = Gold,
            background = Color(0xFF070B16),
            surface = Color(0xFF10182A),
            surfaceVariant = Color(0xFF17233A),
            onPrimary = Color.White,
            onBackground = Color(0xFFF5F7FB),
            onSurface = Color(0xFFF5F7FB)
        )
    } else {
        lightColorScheme(
            primary = primary,
            secondary = Navy,
            tertiary = Gold,
            background = Mist,
            surface = Color.White,
            surfaceVariant = Color(0xFFF0F3FA),
            onPrimary = Color.White,
            onBackground = Color(0xFF111A2E),
            onSurface = Color(0xFF111A2E)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
