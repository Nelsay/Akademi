package com.akademi.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Message
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.akademi.app.data.*
import com.akademi.app.ai.AiInsightCache
import com.akademi.app.ai.GeminiClient
import com.akademi.app.ai.SecureGeminiKeyStore
import com.akademi.app.settings.*
import com.akademi.app.notifications.AkademiNotificationManager
import com.akademi.app.push.OptionalFcmPush
import com.akademi.app.ui.AkademiMark
import com.akademi.app.ui.AkademiWordmark
import com.akademi.app.ui.SmartImage
import com.akademi.app.ui.theme.AkademiTheme
import com.akademi.app.ui.theme.Gold
import com.akademi.app.ui.theme.Teal
import com.akademi.app.ui.theme.accentGradient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Screen { HOME, DISCOVER, RESEARCH, TRACKER, PROFILE, SETTINGS, COUNTRIES, STORIES, DETAIL, WEB }

@Composable
fun AkademiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { AppPreferences(context) }
    var settings by remember { mutableStateOf(prefs.loadSettings()) }
    var profile by remember { mutableStateOf(prefs.loadProfile()) }
    var tracker by remember { mutableStateOf(prefs.loadTracker()) }
    var opportunities by remember { mutableStateOf(SeedData.opportunities) }
    var selected by remember { mutableStateOf<Opportunity?>(null) }
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var lastMain by rememberSaveable { mutableStateOf(Screen.HOME) }
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var remoteMessage by remember { mutableStateOf<String?>(null) }
    var webUrl by rememberSaveable { mutableStateOf("") }
    var returnScreen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val scope = rememberCoroutineScope()
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun go(next: Screen) {
        if (next in listOf(Screen.HOME, Screen.DISCOVER, Screen.RESEARCH, Screen.TRACKER, Screen.PROFILE)) lastMain = next
        screen = next
    }
    fun openInside(url: String) {
        returnScreen = screen
        webUrl = url
        screen = Screen.WEB
    }
    fun openOutside(url: String) { openUrl(context, url) }
    fun openLink(url: String) { if (settings.openLinksExternally) openOutside(url) else openInside(url) }
    fun loadRemote(feedOverride: String? = null) {
        val feedUrl = feedOverride?.trim().orEmpty().ifBlank { settings.liveFeedUrl }
        if (feedUrl.isBlank()) {
            remoteMessage = "Add a normalized HTTPS feed URL in Settings to enable live opportunity updates."
            return
        }
        scope.launch {
            remoteMessage = "Refreshing live feed…"
            val result = RemoteOpportunityRepository.fetch(feedUrl)
            result.onSuccess { remote ->
                opportunities = (remote + SeedData.opportunities).distinctBy { it.id }
                remoteMessage = "Loaded ${remote.size} live opportunities."
            }.onFailure { remoteMessage = "Feed refresh failed: ${it.message ?: "unknown error"}" }
        }
    }

    LaunchedEffect(Unit) {
        delay(850)
        showSplash = false
        if (settings.refreshOnLaunch && settings.liveFeedUrl.isNotBlank()) loadRemote()
    }

    LaunchedEffect(settings.notifications, settings.liveFeedUrl) {
        if (settings.notifications) OptionalFcmPush.initialize(context)
        AkademiNotificationManager.schedule(context, settings.notifications && settings.liveFeedUrl.isNotBlank())
        if (settings.notifications && Build.VERSION.SDK_INT >= 33 && !AkademiNotificationManager.canNotify(context)) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    BackHandler(enabled = !showSplash && screen != Screen.HOME && screen != Screen.WEB) {
        screen = when (screen) {
            Screen.DETAIL, Screen.COUNTRIES, Screen.STORIES -> lastMain
            Screen.SETTINGS -> Screen.PROFILE
            Screen.DISCOVER, Screen.RESEARCH, Screen.TRACKER, Screen.PROFILE -> Screen.HOME
            else -> screen
        }
    }

    AkademiTheme(settings) {
        if (showSplash) {
            SplashScreen()
        } else {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (screen) {
                    Screen.DETAIL -> OpportunityDetailScreen(
                        scored = selected?.let { MatchEngine.score(profile, it) },
                        tracked = selected?.let { o -> tracker.any { it.opportunityId == o.id } } == true,
                        profile = profile,
                        settings = settings,
                        onBack = { screen = lastMain },
                        onOpenInside = { selected?.sourceUrl?.let { openInside(it) } },
                        onOpenExternal = { selected?.sourceUrl?.let { openOutside(it) } },
                        onApplyInside = { selected?.let { openInside(it.applicationUrl.ifBlank { it.sourceUrl }) } },
                        onTrack = {
                            selected?.let { o ->
                                if (tracker.none { it.opportunityId == o.id }) {
                                    tracker = tracker + TrackerItem(o.id)
                                    prefs.saveTracker(tracker)
                                }
                            }
                        }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        settings = settings,
                        onSettings = { settings = it; prefs.saveSettings(it) },
                        remoteMessage = remoteMessage,
                        onRefresh = { url -> loadRemote(url) },
                        onBack = { screen = Screen.PROFILE },
                        onReset = {
                            prefs.reset()
                            settings = SettingsState()
                            profile = UserProfile()
                            tracker = emptyList()
                            opportunities = SeedData.opportunities
                            remoteMessage = "Local Akademi data reset."
                        }
                    )
                    Screen.COUNTRIES -> CountryInsightsScreen(onBack = { screen = lastMain }, onOpen = { openInside(it) }, onOpenExternal = { openOutside(it) })
                    Screen.STORIES -> SuccessStoriesScreen(onBack = { screen = lastMain }, onOpen = { openInside(it) }, onOpenExternal = { openOutside(it) })
                    Screen.WEB -> WebScreen(url = webUrl, popupsEnabled = settings.webPopupsEnabled, onExternal = { openOutside(webUrl) }, onBack = { screen = returnScreen })
                    else -> MainScaffold(
                        screen = screen,
                        onNavigate = ::go
                    ) { padding, targetScreen ->
                        when (targetScreen) {
                            Screen.HOME -> HomeScreen(
                                modifier = Modifier.padding(padding), profile = profile, settings = settings, opportunities = opportunities,
                                tracker = tracker, onDiscover = { go(Screen.DISCOVER) }, onResearch = { go(Screen.RESEARCH) },
                                onCountries = { screen = Screen.COUNTRIES }, onStories = { screen = Screen.STORIES },
                                onRefresh = { loadRemote() }, onOpenWeb = { openInside(it) }, onOpenExternal = { openOutside(it) },
                                onOpportunity = { selected = it; screen = Screen.DETAIL }
                            )
                            Screen.DISCOVER -> DiscoverScreen(
                                modifier = Modifier.padding(padding), profile = profile, opportunities = opportunities,
                                remoteMessage = remoteMessage, onRefresh = { loadRemote() },
                                onOpportunity = { selected = it; screen = Screen.DETAIL }, onOpenExternal = { openOutside(it) }
                            )
                            Screen.RESEARCH -> ResearchScreen(
                                modifier = Modifier.padding(padding), profile = profile,
                                onOpen = { openInside(it) }, onOpenExternal = { openOutside(it) }, onStories = { screen = Screen.STORIES }
                            )
                            Screen.TRACKER -> TrackerScreen(
                                modifier = Modifier.padding(padding), opportunities = opportunities, tracker = tracker,
                                onTracker = { tracker = it; prefs.saveTracker(it) },
                                onOpen = { o -> selected = o; screen = Screen.DETAIL }
                            )
                            Screen.PROFILE -> ProfileScreen(
                                modifier = Modifier.padding(padding), profile = profile, settings = settings,
                                onProfile = { profile = it; prefs.saveProfile(it) },
                                onSettings = { screen = Screen.SETTINGS }, onCountries = { screen = Screen.COUNTRIES }
                            )
                            else -> Unit
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.secondary).systemBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(shape = RoundedCornerShape(30.dp), color = Color.White, shadowElevation = 8.dp) {
                Box(Modifier.padding(14.dp), contentAlignment = Alignment.Center) { AkademiMark(Modifier.size(104.dp)) }
            }
            Spacer(Modifier.height(18.dp))
            Text("Akademi", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.SemiBold)
            Text("OPPORTUNITY INTELLIGENCE", color = Color(0xFF7FD1C9), fontSize = 12.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
            Text("SCHOLARSHIPS • RESEARCH • GLOBAL IMPACT", color = Color.White.copy(alpha = .78f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun MainScaffold(screen: Screen, onNavigate: (Screen) -> Unit, content: @Composable (PaddingValues, Screen) -> Unit) {
    val tabs = listOf(
        Triple(Screen.HOME, "Home", Icons.Outlined.Home),
        Triple(Screen.DISCOVER, "Discover", Icons.Outlined.Search),
        Triple(Screen.RESEARCH, "Research", Icons.Outlined.Science),
        Triple(Screen.TRACKER, "Tracker", Icons.Outlined.Checklist),
        Triple(Screen.PROFILE, "Profile", Icons.Outlined.Person)
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 10.dp) {
                tabs.forEach { (s, label, icon) ->
                    NavigationBarItem(
                        selected = screen == s,
                        onClick = { onNavigate(s) },
                        icon = {
                            AnimatedContent(targetState = screen == s, label = "navIcon") { selected ->
                                Icon(icon, label, modifier = Modifier.size(if (selected) 25.dp else 22.dp))
                            }
                        },
                        label = { Text(label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                (fadeIn(tween(220)) + slideInHorizontally(tween(260)) { it / 12 }) togetherWith
                    (fadeOut(tween(160)) + slideOutHorizontally(tween(220)) { -it / 14 })
            },
            label = "pageTransition"
        ) { target ->
            content(padding, target)
        }
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            subtitle?.let { Text(it, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f), fontSize = 13.sp) }
        }
        trailing?.invoke()
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    profile: UserProfile,
    settings: SettingsState,
    opportunities: List<Opportunity>,
    tracker: List<TrackerItem>,
    onDiscover: () -> Unit,
    onResearch: () -> Unit,
    onCountries: () -> Unit,
    onStories: () -> Unit,
    onRefresh: () -> Unit,
    onOpenWeb: (String) -> Unit,
    onOpenExternal: (String) -> Unit,
    onOpportunity: (Opportunity) -> Unit
) {
    val scored = remember(profile, opportunities) { opportunities.map { MatchEngine.score(profile, it) }.sortedByDescending { it.score } }
    val feed = remember(profile, opportunities) { HomeFeedBuilder.build(profile, opportunities) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 30.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AkademiWordmark(compact = true, modifier = Modifier.weight(1f))
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                    Icon(Icons.Outlined.Notifications, "Notifications", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(10.dp).size(20.dp))
                }
            }
        }
        item { HomeProfileHero(profile, settings) }
        item {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                StatCard("${scored.count { it.score >= 70 }}", "Strong matches", Modifier.weight(1f))
                StatCard("${opportunities.size}", "Live radar", Modifier.weight(1f))
                StatCard("${tracker.size}", "In tracker", Modifier.weight(1f))
            }
        }
        item { SectionTitle("Explore your route") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item { TravelActionCard("Opportunities", "Funding worldwide", Icons.Outlined.FlightTakeoff, onDiscover) }
                item { TravelActionCard("Professors", "Research people", Icons.Outlined.Groups, onResearch) }
                item { TravelActionCard("Countries", "Study + stay paths", Icons.Outlined.Public, onCountries) }
                item { TravelActionCard("Stories", "How people got funded", Icons.Outlined.PlayCircle, onStories) }
            }
        }
        if (profile.preferredCountries.isNotEmpty()) {
            item { SectionTitle("Countries on your radar") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(profile.preferredCountries.toList()) { country ->
                        AssistChip(onClick = onCountries, leadingIcon = { Icon(Icons.Outlined.LocationOn, null, Modifier.size(16.dp)) }, label = { Text(country) })
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 10.dp, top = 24.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Akademi Pulse", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Fresh opportunities, advice and videos for your profile", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f))
                }
                IconButton(onClick = onRefresh) { Icon(Icons.Outlined.Refresh, "Refresh feed", tint = MaterialTheme.colorScheme.primary) }
            }
        }
        items(feed, key = { it.id }) { item ->
            HomeFeedCard(
                item = item,
                opportunity = opportunities.firstOrNull { it.id == item.opportunityId },
                onOpportunity = onOpportunity,
                onOpenWeb = onOpenWeb,
                onOpenExternal = onOpenExternal
            )
        }
        item {
            InfoBanner(
                "Your feed changes with your profile",
                "Update your degree, CGPA, interests, preferred countries or target level and Akademi re-ranks opportunities, research directions and professor searches around you."
            )
        }
    }
}

@Composable
private fun HomeProfileHero(profile: UserProfile, settings: SettingsState) {
    val baseGradient = accentGradient(settings.accent)
    val gradient = when ((profile.bannerStyle % 4)) {
        1 -> baseGradient.reversed()
        2 -> listOf(baseGradient.first(), baseGradient.last(), MaterialTheme.colorScheme.tertiary)
        3 -> listOf(baseGradient.last(), baseGradient[baseGradient.size / 2], baseGradient.first())
        else -> baseGradient
    }
    ElevatedCard(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 8.dp)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(118.dp)) {
                if (profile.bannerImagePath.isNotBlank()) {
                    SmartImage(profile.bannerImagePath, Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color.Transparent, Color.Black.copy(.28f)))))
                } else {
                    Box(Modifier.fillMaxSize().background(Brush.linearGradient(gradient)))
                    Box(Modifier.align(Alignment.TopEnd).padding(16.dp).size(if ((profile.bannerStyle % 2) == 0) 74.dp else 92.dp).clip(CircleShape).background(Color.White.copy(.14f)))
                    Box(Modifier.align(Alignment.BottomStart).offset(x = if ((profile.bannerStyle % 3) == 0) 80.dp else 150.dp, y = 28.dp).size(110.dp).clip(CircleShape).background(Color.White.copy(.10f)))
                    if ((profile.bannerStyle % 4) >= 2) {
                        Box(Modifier.align(Alignment.CenterStart).offset(x = (-18).dp).size(62.dp).clip(CircleShape).background(Color.White.copy(.09f)))
                    }
                }
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
                    color = Color.White.copy(.92f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text("GLOBAL POSTGRAD RADAR", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF13224A), modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                }
            }
            Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
                Surface(
                    modifier = Modifier.offset(y = (-38).dp).size(82.dp),
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(4.dp, MaterialTheme.colorScheme.surface),
                    shadowElevation = 8.dp
                ) {
                    if (profile.profileImagePath.isNotBlank()) {
                        SmartImage(profile.profileImagePath, Modifier.fillMaxSize().clip(CircleShape))
                    } else {
                        Box(Modifier.fillMaxSize().background(Brush.linearGradient(gradient)), contentAlignment = Alignment.Center) {
                            Text(profile.name.trim().take(1).ifBlank { "A" }.uppercase(), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Column(Modifier.padding(start = 96.dp, top = 10.dp, bottom = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(profile.name.ifBlank { "Your Akademi profile" }, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Filled.Verified, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    Text(profile.headline.ifBlank { "Postgraduate opportunity explorer" }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), maxLines = 2)
                    Spacer(Modifier.height(7.dp))
                    Text("${profile.degree.ifBlank { "Add your degree" }} • ${profile.nationality}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    val cgpaLabel = if (profile.cgpa > 0.0) "CGPA ${profile.cgpa}/${profile.cgpaScale}" else "CGPA not set"
                    Text("$cgpaLabel • Target: ${profile.targetLevel}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 3.dp))
                }
            }
        }
    }
}

@Composable
private fun TravelActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    ElevatedCard(
        modifier = Modifier.width(158.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 5.dp)
    ) {
        Column(Modifier.padding(15.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = MaterialTheme.colorScheme.primary.copy(.11f)) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(9.dp).size(22.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 3.dp))
        }
    }
}

@Composable
private fun HomeFeedCard(
    item: HomeFeedItem,
    opportunity: Opportunity?,
    onOpportunity: (Opportunity) -> Unit,
    onOpenWeb: (String) -> Unit,
    onOpenExternal: (String) -> Unit
) {
    var expanded by rememberSaveable(item.id) { mutableStateOf(false) }
    ElevatedCard(
        Modifier.padding(horizontal = 18.dp, vertical = 7.dp).fillMaxWidth().animateContentSize(spring(dampingRatio = Spring.DampingRatioMediumBouncy)).clickable { expanded = !expanded },
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 8.dp else 4.dp)
    ) {
        Column {
            if (item.imageUrl.isNotBlank()) {
                SmartImage(item.imageUrl, Modifier.fillMaxWidth().height(if (expanded) 190.dp else 142.dp), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
            } else if (item.type == "video") {
                Box(Modifier.fillMaxWidth().height(136.dp).background(Brush.linearGradient(listOf(Color(0xFF5D48F5), Color(0xFF00BCEB), Color(0xFFFF4C82)))), contentAlignment = Alignment.Center) {
                    Surface(shape = CircleShape, color = Color.White.copy(.92f), shadowElevation = 8.dp) {
                        Icon(Icons.Filled.PlayArrow, null, tint = Color(0xFF542EEA), modifier = Modifier.padding(17.dp).size(32.dp))
                    }
                }
            }
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                        Text(item.badge, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Text(item.source, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.52f))
                    Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.onSurface.copy(.5f))
                }
                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(top = 10.dp))
                Text(item.body, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), lineHeight = 18.sp, maxLines = if (expanded) 8 else 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                AnimatedVisibility(expanded) {
                    Column(Modifier.padding(top = 10.dp)) {
                        if (opportunity != null) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { onOpportunity(opportunity) }, modifier = Modifier.weight(1f)) { Text("View details") }
                                OutlinedButton(onClick = { onOpenExternal(opportunity.sourceUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                            }
                        } else if (item.url.isNotBlank()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { onOpenWeb(item.url) }, modifier = Modifier.weight(1f)) { Text(if (item.type == "video") "Watch inside" else "Open inside") }
                                OutlinedButton(onClick = { onOpenExternal(item.url) }, modifier = Modifier.weight(1f)) { Text("External") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f))
        }
    }
}

@Composable private fun QuickAction(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    ElevatedCard(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f), maxLines = 2)
        }
    }
}

@Composable private fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 10.dp))
}

@Composable
private fun DiscoverScreen(
    modifier: Modifier, profile: UserProfile, opportunities: List<Opportunity>, remoteMessage: String?, onRefresh: () -> Unit,
    onOpportunity: (Opportunity) -> Unit, onOpenExternal: (String) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var level by rememberSaveable { mutableStateOf("All") }
    var funding by rememberSaveable { mutableStateOf("All") }
    val filtered = remember(query, level, funding, opportunities, profile) {
        opportunities.filter { o ->
            (query.isBlank() || (o.title + o.provider + o.country + o.field).contains(query, true)) &&
                (level == "All" || o.level.contains(level, true)) &&
                (funding == "All" || o.funding.contains(funding, true))
        }.map { MatchEngine.score(profile, it) }.sortedByDescending { it.score }
    }
    Column(modifier.fillMaxSize()) {
        PageHeader("Discover", "Scholarships, fellowships and funded research") {
            IconButton(onClick = onRefresh) { Icon(Icons.Outlined.Refresh, "Refresh") }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            leadingIcon = { Icon(Icons.Outlined.Search, null) }, placeholder = { Text("Search your field, country, scholarship, PhD…") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)
        )
        Row(Modifier.padding(horizontal = 20.dp, vertical = 10.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Master's", "PhD").forEach { v -> FilterChip(selected = level == v, onClick = { level = v }, label = { Text(v) }) }
            listOf("All", "Fully", "Salary", "Partial").forEach { v -> FilterChip(selected = funding == v, onClick = { funding = v }, label = { Text(if (v == "All") "Any funding" else v) }) }
        }
        remoteMessage?.let { Text(it, Modifier.padding(horizontal = 20.dp, vertical = 4.dp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f)) }
        Text("${filtered.size} opportunities • sorted by your fit", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(filtered, key = { it.opportunity.id }) { s -> OpportunityCard(s, onViewDetails = { onOpportunity(s.opportunity) }, onExternal = { onOpenExternal(s.opportunity.sourceUrl) }) }
        }
    }
}

@Composable
private fun OpportunityCard(s: ScoredOpportunity, onViewDetails: () -> Unit, onExternal: () -> Unit) {
    val o = s.opportunity
    var expanded by rememberSaveable(o.id) { mutableStateOf(false) }
    ElevatedCard(
        Modifier.padding(horizontal = 18.dp, vertical = 7.dp).fillMaxWidth()
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioMediumBouncy))
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(21.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 8.dp else 4.dp)
    ) {
        Column {
            if (o.imageUrl.isNotBlank()) SmartImage(o.imageUrl, Modifier.fillMaxWidth().height(if (expanded) 176.dp else 118.dp))
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primary.copy(.09f)) {
                            Text(o.funding.uppercase(), fontSize = 9.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(o.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(o.provider, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f), modifier = Modifier.padding(top = 2.dp))
                    }
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                        Column(Modifier.size(56.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text("${s.score}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text("/100", fontSize = 8.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SmallMeta(Icons.Outlined.Place, o.country)
                    SmallMeta(Icons.Outlined.School, o.level)
                }
                Spacer(Modifier.height(5.dp))
                SmallMeta(Icons.Outlined.Event, o.deadline)
                Row(Modifier.fillMaxWidth().padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(o.status, fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(if (expanded) "Show less" else "Quick view", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                    Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, Modifier.size(19.dp), tint = MaterialTheme.colorScheme.primary)
                }
                AnimatedVisibility(expanded) {
                    Column(Modifier.padding(top = 12.dp)) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.08f))
                        Text(o.summary.ifBlank { "Akademi has basic metadata for this opportunity. Open the full Akademi detail view for extracted requirements, funding and application steps." }, fontSize = 12.sp, lineHeight = 18.sp, color = MaterialTheme.colorScheme.onSurface.copy(.72f), modifier = Modifier.padding(top = 12.dp))
                        if (s.reasons.isNotEmpty()) {
                            Text("Why it surfaced", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                            s.reasons.take(3).forEach { reason -> CheckRow(reason) }
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onViewDetails, modifier = Modifier.weight(1f)) { Text("Full details") }
                            OutlinedButton(onClick = onExternal, modifier = Modifier.weight(1f)) { Icon(Icons.Outlined.OpenInNew, null, Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("External") }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun SmallMeta(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurface.copy(.55f))
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun OpportunityDetailScreen(
    scored: ScoredOpportunity?,
    tracked: Boolean,
    profile: UserProfile,
    settings: SettingsState,
    onBack: () -> Unit,
    onOpenInside: () -> Unit,
    onOpenExternal: () -> Unit,
    onApplyInside: () -> Unit,
    onTrack: () -> Unit
) {
    if (scored == null) return
    val o = scored.opportunity
    val context = androidx.compose.ui.platform.LocalContext.current
    val keyStore = remember { SecureGeminiKeyStore(context) }
    val aiCache = remember { AiInsightCache(context) }
    val scope = rememberCoroutineScope()
    var aiInsight by remember(o.id, settings.aiModel) {
        mutableStateOf(if (settings.aiCacheEnabled) aiCache.get(o.id, settings.aiModel) else null)
    }
    var aiLoading by remember(o.id) { mutableStateOf(false) }
    var aiMessage by remember(o.id) { mutableStateOf<String?>(null) }
    var aiQuestion by rememberSaveable(o.id) { mutableStateOf("") }
    var aiAnswer by remember(o.id) { mutableStateOf<String?>(null) }
    var questionLoading by remember(o.id) { mutableStateOf(false) }
    val aiConfigured = keyStore.hasKey()

    Scaffold(
        topBar = {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }
                Text("Opportunity details", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onOpenExternal) { Icon(Icons.Outlined.OpenInNew, "Open externally") }
            }
        }
    ) { p ->
        LazyColumn(Modifier.padding(p).fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = {}, label = { Text(o.funding.uppercase(), fontSize = 10.sp) })
                    if (o.verified) AssistChip(onClick = {}, leadingIcon = { Icon(Icons.Filled.Verified, null, Modifier.size(15.dp)) }, label = { Text("SOURCE CHECKED", fontSize = 10.sp) })
                }
            }
            item { Text(o.title, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 32.sp) }
            item { Text("${o.provider} • ${o.country}", color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 5.dp)) }
            if (o.lastChecked.isNotBlank()) item { Text("Last checked: ${o.lastChecked}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.48f), modifier = Modifier.padding(top = 3.dp)) }
            item {
                ElevatedCard(Modifier.fillMaxWidth().padding(top = 18.dp), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Your match strength", fontWeight = FontWeight.SemiBold)
                                Text(matchLabel(scored.score), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                            Text("${scored.score}/100", fontWeight = FontWeight.Bold, fontSize = 24.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator({ scored.score / 100f }, Modifier.fillMaxWidth())
                        Text("Profile-fit score, not an acceptance probability.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.52f), modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
            item { SectionTitleNoIndent("Why Akademi matched it") }
            items(scored.reasons) { reason -> CheckRow(reason) }

            if (o.aiSummary.isNotBlank()) {
                item { SectionTitleNoIndent("Akademi AI source brief") }
                item {
                    ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text("Collector-enriched summary", fontWeight = FontWeight.Bold)
                            }
                            Text(o.aiSummary, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 10.dp))
                            if (o.aiFundingNotes.isNotBlank()) Text("Funding note: ${o.aiFundingNotes}", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                            if (o.aiUpdatedAt.isNotBlank()) Text("AI checked ${o.aiUpdatedAt} • ${o.aiModel}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.48f), modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                if (o.aiRequirements.isNotEmpty()) {
                    item { Text("Important requirements", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(o.aiRequirements) { CheckRow(it, checked = false) }
                }
                if (o.aiSelectionSignals.isNotEmpty()) {
                    item { Text("What appears to matter", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(o.aiSelectionSignals) { CheckRow(it) }
                }
                if (o.aiRisks.isNotEmpty()) {
                    item { Text("Watch-outs", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(o.aiRisks) { CheckRow(it, checked = false) }
                }
                if (o.aiActions.isNotEmpty()) {
                    item { Text("Application strategy", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(o.aiActions) { step -> NumberedInfoRow(step, o.aiActions.indexOf(step) + 1) }
                }
            }

            item { SectionTitleNoIndent("Personalized Gemini analysis") }
            item {
                ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Psychology, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Akademi Intelligence", fontWeight = FontWeight.Bold)
                                Text(settings.aiModel, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.52f))
                            }
                        }
                        when {
                            !settings.aiEnabled -> Text("AI is optional and currently off. Enable Gemini in Settings to get a profile-specific review.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 10.dp))
                            !aiConfigured -> Text("Gemini is enabled, but no API key is stored. Add your key in Settings → Gemini AI.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 10.dp))
                            aiInsight == null -> {
                                Text("Analyze this opportunity against your saved profile. Results can be cached locally so reopening the card does not consume another API call.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 10.dp))
                                Button(
                                    onClick = {
                                        val key = keyStore.load()
                                        if (key.isNullOrBlank()) aiMessage = "Gemini API key could not be read. Re-save it in Settings."
                                        else scope.launch {
                                            aiLoading = true; aiMessage = null
                                            GeminiClient.analyzeOpportunity(key, settings.aiModel, profile, scored)
                                                .onSuccess {
                                                    aiInsight = it
                                                    if (settings.aiCacheEnabled) aiCache.put(o.id, it)
                                                }
                                                .onFailure { aiMessage = it.message ?: "Gemini analysis failed" }
                                            aiLoading = false
                                        }
                                    },
                                    enabled = !aiLoading,
                                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                                ) {
                                    if (aiLoading) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)) }
                                    Text(if (aiLoading) "Analyzing…" else "Analyze with Gemini")
                                }
                            }
                        }
                        aiMessage?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
                    }
                }
            }
            aiInsight?.let { insight ->
                item { Text(insight.headline, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 14.dp)) }
                item { Text(insight.summary, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 6.dp)) }
                if (insight.strengths.isNotEmpty()) {
                    item { Text("Your strengths", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(insight.strengths) { CheckRow(it) }
                }
                if (insight.risks.isNotEmpty()) {
                    item { Text("Possible weaknesses / unknowns", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(insight.risks) { CheckRow(it, checked = false) }
                }
                if (insight.actions.isNotEmpty()) {
                    item { Text("What to do next", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(insight.actions) { step -> NumberedInfoRow(step, insight.actions.indexOf(step) + 1) }
                }
                if (insight.questionsToVerify.isNotEmpty()) {
                    item { Text("Verify on the official source", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(insight.questionsToVerify) { CheckRow(it, checked = false) }
                }
            }

            if (settings.aiEnabled && aiConfigured) {
                item {
                    OutlinedTextField(
                        value = aiQuestion,
                        onValueChange = { aiQuestion = it },
                        label = { Text("Ask Akademi about this opportunity") },
                        placeholder = { Text("e.g. What should my motivation letter emphasize?") },
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                        minLines = 2,
                        maxLines = 5
                    )
                    Button(
                        onClick = {
                            val key = keyStore.load()
                            if (!key.isNullOrBlank() && aiQuestion.isNotBlank()) scope.launch {
                                questionLoading = true; aiAnswer = null
                                GeminiClient.askOpportunity(key, settings.aiModel, profile, scored, aiQuestion)
                                    .onSuccess { aiAnswer = it }
                                    .onFailure { aiAnswer = "Gemini request failed: ${it.message ?: "unknown error"}" }
                                questionLoading = false
                            }
                        },
                        enabled = aiQuestion.isNotBlank() && !questionLoading,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) {
                        if (questionLoading) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)) }
                        Text(if (questionLoading) "Thinking…" else "Ask Gemini")
                    }
                }
                aiAnswer?.let { answer ->
                    item {
                        Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(.07f))) {
                            Text(answer, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(15.dp))
                        }
                    }
                }
            }

            item { SectionTitleNoIndent("Major details") }
            item {
                DetailRow("Type", o.opportunityType)
                DetailRow("Level", o.level)
                DetailRow("Field", o.field)
                DetailRow("Country", o.country)
                DetailRow("Study mode", o.studyMode)
                DetailRow("Duration", o.duration)
                DetailRow("Start", o.startDate)
                DetailRow("Deadline", o.deadline)
                DetailRow("Status", o.status)
                DetailRow("Supervisor", o.requiresSupervisor)
                DetailRow("Application fee", o.applicationFee)
            }

            item { SectionTitleNoIndent("Funding & benefits") }
            item {
                DetailRow("Funding", o.funding)
                DetailRow("Tuition", o.tuitionCoverage)
                DetailRow("Stipend", o.stipend)
                DetailRow("Living support", o.livingAllowance)
                DetailRow("Travel", o.travelSupport)
            }
            if (o.benefits.isNotEmpty()) items(o.benefits) { CheckRow(it) }

            if (o.eligibility.isNotEmpty() || o.eligibleNationalities.isNotEmpty()) {
                item { SectionTitleNoIndent("Eligibility") }
                if (o.eligibleNationalities.isNotEmpty()) item { DetailRow("Nationality", o.eligibleNationalities.joinToString(", ")) }
                items(o.eligibility) { CheckRow(it, checked = false) }
            }

            item { SectionTitleNoIndent("Requirements") }
            if (o.requirements.isEmpty()) item { Text("No structured requirements extracted yet. Verify the original source before applying.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f)) }
            items(o.requirements) { CheckRow(it, checked = false) }
            if (o.languageRequirements.isNotEmpty()) {
                item { Text("Language", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp)) }
                items(o.languageRequirements) { CheckRow(it, checked = false) }
            }

            if (o.documents.isNotEmpty()) {
                item { SectionTitleNoIndent("Documents") }
                items(o.documents) { CheckRow(it, checked = false) }
            }
            if (o.howToApply.isNotEmpty()) {
                item { SectionTitleNoIndent("How to apply") }
                items(o.howToApply) { step -> NumberedInfoRow(step, o.howToApply.indexOf(step) + 1) }
            }
            if (o.selectionProcess.isNotEmpty()) {
                item { SectionTitleNoIndent("Selection process") }
                items(o.selectionProcess) { CheckRow(it, checked = false) }
            }

            item { SectionTitleNoIndent("About this opportunity") }
            item { Text(o.summary.ifBlank { "Akademi found this opportunity from its source network. Open the official source below for the original wording and final verification." }, color = MaterialTheme.colorScheme.onSurface.copy(.75f), lineHeight = 22.sp) }
            item {
                Spacer(Modifier.height(22.dp))
                Button(onClick = onTrack, enabled = !tracked, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) {
                    Icon(if (tracked) Icons.Filled.Check else Icons.Outlined.BookmarkAdd, null)
                    Spacer(Modifier.width(8.dp)); Text(if (tracked) "Already in tracker" else "Save & start application")
                }
                if (o.applicationUrl.isNotBlank()) {
                    Button(onClick = onApplyInside, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(50.dp), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Outlined.Send, null); Spacer(Modifier.width(8.dp)); Text("Open application page inside Akademi")
                    }
                }
                OutlinedButton(onClick = onOpenInside, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(50.dp), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Outlined.Language, null); Spacer(Modifier.width(8.dp)); Text("View original source inside Akademi")
                }
                TextButton(onClick = onOpenExternal, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Icon(Icons.Outlined.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text("Open original source in external browser")
                }
                Text("The official source is always the final authority for eligibility, deadlines and funding. AI analysis is advisory and may be wrong.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.5f), modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
            }
        }
    }
}

@Composable private fun NumberedInfoRow(text: String, number: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.12f)) {
            Text(number.toString(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
        }
        Spacer(Modifier.width(9.dp)); Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f), lineHeight = 19.sp)
    }
}

@Composable private fun SectionTitleNoIndent(text: String) = Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 24.dp, bottom = 10.dp))
@Composable private fun CheckRow(text: String, checked: Boolean = true) { Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) { Icon(if (checked) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked, null, tint = if (checked) Teal else MaterialTheme.colorScheme.onSurface.copy(.35f), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f)) } }
@Composable private fun DetailRow(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(label, Modifier.width(92.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f)); Text(value, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f)) } }
private fun matchLabel(score: Int) = when { score >= 85 -> "Excellent fit"; score >= 70 -> "Strong fit"; score >= 55 -> "Possible fit"; else -> "Needs review" }

@Composable
private fun ResearchScreen(
    modifier: Modifier,
    profile: UserProfile,
    onOpen: (String) -> Unit,
    onOpenExternal: (String) -> Unit,
    onStories: () -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize()) {
        PageHeader("Research", "Professors, papers and directions matched to your profile")
        TabRow(selectedTabIndex = tab) {
            Tab(tab == 0, onClick = { tab = 0 }, text = { Text("Professors") })
            Tab(tab == 1, onClick = { tab = 1 }, text = { Text("Directions") })
            Tab(tab == 2, onClick = { tab = 2 }, text = { Text("Stories") })
        }
        AnimatedContent(targetState = tab, label = "researchTabs", transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) }) { selectedTab ->
            Box(Modifier.fillMaxSize()) {
                when (selectedTab) {
                    0 -> ProfessorFinder(profile, onOpen, onOpenExternal)
                    1 -> ResearchDirections(profile, onOpen, onOpenExternal)
                    else -> StoryPreview(onStories)
                }
            }
        }
    }
}

@Composable
private fun ProfessorFinder(profile: UserProfile, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    val defaultTopic = profile.researchInterests.split(',').map { it.trim() }.firstOrNull { it.isNotBlank() }
        ?: profile.field.ifBlank { "postgraduate research" }
    var query by rememberSaveable { mutableStateOf(defaultTopic) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Search current OpenAlex publications to surface researchers working in any field you choose.") }
    var researchers by remember { mutableStateOf<List<Researcher>>(emptyList()) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                query, { query = it }, Modifier.weight(1f), singleLine = true,
                label = { Text("Research topic") }, placeholder = { Text("e.g. renewable energy, finance, genomics, AI") }
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = {
                loading = true; message = "Searching current research…"
                scope.launch {
                    OpenAlexRepository.searchResearchers(query)
                        .onSuccess { researchers = it; message = "${it.size} researchers surfaced from publications related to your search." }
                        .onFailure { message = "Search failed: ${it.message}" }
                    loading = false
                }
            }) { Icon(Icons.Outlined.Search, "Search") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(message, Modifier.padding(horizontal = 20.dp, vertical = 5.dp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (researchers.isEmpty()) {
                item { InfoBanner("Search anything", "Akademi is not limited to one degree. Try your discipline, a specific research problem, methodology or interdisciplinary topic.") }
            }
            items(researchers, key = { it.id }) { r ->
                ProfessorCard(r, query, onOpen, onOpenExternal)
            }
        }
    }
}

@Composable
private fun ProfessorCard(r: Researcher, query: String, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    var expanded by rememberSaveable(r.id) { mutableStateOf(false) }
    ElevatedCard(
        Modifier.padding(horizontal = 18.dp, vertical = 7.dp).fillMaxWidth()
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioMediumBouncy))
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(21.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 8.dp else 4.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(50.dp).clip(CircleShape).background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary.copy(.18f), MaterialTheme.colorScheme.tertiary.copy(.20f)))),
                    contentAlignment = Alignment.Center
                ) { Text(r.name.take(1), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(r.institution, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f), maxLines = 2)
                    if (r.country.isNotBlank()) Text(r.country, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp))
                }
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                    Column(Modifier.size(50.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${r.fitScore}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("fit", fontSize = 8.sp)
                    }
                }
            }
            if (r.topics.isNotEmpty()) {
                Text(r.topics.take(3).joinToString(" • "), fontSize = 11.sp, modifier = Modifier.padding(top = 11.dp), color = MaterialTheme.colorScheme.onSurface.copy(.70f), maxLines = if (expanded) 4 else 2)
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (expanded) "Hide research preview" else "Expand researcher", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.primary)
            }
            AnimatedVisibility(expanded) {
                Column(Modifier.padding(top = 10.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.08f))
                    Text("Why this person surfaced", fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
                    Text("Their recent OpenAlex-indexed publications overlap with your search for “$query”. Treat this as a research-fit signal, then verify the professor's current projects and supervision availability on official profiles.", fontSize = 11.sp, lineHeight = 17.sp, color = MaterialTheme.colorScheme.onSurface.copy(.70f), modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = {}, label = { Text("${r.worksCount} matched works") })
                        AssistChip(onClick = {}, label = { Text("${r.citedByCount} citations") })
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onOpen(r.openAlexUrl) }, modifier = Modifier.weight(1f)) { Text("Research inside") }
                        OutlinedButton(onClick = { onOpenExternal(r.openAlexUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (r.orcid.isNotBlank()) {
                            val orcidUrl = if (r.orcid.startsWith("http")) r.orcid else "https://orcid.org/${r.orcid}"
                            OutlinedButton(onClick = { onOpen(orcidUrl) }, modifier = Modifier.weight(1f)) { Text("ORCID") }
                        }
                        val linkedIn = "https://www.linkedin.com/search/results/people/?keywords=${Uri.encode(r.name + " " + r.institution)}"
                        OutlinedButton(onClick = { onOpenExternal(linkedIn) }, modifier = Modifier.weight(1f)) { Text("LinkedIn search") }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResearchDirections(profile: UserProfile, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    val dirs = remember(profile) { DirectionEngine.recommend(profile) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp)) {
        item { InfoBanner("Directions adapt to you", "Akademi uses your degree, field and interests to suggest adjacent postgraduate routes. Change your profile and these cards change too.") }
        items(dirs, key = { it.title }) { d ->
            var expanded by rememberSaveable(d.title) { mutableStateOf(false) }
            ElevatedCard(
                Modifier.fillMaxWidth().padding(vertical = 7.dp)
                    .animateContentSize(spring(dampingRatio = Spring.DampingRatioMediumBouncy))
                    .clickable { expanded = !expanded },
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 8.dp else 4.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                            Icon(Icons.Outlined.Route, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(9.dp).size(21.dp))
                        }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(d.category, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                            Text(d.headline, color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 3.dp))
                        }
                        Text("${d.fitScore}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    Text(d.detail, fontSize = 11.sp, lineHeight = 17.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), modifier = Modifier.padding(top = 10.dp), maxLines = if (expanded) 8 else 3, overflow = TextOverflow.Ellipsis)
                    Row(Modifier.fillMaxWidth().padding(top = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (expanded) "Show less" else "See topics & research", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                        Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.primary)
                    }
                    AnimatedVisibility(expanded) {
                        Column(Modifier.padding(top = 8.dp)) {
                            Text("Example topics", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            d.exampleTopics.forEach { topic -> CheckRow(topic) }
                            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { onOpen(d.externalUrl) }, modifier = Modifier.weight(1f)) { Text("Explore inside") }
                                OutlinedButton(onClick = { onOpenExternal(d.externalUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun StoryPreview(onStories: () -> Unit) {
    Column(Modifier.padding(20.dp)) {
        InfoBanner("Learn from real applicants", "Akademi keeps official requirements separate from anecdotal experience. Search winner stories, interviews and forum discussions, then verify requirements at the source.")
        Button(onClick = onStories, modifier = Modifier.fillMaxWidth()) { Text("Open success-story hub") }
    }
}

@Composable
private fun SuccessStoriesScreen(onBack: () -> Unit, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    Scaffold(topBar = { SimpleBackBar("Success stories & application intelligence", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(18.dp)) {
            item { InfoBanner("Official facts vs personal experience", "Forum, YouTube and blog stories are useful for strategy, but Akademi treats them as anecdotal and keeps official programme requirements separate.") }
            item { StoryLink("Erasmus Mundus student stories", "Search YouTube for detailed application walkthroughs", "https://www.youtube.com/results?search_query=Erasmus+Mundus+scholarship+international+student+experience", onOpen, onOpenExternal) }
            item { StoryLink("DAAD scholarship experiences", "Find interviews and applicant processes", "https://www.youtube.com/results?search_query=DAAD+scholarship+international+student+experience", onOpen, onOpenExternal) }
            item { StoryLink("Commonwealth scholarship experiences", "Winner advice, essays and interviews", "https://www.youtube.com/results?search_query=Commonwealth+scholarship+winner+experience", onOpen, onOpenExternal) }
            item { StoryLink("Reddit scholarship discussions", "Search community threads and compare multiple perspectives", "https://www.google.com/search?q=site%3Areddit.com+scholarship+masters+phd+international+student+experience", onOpen, onOpenExternal) }
            item { StoryLink("Motivation-letter research", "Search scholarship-specific guidance rather than generic templates", "https://www.google.com/search?q=scholarship+motivation+letter+official+university+guidance", onOpen, onOpenExternal) }
        }
    }
}

@Composable private fun StoryLink(title: String, body: String, url: String, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    var expanded by rememberSaveable(title) { mutableStateOf(false) }
    ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 7.dp).animateContentSize().clickable { expanded = !expanded }, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.10f)) { Icon(Icons.Outlined.PlayCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(9.dp).size(22.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(body, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f), maxLines = if (expanded) 4 else 2) }
                Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, Modifier.size(18.dp))
            }
            AnimatedVisibility(expanded) {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onOpen(url) }, modifier = Modifier.weight(1f)) { Text("Open inside") }
                    OutlinedButton(onClick = { onOpenExternal(url) }, modifier = Modifier.weight(1f)) { Text("External") }
                }
            }
        }
    }
}

@Composable
private fun TrackerScreen(modifier: Modifier, opportunities: List<Opportunity>, tracker: List<TrackerItem>, onTracker: (List<TrackerItem>) -> Unit, onOpen: (Opportunity) -> Unit) {
    Column(modifier.fillMaxSize()) {
        PageHeader("My tracker", "Plan, apply and follow up")
        val preparing = tracker.count { it.status == "Preparing" }; val applied = tracker.count { it.status == "Applied" }; val interview = tracker.count { it.status == "Interview" }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("$preparing", "Preparing", Modifier.weight(1f)); StatCard("$applied", "Applied", Modifier.weight(1f)); StatCard("$interview", "Interview", Modifier.weight(1f))
        }
        if (tracker.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Outlined.Bookmarks, null, Modifier.size(52.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp)); Text("Nothing saved yet", fontWeight = FontWeight.Bold); Text("Open an opportunity and tap “Save & start application”.", textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)) {
                items(tracker, key = { it.opportunityId }) { t ->
                    val o = opportunities.firstOrNull { it.id == t.opportunityId }
                    if (o != null) TrackerCard(o, t, onChange = { changed -> onTracker(tracker.map { if (it.opportunityId == t.opportunityId) changed else it }) }, onRemove = { onTracker(tracker.filterNot { it.opportunityId == t.opportunityId }) }, onOpen = { onOpen(o) })
                }
            }
        }
    }
}

@Composable private fun TrackerCard(o: Opportunity, t: TrackerItem, onChange: (TrackerItem) -> Unit, onRemove: () -> Unit, onOpen: () -> Unit) {
    ElevatedCard(Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row { Column(Modifier.weight(1f)) { Text(o.title, fontWeight = FontWeight.Bold); Text(o.provider, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f)) }; IconButton(onClick = onRemove) { Icon(Icons.Outlined.Delete, "Remove") } }
            LinearProgressIndicator({ t.progress / 100f }, Modifier.fillMaxWidth().padding(vertical = 10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${t.progress}%", modifier = Modifier.width(45.dp), fontSize = 12.sp)
                Slider(value = t.progress.toFloat(), onValueChange = { onChange(t.copy(progress = it.toInt())) }, valueRange = 0f..100f, steps = 9, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Preparing", "Applied", "Interview", "Offer").forEach { status -> FilterChip(selected = t.status == status, onClick = { onChange(t.copy(status = status)) }, label = { Text(status, fontSize = 10.sp) }) }
            }
            TextButton(onClick = onOpen) { Text("View opportunity") }
        }
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier, profile: UserProfile, settings: SettingsState, onProfile: (UserProfile) -> Unit, onSettings: () -> Unit, onCountries: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var editing by rememberSaveable { mutableStateOf(false) }
    var name by remember(profile.name) { mutableStateOf(profile.name) }
    var headline by remember(profile.headline) { mutableStateOf(profile.headline) }
    var nationality by remember(profile.nationality) { mutableStateOf(profile.nationality) }
    var degree by remember(profile.degree) { mutableStateOf(profile.degree) }
    var field by remember(profile.field) { mutableStateOf(profile.field) }
    var cgpa by remember(profile.cgpa) { mutableStateOf(profile.cgpa.toString()) }
    var cgpaScale by remember(profile.cgpaScale) { mutableStateOf(profile.cgpaScale.toString()) }
    var interests by remember(profile.researchInterests) { mutableStateOf(profile.researchInterests) }
    var publications by remember(profile.publications) { mutableStateOf(profile.publications.toString()) }
    var targetLevel by remember(profile.targetLevel) { mutableStateOf(profile.targetLevel) }
    var researchExperience by remember(profile.researchExperience) { mutableStateOf(profile.researchExperience) }
    var preferredCountries by remember(profile.preferredCountries) { mutableStateOf(profile.preferredCountries) }
    var fullFundingPreferred by remember(profile.fullFundingPreferred) { mutableStateOf(profile.fullFundingPreferred) }
    var prPriority by remember(profile.prPriority) { mutableIntStateOf(profile.prPriority) }

    fun keepUri(uri: Uri?, banner: Boolean) {
        if (uri == null) return
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        onProfile(if (banner) profile.copy(bannerImagePath = uri.toString()) else profile.copy(profileImagePath = uri.toString()))
    }

    val profilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> keepUri(uri, false) }
    val bannerPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> keepUri(uri, true) }

    Column(modifier.fillMaxSize()) {
        PageHeader("Profile", "Your profile personalizes the entire Akademi experience") { IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, "Settings") } }
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp)) {
            item { HomeProfileHero(profile, settings) }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { profilePicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Outlined.PhotoCamera, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Profile photo") }
                    OutlinedButton(onClick = { bannerPicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Outlined.Image, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Banner") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { onProfile(profile.copy(bannerImagePath = "", bannerStyle = (profile.bannerStyle + 1) % 4)) }) {
                        Icon(Icons.Outlined.AutoAwesome, null, Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Shuffle banner")
                    }
                    if (profile.profileImagePath.isNotBlank() || profile.bannerImagePath.isNotBlank()) {
                        TextButton(onClick = { onProfile(profile.copy(profileImagePath = "", bannerImagePath = "")) }) { Text("Clear images") }
                    }
                }
            }
            item { SectionTitleNoIndent("Academic profile") }
            item {
                if (editing) {
                    OutlinedTextField(name, { name = it }, label = { Text("Name / profile label") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(headline, { headline = it }, label = { Text("Headline") }, placeholder = { Text("e.g. Environmental scientist exploring funded MSc/PhD routes") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(nationality, { nationality = it }, label = { Text("Nationality") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(degree, { degree = it }, label = { Text("Degree / qualification") }, placeholder = { Text("Any field is supported") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(field, { field = it }, label = { Text("Main field") }, placeholder = { Text("e.g. Economics, Engineering, Botany, Computer Science") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(cgpa, { cgpa = it }, label = { Text("CGPA") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(cgpaScale, { cgpaScale = it }, label = { Text("Scale") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Text("Target level", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
                    Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("Master's", "PhD", "Both").forEach { option -> FilterChip(selected = targetLevel == option, onClick = { targetLevel = option }, label = { Text(option) }) }
                    }
                    Text("Preferred destinations", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
                    Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("Germany", "Canada", "Australia", "New Zealand", "Netherlands", "Ireland", "Sweden", "Finland", "Denmark", "United Kingdom", "United States").forEach { country ->
                            FilterChip(
                                selected = country in preferredCountries,
                                onClick = { preferredCountries = if (country in preferredCountries) preferredCountries - country else preferredCountries + country },
                                label = { Text(country) }
                            )
                        }
                    }
                    ToggleRow("Prioritize full funding", "Rank fully funded and salaried research routes more strongly", fullFundingPreferred) { fullFundingPreferred = it }
                    Text("Post-study stay / PR importance: $prPriority%", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Slider(value = prPriority.toFloat(), onValueChange = { prPriority = it.toInt() }, valueRange = 0f..100f, steps = 9)
                    OutlinedTextField(interests, { interests = it }, label = { Text("Research / study interests") }, placeholder = { Text("Separate several interests with commas") }, minLines = 3, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(publications, { publications = it }, label = { Text("Publications") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    ToggleRow("Research experience", "Include this signal in personalized guidance", researchExperience) { researchExperience = it }
                    Button(
                        onClick = {
                            val scale = cgpaScale.toDoubleOrNull()?.takeIf { it > 0 } ?: profile.cgpaScale
                            val grade = cgpa.toDoubleOrNull()?.coerceIn(0.0, scale) ?: profile.cgpa
                            onProfile(
                                profile.copy(
                                    name = name.trim().ifBlank { "My Profile" }, headline = headline.trim(), nationality = nationality.trim().ifBlank { "Nigeria" },
                                    degree = degree.trim(), field = field.trim(), cgpa = grade, cgpaScale = scale, targetLevel = targetLevel,
                                    researchInterests = interests.trim(), researchExperience = researchExperience, publications = publications.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                                    preferredCountries = preferredCountries, fullFundingPreferred = fullFundingPreferred, prPriority = prPriority
                                )
                            )
                            editing = false
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                    ) { Text("Save & re-personalize Akademi") }
                } else {
                    ProfileLine("Nationality", profile.nationality)
                    ProfileLine("Degree", profile.degree.ifBlank { "Not set" })
                    ProfileLine("Field", profile.field.ifBlank { "Not set" })
                    ProfileLine("CGPA", if (profile.cgpa > 0.0) "${profile.cgpa}/${profile.cgpaScale}" else "Not set")
                    ProfileLine("Target", profile.targetLevel)
                    ProfileLine("Countries", profile.preferredCountries.joinToString().ifBlank { "Any" })
                    ProfileLine("Funding", if (profile.fullFundingPreferred) "Full funding preferred" else "Any funding")
                    ProfileLine("Stay priority", "${profile.prPriority}%")
                    ProfileLine("Research", if (profile.researchExperience) "Experience added" else "Not added")
                    ProfileLine("Publications", profile.publications.toString())
                    ProfileLine("Interests", profile.researchInterests.ifBlank { "Not set" })
                    OutlinedButton(onClick = { editing = true }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Icon(Icons.Outlined.Edit, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Edit profile & CGPA") }
                }
            }
            item { SectionTitleNoIndent("Strategy") }
            item { SettingAction(Icons.Outlined.Public, "Country & stay-potential insights", "Expandable country profiles with official external sources", onCountries) }
            item { SettingAction(Icons.Outlined.Settings, "Settings", "Theme, lively color palettes, Gemini, notifications and browsing", onSettings) }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable private fun ProfileLine(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) { Text(label, Modifier.width(115.dp), color = MaterialTheme.colorScheme.onSurface.copy(.55f), fontSize = 12.sp); Text(value, Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Medium) } }

@Composable
private fun CountryInsightsScreen(onBack: () -> Unit, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    Scaffold(topBar = { SimpleBackBar("Country insights", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(18.dp)) {
            item { InfoBanner("Travel planning + postgraduate strategy", "Stay potential is a planning signal, not immigration advice. Expand a country to see the reasoning, then verify the current rules on the official immigration website.") }
            items(SeedData.countries, key = { it.country }) { c ->
                var expanded by rememberSaveable(c.country) { mutableStateOf(false) }
                ElevatedCard(
                    Modifier.fillMaxWidth().padding(vertical = 7.dp).animateContentSize(spring(dampingRatio = Spring.DampingRatioMediumBouncy)).clickable { expanded = !expanded },
                    shape = RoundedCornerShape(22.dp),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 8.dp else 4.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                                Icon(Icons.Outlined.Flight, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(10.dp).size(22.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.country, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text(c.headline, color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                            }
                            Text("${c.stayPotential}/100", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (expanded) "Hide country profile" else "Expand country profile", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                            Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        AnimatedVisibility(expanded) {
                            Column(Modifier.padding(top = 8.dp)) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.08f))
                                Text(c.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.70f), modifier = Modifier.padding(top = 12.dp), lineHeight = 18.sp)
                                Text("Akademi prioritizes countries using study opportunity, post-study work potential and your profile preferences. Rules change, so the official source is always the final authority.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f), modifier = Modifier.padding(top = 8.dp), lineHeight = 15.sp)
                                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { onOpen(c.officialUrl) }, modifier = Modifier.weight(1f)) { Text("View inside") }
                                    OutlinedButton(onClick = { onOpenExternal(c.officialUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    settings: SettingsState, onSettings: (SettingsState) -> Unit, remoteMessage: String?, onRefresh: (String?) -> Unit,
    onBack: () -> Unit, onReset: () -> Unit
) {
    var feed by remember(settings.liveFeedUrl) { mutableStateOf(settings.liveFeedUrl) }
    val settingsContext = androidx.compose.ui.platform.LocalContext.current
    val instantPushConfigured = remember { settingsContext.resources.getIdentifier("google_app_id", "string", settingsContext.packageName) != 0 }
    val keyStore = remember { SecureGeminiKeyStore(settingsContext) }
    val aiCache = remember { AiInsightCache(settingsContext) }
    val scope = rememberCoroutineScope()
    var apiKeyInput by rememberSaveable { mutableStateOf("") }
    var keyConfigured by remember { mutableStateOf(keyStore.hasKey()) }
    var aiStatus by remember { mutableStateOf<String?>(null) }
    var testingAi by remember { mutableStateOf(false) }

    Scaffold(topBar = { SimpleBackBar("Settings", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp)) {
            item { SettingsHeading("Appearance") }
            item {
                Text("Theme", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(Modifier.padding(vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ThemeMode.entries.forEach { m -> FilterChip(selected = settings.themeMode == m, onClick = { onSettings(settings.copy(themeMode = m)) }, label = { Text(m.name.lowercase().replaceFirstChar { it.uppercase() }) }) }
                }
            }
            item {
                Text("Accent color", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Choose a lively palette inspired by the Akademi logo. The selection updates cards, buttons, highlights and profile banners.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 3.dp))
                LazyRow(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(AccentPreset.entries) { a -> AccentPaletteCard(a, settings.accent == a) { onSettings(settings.copy(accent = a)) } }
                }
            }
            item { SettingsHeading("App behaviour") }
            item { ToggleRow("Notifications", "Master switch for Akademi alerts", settings.notifications) { onSettings(settings.copy(notifications = it)) } }
            item { ToggleRow("New opportunity alerts", "Notify when the live collector finds new strong profile matches", settings.opportunityAlerts) { onSettings(settings.copy(opportunityAlerts = it)) } }
            item { ToggleRow("Deadline alerts", "Remind you about tracked applications as deadlines approach", settings.deadlineAlerts) { onSettings(settings.copy(deadlineAlerts = it)) } }
            item { ToggleRow("Refresh live feed on launch", "Refresh the collector feed whenever Akademi opens", settings.refreshOnLaunch) { onSettings(settings.copy(refreshOnLaunch = it)) } }
            item { ToggleRow("Allow external browser by default", "Off by default. Opportunity details still open in Akademi first", settings.openLinksExternally) { onSettings(settings.copy(openLinksExternally = it)) } }
            item { ToggleRow("Web-page popups & new-window links", "Allow target=_blank and JavaScript window links while browsing sources inside Akademi", settings.webPopupsEnabled) { onSettings(settings.copy(webPopupsEnabled = it)) } }
            item { Text(if (instantPushConfigured) "Instant push: Firebase Cloud Messaging configured" else "Instant push: optional Firebase config not installed; background live-feed alerts remain active", fontSize = 11.sp, color = if (instantPushConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 6.dp)) }

            item { SettingsHeading("Gemini AI (optional)") }
            item { ToggleRow("Enable Akademi Intelligence", "Adds AI summaries, personalized opportunity analysis and scholarship Q&A. Core Akademi remains fully usable when off.", settings.aiEnabled) { onSettings(settings.copy(aiEnabled = it)) } }
            item {
                Text("Model", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                Row(Modifier.padding(vertical = 8.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GeminiClient.supportedModels.forEach { model ->
                        FilterChip(selected = settings.aiModel == model, onClick = { onSettings(settings.copy(aiModel = model)) }, label = { Text(model.removePrefix("gemini-")) })
                    }
                }
                Text("3.6 Flash is the default configured model. Check AI Studio for the current free-tier quota and model availability, since provider limits can change.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f))
            }
            item {
                Text("API key", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
                Text(if (keyConfigured) "A Gemini key is securely stored on this device." else "No Gemini key is stored on this device.", fontSize = 11.sp, color = if (keyConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 3.dp))
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it; aiStatus = null },
                    label = { Text(if (keyConfigured) "Replace Gemini API key" else "Gemini API key") },
                    placeholder = { Text("Paste key from Google AI Studio") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            runCatching { keyStore.save(apiKeyInput) }
                                .onSuccess { keyConfigured = true; apiKeyInput = ""; aiStatus = "Gemini key saved securely on this device." }
                                .onFailure { aiStatus = it.message ?: "Could not save key" }
                        },
                        enabled = apiKeyInput.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) { Text("Save key") }
                    Button(
                        onClick = {
                            val testKey = apiKeyInput.trim().ifBlank { keyStore.load().orEmpty() }
                            if (testKey.isBlank()) aiStatus = "Add or save a Gemini API key first."
                            else scope.launch {
                                testingAi = true; aiStatus = "Testing Gemini…"
                                GeminiClient.test(testKey, settings.aiModel)
                                    .onSuccess { aiStatus = it }
                                    .onFailure { aiStatus = it.message ?: "Gemini connection failed" }
                                testingAi = false
                            }
                        },
                        enabled = !testingAi && (apiKeyInput.isNotBlank() || keyConfigured),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (testingAi) { CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp); Spacer(Modifier.width(6.dp)) }
                        Text(if (testingAi) "Testing…" else "Test connection")
                    }
                }
                if (keyConfigured) TextButton(onClick = { keyStore.clear(); keyConfigured = false; aiStatus = "Gemini key removed from this device." }) { Text("Remove stored key") }
                aiStatus?.let { Text(it, fontSize = 11.sp, color = if (it.contains("error", true) || it.contains("failed", true)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 4.dp)) }
            }
            item { ToggleRow("Cache personalized AI reviews", "Recommended. Reopening the same scholarship will reuse its local AI analysis instead of spending another request.", settings.aiCacheEnabled) { onSettings(settings.copy(aiCacheEnabled = it)) } }
            item {
                OutlinedButton(onClick = { aiCache.clear(); aiStatus = "Local Gemini analysis cache cleared." }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Icon(Icons.Outlined.DeleteSweep, null); Spacer(Modifier.width(8.dp)); Text("Clear AI analysis cache")
                }
            }
            item {
                Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary.copy(.08f))) {
                    Text("Privacy note: Gemini free-tier prompts may be used by Google to improve its products. Avoid submitting unnecessary sensitive information in CVs, research proposals or personal statements. Collector enrichment uses public scholarship information only.", fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurface.copy(.68f))
                }
            }

            item { SettingsHeading("Live opportunity feed") }
            item { Text("The included collector publishes a normalized HTTPS scholarship feed. When the GitHub GEMINI_API_KEY secret is configured, the collector can enrich newly found opportunities once and cache those summaries in the feed; otherwise collection continues without AI.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), lineHeight = 18.sp) }
            item {
                OutlinedTextField(feed, { feed = it }, label = { Text("HTTPS feed URL") }, placeholder = { Text("https://…/opportunities.json") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), singleLine = true)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onSettings(settings.copy(liveFeedUrl = feed.trim())) }, modifier = Modifier.weight(1f)) { Text("Save feed") }
                    Button(onClick = { val u = feed.trim(); onSettings(settings.copy(liveFeedUrl = u)); onRefresh(u) }, modifier = Modifier.weight(1f)) { Text("Save & refresh") }
                }
                remoteMessage?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f), modifier = Modifier.padding(top = 6.dp)) }
            }
            item { SettingsHeading("Privacy & data") }
            item { Text("Profile, tracker, appearance preferences and optional AI cache are stored locally. The Gemini key is encrypted with Android Keystore. Professor searches are sent directly to OpenAlex when requested.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f)) }
            item { OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Icon(Icons.Outlined.RestartAlt, null); Spacer(Modifier.width(8.dp)); Text("Reset local app data") } }
            item { SettingsHeading("About") }
            item { AkademiWordmark(); Text("Version 0.3.0 • Gemini Intelligence • Live collector • Dynamic feed • Expandable research cards • Full-screen video", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f), modifier = Modifier.padding(top = 8.dp, bottom = 30.dp)) }
        }
    }
}


@Composable
private fun AccentPaletteCard(preset: AccentPreset, selected: Boolean, onClick: () -> Unit) {
    val colors = accentGradient(preset)
    Surface(
        modifier = Modifier.width(132.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.10f)),
        shadowElevation = if (selected) 7.dp else 2.dp,
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.padding(8.dp)) {
            Box(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(colors))) {
                if (selected) Surface(Modifier.align(Alignment.TopEnd).padding(6.dp), shape = CircleShape, color = Color.White.copy(.92f)) { Icon(Icons.Filled.Check, null, tint = colors.first(), modifier = Modifier.padding(4.dp).size(14.dp)) }
            }
            Text(preset.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 3.dp, top = 7.dp, bottom = 2.dp))
        }
    }
}

@Composable private fun SettingsHeading(text: String) { Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(top = 18.dp, bottom = 10.dp)) }
@Composable private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onCheck: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Medium); Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f)) }; Switch(checked = checked, onCheckedChange = onCheck) } }
@Composable private fun SettingAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) { ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable(onClick = onClick), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f)) }; Icon(Icons.Outlined.ChevronRight, null) } } }

@Composable private fun SimpleBackBar(title: String, onBack: () -> Unit) { Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }; Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp) } }

@Composable private fun InfoBanner(title: String, body: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(.08f)), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.Top) { Icon(Icons.Outlined.Info, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp)); Column { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(body, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.67f), modifier = Modifier.padding(top = 4.dp), lineHeight = 16.sp) } }
    }
}

@Composable
private fun WebScreen(url: String, popupsEnabled: Boolean, onExternal: () -> Unit, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as? android.app.Activity
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageTitle by remember { mutableStateOf("Source") }
    var loading by remember { mutableStateOf(true) }
    var customView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    fun hideFullscreenVideo() {
        val view = customView ?: return
        val decor = activity?.window?.decorView as? ViewGroup
        decor?.removeView(view)
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    fun handleBack() {
        if (customView != null) hideFullscreenVideo()
        else {
            val view = webView
            if (view?.canGoBack() == true) view.goBack() else onBack()
        }
    }

    BackHandler { handleBack() }
    DisposableEffect(Unit) {
        onDispose {
            hideFullscreenVideo()
            webView?.stopLoading()
            webView?.destroy()
        }
    }

    Scaffold(topBar = {
        if (customView == null) {
            Column {
                Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { handleBack() }) { Icon(Icons.Outlined.ArrowBack, "Back") }
                    Column(Modifier.weight(1f)) {
                        Text(pageTitle.ifBlank { "Source" }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(webView?.url ?: url, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                    }
                    IconButton(onClick = { webView?.reload() }) { Icon(Icons.Outlined.Refresh, "Reload") }
                    IconButton(onClick = onExternal) { Icon(Icons.Outlined.OpenInNew, "Open externally") }
                }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        }
    }) { p ->
        AndroidView(
            modifier = Modifier.padding(if (customView == null) p else PaddingValues(0.dp)).fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    webView = this
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadsImagesAutomatically = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.javaScriptCanOpenWindowsAutomatically = popupsEnabled
                    settings.setSupportMultipleWindows(popupsEnabled)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val target = request?.url?.toString().orEmpty()
                            return if (target.startsWith("http://") || target.startsWith("https://")) {
                                view?.loadUrl(target); true
                            } else false
                        }
                        override fun onPageFinished(view: WebView?, url: String?) { loading = false }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) { loading = newProgress < 100 }
                        override fun onReceivedTitle(view: WebView?, title: String?) { pageTitle = title.orEmpty() }
                        override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                            if (view == null || activity == null) { callback?.onCustomViewHidden(); return }
                            if (customView != null) { callback?.onCustomViewHidden(); return }
                            customView = view
                            customViewCallback = callback
                            val decor = activity.window.decorView as ViewGroup
                            decor.addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                            activity.window.decorView.systemUiVisibility =
                                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        }
                        override fun onHideCustomView() { hideFullscreenVideo() }
                        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                            if (!popupsEnabled || view == null || resultMsg == null) return false
                            val popup = WebView(ctx)
                            popup.settings.javaScriptEnabled = true
                            popup.settings.domStorageEnabled = true
                            popup.settings.javaScriptCanOpenWindowsAutomatically = true
                            popup.settings.setSupportMultipleWindows(true)
                            popup.webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                                    val target = request?.url?.toString().orEmpty()
                                    if (target.startsWith("http")) {
                                        view.loadUrl(target)
                                        popup.destroy()
                                        return true
                                    }
                                    return false
                                }
                                override fun onPageStarted(v: WebView?, popupUrl: String?, favicon: android.graphics.Bitmap?) {
                                    if (!popupUrl.isNullOrBlank() && popupUrl != "about:blank") {
                                        view.loadUrl(popupUrl)
                                        popup.destroy()
                                    }
                                }
                            }
                            val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                            transport.webView = popup
                            resultMsg.sendToTarget()
                            return true
                        }
                    }
                    loadUrl(url)
                }
            },
            update = { view ->
                view.settings.javaScriptCanOpenWindowsAutomatically = popupsEnabled
                view.settings.setSupportMultipleWindows(popupsEnabled)
            }
        )
    }
}

private fun openUrl(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
