import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

android {
    val akademiFeedUrl = providers.gradleProperty("AKADEMI_FEED_URL").orElse("")
    val akademiUpdateApiUrl = providers.gradleProperty("AKADEMI_UPDATE_API_URL").orElse("")
    namespace = "com.akademi.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.akademi.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 15
        versionName = "0.5.0"
        buildConfigField("String", "DEFAULT_LIVE_FEED_URL", "\"${akademiFeedUrl.get()}\"")
        buildConfigField("String", "DEFAULT_UPDATE_API_URL", "\"${akademiUpdateApiUrl.get()}\"")
    }

    signingConfigs {
        create("personalRelease") {
            val keyPath = System.getenv("AKADEMI_KEYSTORE_PATH")
            if (!keyPath.isNullOrBlank()) {
                storeFile = file(keyPath)
                storePassword = System.getenv("AKADEMI_STORE_PASSWORD")
                keyAlias = System.getenv("AKADEMI_KEY_ALIAS")
                keyPassword = System.getenv("AKADEMI_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = false
            if (!System.getenv("AKADEMI_KEYSTORE_PATH").isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("personalRelease")
            }
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}


kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.fromTarget("17")
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2026.06.00"))
    androidTestImplementation(platform("androidx.compose:compose-bom:2026.06.00"))

    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.ui:ui-text-google-fonts")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("androidx.work:work-runtime-ktx:2.11.2")
    implementation(platform("com.google.firebase:firebase-bom:34.17.0"))
    implementation("com.google.firebase:firebase-messaging")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
