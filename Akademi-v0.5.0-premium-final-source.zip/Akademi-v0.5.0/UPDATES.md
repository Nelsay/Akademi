# Akademi signed updates

Akademi v0.5.0 begins the stable personal signing line.

## Why this matters
Android only installs a new APK over an existing app when the application ID and signing certificate match and the version code increases. Previous GitHub debug builds used runner-created debug signing keys, so each runner could produce an APK Android would not accept as an update.

v0.5.0 uses one persistent personal Akademi signing key restored from a GitHub Actions secret. Keep that key forever. Future releases must use the same key and a higher `versionCode`.

## In-app updater
Settings → App updates checks the GitHub Releases `latest` API endpoint embedded at build time. When a newer release exists, Akademi downloads the APK over HTTPS, verifies SHA-256 when available, and opens Android's system package installer for the final confirmation.

A normal Android app cannot silently replace itself. The system installer always owns the final install/update confirmation.

## One-time migration
Because v0.4.x and earlier were debug-signed, they cannot be updated directly to the new personal release certificate. Uninstall the old Akademi once, install the signed v0.5.0 APK, and then keep the signing key unchanged. Future signed versions can update in place.

## Private repository note
The embedded GitHub Releases updater expects the release API and APK asset to be reachable without an authenticated GitHub session. If the repository/release is private, use manual APK updates or a separate public release endpoint.
