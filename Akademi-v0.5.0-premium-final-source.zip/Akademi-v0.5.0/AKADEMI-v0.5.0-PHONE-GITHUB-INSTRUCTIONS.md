# Akademi v0.5.0 — phone + GitHub build

This version starts Akademi's **persistent signed release line**, which fixes the previous “new APK will not update the installed app” problem.

## Files to upload to the repository root

1. `Akademi-v0.5.0-premium-final-source.zip`
2. `build-akademi-v0.5.0-signed.yml` inside `.github/workflows/`
3. `collect-akademi-live-feed-v0.5.0.yml` inside `.github/workflows/`

You can keep the older ZIPs, but the v0.5 workflow only looks for the exact v0.5 filename.

## One required GitHub secret for signed updates

Open the repository → **Settings → Secrets and variables → Actions → New repository secret**.

Name it exactly:

`AKADEMI_SIGNING_KEY_B64`

Paste the complete contents of the supplied private file:

`Akademi-Personal-Signing-v1.base64.txt`

Never commit that text file or the `.jks` file to the repository. Keep both as private backups. If this signing key is lost, future APKs cannot update this installed app in place.

The signing alias is `akademi`. The key is valid through 2054.

## Existing optional secret

Keep `GEMINI_API_KEY` if you want automatic Gemini source enrichment in the live collector.

`FIREBASE_SERVICE_ACCOUNT_JSON` remains optional for instant FCM push.

## Build

Run **Build Akademi v0.5.0 Signed Release** from GitHub Actions.

A successful build gives you:

- `Akademi-v0.5.0.apk`
- its SHA-256 file
- a GitHub Release tagged `v0.5.0`

The release is what Akademi's in-app updater checks later.

## Important one-time install step

**Uninstall any v0.4.x or older Akademi APK before installing v0.5.0.**

Those old builds used changing debug certificates, so Android cannot accept v0.5.0 as an in-place update over them. This is a one-time signing migration.

After v0.5.0 is installed, future Akademi versions built with the same signing secret and a higher `versionCode` can update the existing app.

## Future update flow

Inside Akademi:

**Profile → Settings → App updates → Check now → Install update**

Android still shows its own final install confirmation. Akademi cannot and should not bypass that system security step.

## Play Protect / sideload trust

The APK is release-signed with one stable certificate, uses HTTPS-only update/download paths, disables cleartext traffic, and publishes an APK SHA-256. These improve integrity and continuity, but the first sideload can still trigger Android/Play Protect warnings because the APK is not distributed through Google Play.

## Repository visibility

For the built-in GitHub updater to work without GitHub login, the latest Release/API and APK asset must be publicly reachable. If your code repository is private, you can keep manual updates or later point `AKADEMI_UPDATE_API_URL` to a small public release endpoint.
