package com.akademi.app.data

/**
 * Akademi's bundled editorial image library.
 *
 * The app always prefers a real source image when the collector provides one.
 * When a scholarship, professor, country, story or guidance item has no reliable
 * remote image, these generated assets keep the experience visual without
 * pretending that a generic image is the real institution or person.
 */
object VisualLibrary {
    val all = listOf(
        "res://akademi_visual_01_candid_welcome_in_a_bright_terminal",
        "res://akademi_visual_02_coastal_campus_walkway_stroll",
        "res://akademi_visual_03_collaborative_high_tech_laboratory_research",
        "res://akademi_visual_04_collaborative_modern_design_studio",
        "res://akademi_visual_05_collaborative_robotics_makerspace_workshop",
        "res://akademi_visual_06_cozy_home_office_video_call",
        "res://akademi_visual_07_cozy_sunlit_bedroom_workspace",
        "res://akademi_visual_08_golden_hour_cyclist_on_historic_campus_street",
        "res://akademi_visual_09_grand_library_reading_room",
        "res://akademi_visual_10_joyful_graduate_in_a_sunlit_campus",
        "res://akademi_visual_11_midnight_coding_in_the_neon_workspace",
        "res://akademi_visual_12_modern_lecture_hall_seminar",
        "res://akademi_visual_13_mountain_train_journey_begins",
        "res://akademi_visual_14_professional_networking_in_a_bright_atrium",
        "res://akademi_visual_15_professor_in_a_bright_research_office",
        "res://akademi_visual_16_rainy_blue_hour_campus_walk",
        "res://akademi_visual_17_rooftop_cafe_workday",
        "res://akademi_visual_18_snowy_tramway_by_the_grand_hall",
        "res://akademi_visual_19_springtime_campus_study_group",
        "res://akademi_visual_20_sunlit_artist_studio_workspace",
        "res://akademi_visual_21_sunlit_greenhouse_plant_science_lab",
        "res://akademi_visual_22_sunlit_travel_themed_study_workspace",
        "res://akademi_visual_23_sunny_campus_courtyard_walkway",
        "res://akademi_visual_24_sunny_waterfront_promenade_stroll",
        "res://akademi_visual_25_travel_planning_desk_flat_lay",
        "res://akademi_visual_26_traveler_checking_airport_departures"
    )

    private fun stableIndex(key: String, size: Int = all.size): Int {
        val positive = key.fold(17) { acc, c -> (acc * 31 + c.code) and 0x7fffffff }
        return positive % size.coerceAtLeast(1)
    }

    fun generic(key: String): String = all[stableIndex(key)]

    fun forOpportunity(o: Opportunity): String = o.imageUrl.ifBlank { fallbackForOpportunity(o) }

    fun fallbackForOpportunity(o: Opportunity): String {
        val text = "${o.title} ${o.field} ${o.keywords.joinToString(" ")} ${o.country}".lowercase()
        return when {
            listOf("computer", "software", "data", "ai ", "artificial intelligence", "robot", "engineering").any { it in text } ->
                listOf(all[4], all[10], all[3])[stableIndex(o.id, 3)]
            listOf("health", "medical", "medicine", "biotech", "genomic", "molecular").any { it in text } -> all[2]
            listOf("plant", "agriculture", "environment", "climate", "ecology", "botany").any { it in text } -> all[20]
            listOf("art", "design", "architecture", "creative", "humanities").any { it in text } ->
                listOf(all[19], all[3], all[8])[stableIndex(o.id, 3)]
            listOf("business", "finance", "econom", "management", "policy", "law").any { it in text } ->
                listOf(all[13], all[16], all[8])[stableIndex(o.id, 3)]
            o.level.contains("PhD", true) -> listOf(all[14], all[8], all[11])[stableIndex(o.id, 3)]
            else -> listOf(all[22], all[1], all[18], all[23], all[17])[stableIndex(o.id, 5)]
        }
    }

    fun forResearcher(r: Researcher): String {
        val text = (r.topics.joinToString(" ") + " " + r.institution).lowercase()
        return when {
            listOf("computer", "data", "machine", "artificial", "robot", "engineering").any { it in text } -> all[4]
            listOf("medical", "health", "genomic", "cancer", "biotech").any { it in text } -> all[2]
            listOf("plant", "ecology", "environment", "agri", "climate").any { it in text } -> all[20]
            listOf("design", "architecture", "art").any { it in text } -> all[3]
            else -> listOf(all[8], all[11], all[13])[stableIndex(r.id, 3)]
        }
    }

    fun forDirection(title: String, description: String = ""): String {
        val text = "$title $description".lowercase()
        return when {
            listOf("computer", "software", "data", "ai", "robot", "engineering").any { it in text } -> all[4]
            listOf("medical", "health", "biotech", "biology", "genomic").any { it in text } -> all[2]
            listOf("plant", "agriculture", "environment", "climate", "ecology").any { it in text } -> all[20]
            listOf("art", "design", "architecture", "creative").any { it in text } -> all[19]
            listOf("business", "finance", "econom", "management", "policy").any { it in text } -> all[13]
            else -> generic(title)
        }
    }

    fun forCountry(country: String): String = when (country.lowercase()) {
        "germany" -> all[17]
        "canada" -> all[15]
        "australia" -> all[1]
        "new zealand" -> all[12]
        "united kingdom", "uk" -> all[7]
        "ireland" -> all[23]
        "netherlands" -> all[23]
        "sweden", "finland", "denmark", "norway" -> all[17]
        else -> listOf(all[1], all[12], all[23], all[25])[stableIndex(country, 4)]
    }

    fun forStory(key: String): String = listOf(
        all[9], all[0], all[18], all[5], all[13], all[24]
    )[stableIndex(key, 6)]

    fun forHomeTip(key: String): String = listOf(
        all[24], all[21], all[6], all[8], all[16], all[5]
    )[stableIndex(key, 6)]

    fun forHero(profile: UserProfile): String {
        if (profile.bannerImagePath.isNotBlank()) return profile.bannerImagePath
        return listOf(all[22], all[1], all[17], all[23], all[15])[profile.bannerStyle % 5]
    }
}
