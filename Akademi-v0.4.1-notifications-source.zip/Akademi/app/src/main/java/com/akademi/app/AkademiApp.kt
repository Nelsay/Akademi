package com.akademi.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Message
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.akademi.app.data.*
import com.akademi.app.ai.AiInsightCache
import com.akademi.app.ai.GeminiClient
import com.akademi.app.ai.SecureGeminiKeyStore
import com.akademi.app.settings.*
import com.akademi.app.notifications.AkademiNotificationManager
import com.akademi.app.notifications.AkademiInboxNotification
import com.akademi.app.notifications.InAppNotificationStore
import com.akademi.app.push.OptionalFcmPush
import com.akademi.app.ui.AkademiMark
import com.akademi.app.ui.AkademiWordmark
import com.akademi.app.ui.SmartImage
import com.akademi.app.ui.theme.AkademiTheme
import com.akademi.app.ui.theme.Gold
import com.akademi.app.ui.theme.Teal
import com.akademi.app.ui.theme.accentGradient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Screen { HOME, DISCOVER, RESEARCH, TRACKER, PROFILE, SETTINGS, COUNTRIES, STORIES, NOTIFICATIONS, DETAIL, WEB }

@Composable
fun AkademiApp(
    launchTarget: AkademiLaunchTarget? = null,
    onLaunchTargetConsumed: () -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { AppPreferences(context) }
    var settings by remember { mutableStateOf(prefs.loadSettings()) }
    var profile by remember { mutableStateOf(prefs.loadProfile()) }
    var tracker by remember { mutableStateOf(prefs.loadTracker()) }
    var opportunities by remember { mutableStateOf(SeedData.opportunities) }
    var selected by remember { mutableStateOf<Opportunity?>(null) }
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var lastMain by rememberSaveable { mutableStateOf(Screen.HOME) }
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var remoteMessage by remember { mutableStateOf<String?>(null) }
    var webUrl by rememberSaveable { mutableStateOf("") }
    var returnScreen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val scope = rememberCoroutineScope()
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    var notificationVersion by remember { mutableIntStateOf(0) }
    val inboxNotifications = remember(notificationVersion, screen, launchTarget?.nonce) { InAppNotificationStore.load(context) }

    fun go(next: Screen) {
        if (next in listOf(Screen.HOME, Screen.DISCOVER, Screen.RESEARCH, Screen.TRACKER, Screen.PROFILE)) lastMain = next
        screen = next
    }
    fun openInside(url: String) {
        returnScreen = screen
        webUrl = url
        screen = Screen.WEB
    }
    fun openOutside(url: String) { openUrl(context, url) }
    fun openLink(url: String) { if (settings.openLinksExternally) openOutside(url) else openInside(url) }
    fun loadRemote(feedOverride: String? = null) {
        val feedUrl = feedOverride?.trim().orEmpty().ifBlank { settings.liveFeedUrl }
        if (feedUrl.isBlank()) {
            remoteMessage = "Add a normalized HTTPS feed URL in Settings to enable live opportunity updates."
            return
        }
        scope.launch {
            remoteMessage = "Refreshing live feed…"
            val result = RemoteOpportunityRepository.fetch(feedUrl)
            result.onSuccess { remote ->
                opportunities = (remote + SeedData.opportunities).distinctBy { it.id }
                remoteMessage = "Loaded ${remote.size} live opportunities."
            }.onFailure { remoteMessage = "Feed refresh failed: ${it.message ?: "unknown error"}" }
        }
    }

    LaunchedEffect(Unit) {
        delay(850)
        showSplash = false
        if (settings.refreshOnLaunch && settings.liveFeedUrl.isNotBlank()) loadRemote()
    }

    LaunchedEffect(settings.notifications, settings.liveFeedUrl) {
        if (settings.notifications) OptionalFcmPush.initialize(context)
        AkademiNotificationManager.schedule(context, settings.notifications && settings.liveFeedUrl.isNotBlank())
        if (settings.notifications && Build.VERSION.SDK_INT >= 33 && !AkademiNotificationManager.canNotify(context)) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(profile, opportunities, tracker, settings.notifications) {
        if (settings.notifications && InAppNotificationStore.sync(context, profile, opportunities, tracker)) {
            notificationVersion++
        }
    }

    LaunchedEffect(launchTarget?.nonce, opportunities) {
        val target = launchTarget ?: return@LaunchedEffect
        if (target.opportunityId.isNotBlank()) {
            val opportunity = opportunities.firstOrNull { it.id == target.opportunityId }
            if (opportunity != null) {
                InAppNotificationStore.markOpportunityRead(context, target.opportunityId)
                notificationVersion++
                selected = opportunity
                screen = Screen.DETAIL
            } else if (target.openNotifications) {
                screen = Screen.NOTIFICATIONS
            }
        } else if (target.openNotifications) {
            screen = Screen.NOTIFICATIONS
        }
        onLaunchTargetConsumed()
    }

    BackHandler(enabled = !showSplash && screen != Screen.HOME && screen != Screen.WEB) {
        screen = when (screen) {
            Screen.DETAIL, Screen.COUNTRIES, Screen.STORIES, Screen.NOTIFICATIONS -> lastMain
            Screen.SETTINGS -> Screen.PROFILE
            Screen.DISCOVER, Screen.RESEARCH, Screen.TRACKER, Screen.PROFILE -> Screen.HOME
            else -> screen
        }
    }

    AkademiTheme(settings) {
        if (showSplash) {
            SplashScreen()
        } else {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (screen) {
                    Screen.DETAIL -> OpportunityDetailScreen(
                        scored = selected?.let { MatchEngine.score(profile, it) },
                        tracked = selected?.let { o -> tracker.any { it.opportunityId == o.id } } == true,
                        profile = profile,
                        settings = settings,
                        onBack = { screen = lastMain },
                        onOpenInside = { selected?.sourceUrl?.let { openInside(it) } },
                        onOpenExternal = { selected?.sourceUrl?.let { openOutside(it) } },
                        onApplyInside = { selected?.let { openInside(it.applicationUrl.ifBlank { it.sourceUrl }) } },
                        onTrack = {
                            selected?.let { o ->
                                if (tracker.none { it.opportunityId == o.id }) {
                                    tracker = tracker + TrackerItem(o.id)
                                    prefs.saveTracker(tracker)
                                }
                            }
                        }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        settings = settings,
                        onSettings = { settings = it; prefs.saveSettings(it) },
                        remoteMessage = remoteMessage,
                        onRefresh = { url -> loadRemote(url) },
                        onBack = { screen = Screen.PROFILE },
                        onReset = {
                            prefs.reset()
                            InAppNotificationStore.reset(context)
                            notificationVersion++
                            settings = SettingsState()
                            profile = UserProfile()
                            tracker = emptyList()
                            opportunities = SeedData.opportunities
                            remoteMessage = "Local Akademi data reset."
                        }
                    )
                    Screen.COUNTRIES -> CountryInsightsScreen(onBack = { screen = lastMain }, onOpen = { openInside(it) }, onOpenExternal = { openOutside(it) })
                    Screen.STORIES -> SuccessStoriesScreen(onBack = { screen = lastMain }, onOpen = { openInside(it) }, onOpenExternal = { openOutside(it) })
                    Screen.NOTIFICATIONS -> NotificationCenterScreen(
                        settings = settings,
                        notifications = inboxNotifications,
                        opportunities = opportunities,
                        onBack = { screen = lastMain },
                        onMarkAllRead = {
                            InAppNotificationStore.markAllRead(context)
                            notificationVersion++
                        },
                        onClear = {
                            InAppNotificationStore.reset(context)
                            notificationVersion++
                        },
                        onNotification = { notice ->
                            InAppNotificationStore.markRead(context, notice.id)
                            notificationVersion++
                            opportunities.firstOrNull { it.id == notice.opportunityId }?.let { opportunity ->
                                selected = opportunity
                                screen = Screen.DETAIL
                            }
                        }
                    )
                    Screen.WEB -> WebScreen(url = webUrl, popupsEnabled = settings.webPopupsEnabled, onExternal = { openOutside(webUrl) }, onBack = { screen = returnScreen })
                    else -> MainScaffold(
                        screen = screen,
                        onNavigate = ::go
                    ) { padding, targetScreen ->
                        when (targetScreen) {
                            Screen.HOME -> HomeScreen(
                                modifier = Modifier.padding(padding), profile = profile, settings = settings, opportunities = opportunities,
                                tracker = tracker, onDiscover = { go(Screen.DISCOVER) }, onResearch = { go(Screen.RESEARCH) },
                                onCountries = { screen = Screen.COUNTRIES }, onStories = { screen = Screen.STORIES },
                                unreadNotifications = inboxNotifications.count { !it.isRead },
                                onNotifications = { notificationVersion++; screen = Screen.NOTIFICATIONS },
                                onRefresh = { loadRemote() }, onOpenWeb = { openInside(it) }, onOpenExternal = { openOutside(it) },
                                onOpportunity = { selected = it; screen = Screen.DETAIL }
                            )
                            Screen.DISCOVER -> DiscoverScreen(
                                modifier = Modifier.padding(padding), profile = profile, opportunities = opportunities,
                                remoteMessage = remoteMessage, onRefresh = { loadRemote() },
                                onOpportunity = { selected = it; screen = Screen.DETAIL }, onOpenExternal = { openOutside(it) }
                            )
                            Screen.RESEARCH -> ResearchScreen(
                                modifier = Modifier.padding(padding), profile = profile,
                                onOpen = { openInside(it) }, onOpenExternal = { openOutside(it) }, onStories = { screen = Screen.STORIES }
                            )
                            Screen.TRACKER -> TrackerScreen(
                                modifier = Modifier.padding(padding), opportunities = opportunities, tracker = tracker,
                                onTracker = { tracker = it; prefs.saveTracker(it) },
                                onOpen = { o -> selected = o; screen = Screen.DETAIL }
                            )
                            Screen.PROFILE -> ProfileScreen(
                                modifier = Modifier.padding(padding), profile = profile, settings = settings,
                                onProfile = { profile = it; prefs.saveProfile(it) },
                                onSettings = { screen = Screen.SETTINGS }, onCountries = { screen = Screen.COUNTRIES }
                            )
                            else -> Unit
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.secondary).systemBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(shape = RoundedCornerShape(30.dp), color = Color.White, shadowElevation = 8.dp) {
                Box(Modifier.padding(14.dp), contentAlignment = Alignment.Center) { AkademiMark(Modifier.size(104.dp)) }
            }
            Spacer(Modifier.height(18.dp))
            Text("Akademi", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.SemiBold)
            Text("OPPORTUNITY INTELLIGENCE", color = Color(0xFF7FD1C9), fontSize = 12.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
            Text("SCHOLARSHIPS • RESEARCH • GLOBAL IMPACT", color = Color.White.copy(alpha = .78f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun MainScaffold(screen: Screen, onNavigate: (Screen) -> Unit, content: @Composable (PaddingValues, Screen) -> Unit) {
    data class NavItem(
        val screen: Screen,
        val label: String,
        val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
        val icon: androidx.compose.ui.graphics.vector.ImageVector
    )
    val tabs = listOf(
        NavItem(Screen.HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home),
        NavItem(Screen.DISCOVER, "Explore", Icons.Filled.TravelExplore, Icons.Outlined.TravelExplore),
        NavItem(Screen.RESEARCH, "Research", Icons.Filled.School, Icons.Outlined.School),
        NavItem(Screen.TRACKER, "Saved", Icons.Filled.Bookmark, Icons.Outlined.BookmarkBorder),
        NavItem(Screen.PROFILE, "Profile", Icons.Filled.Person, Icons.Outlined.Person)
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Surface(
                modifier = Modifier.navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp),
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(28.dp),
                shadowElevation = 12.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(.05f))
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    tabs.forEach { item ->
                        val selected = screen == item.screen
                        Column(
                            modifier = Modifier.width(62.dp).clip(RoundedCornerShape(20.dp)).clickable { onNavigate(item.screen) }.padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (selected) MaterialTheme.colorScheme.primary.copy(.12f) else Color.Transparent
                            ) {
                                Icon(
                                    if (selected) item.selectedIcon else item.icon,
                                    item.label,
                                    modifier = Modifier.padding(7.dp).size(if (selected) 23.dp else 21.dp),
                                    tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.38f)
                                )
                            }
                            AnimatedVisibility(selected) {
                                Text(item.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 1.dp))
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                (fadeIn(tween(180)) + slideInHorizontally(tween(240)) { it / 10 }) togetherWith
                    (fadeOut(tween(130)) + slideOutHorizontally(tween(200)) { -it / 14 })
            },
            label = "pageTransition"
        ) { target -> content(padding, target) }
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineSmall)
            subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f), modifier = Modifier.padding(top = 3.dp)) }
        }
        trailing?.invoke()
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    profile: UserProfile,
    settings: SettingsState,
    opportunities: List<Opportunity>,
    tracker: List<TrackerItem>,
    onDiscover: () -> Unit,
    onResearch: () -> Unit,
    onCountries: () -> Unit,
    onStories: () -> Unit,
    unreadNotifications: Int,
    onNotifications: () -> Unit,
    onRefresh: () -> Unit,
    onOpenWeb: (String) -> Unit,
    onOpenExternal: (String) -> Unit,
    onOpportunity: (Opportunity) -> Unit
) {
    val scored = remember(profile, opportunities) { opportunities.map { MatchEngine.score(profile, it) }.sortedByDescending { it.score } }
    val feed = remember(profile, opportunities) { HomeFeedBuilder.build(profile, opportunities) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 36.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AkademiWordmark(compact = true, modifier = Modifier.weight(1f))
                BadgedBox(
                    badge = {
                        if (unreadNotifications > 0) {
                            Badge(containerColor = MaterialTheme.colorScheme.error) {
                                Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString())
                            }
                        }
                    }
                ) {
                    Surface(
                        modifier = Modifier.clip(CircleShape).clickable(onClick = onNotifications),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(.10f)
                    ) {
                        Icon(
                            if (unreadNotifications > 0) Icons.Filled.Notifications else Icons.Outlined.Notifications,
                            "Notifications",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(10.dp).size(20.dp)
                        )
                    }
                }
            }
        }
        item { HomeProfileHero(profile, settings) }
        item {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("${scored.count { it.score >= 70 }}", "Strong matches", Modifier.weight(1f))
                StatCard("${opportunities.size}", "Live radar", Modifier.weight(1f))
                StatCard("${tracker.size}", "In tracker", Modifier.weight(1f))
            }
        }
        item { SectionTitle("Explore your route") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                item { TravelActionCard("Opportunities", "Funding worldwide", Icons.Outlined.FlightTakeoff, onDiscover) }
                item { TravelActionCard("Professors", "Research people", Icons.Outlined.Groups, onResearch) }
                item { TravelActionCard("Countries", "Study + stay paths", Icons.Outlined.Public, onCountries) }
                item { TravelActionCard("Stories", "How people got funded", Icons.Outlined.PlayCircle, onStories) }
            }
        }
        if (profile.preferredCountries.isNotEmpty()) {
            item { SectionTitle("Countries on your radar") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(profile.preferredCountries.toList()) { country ->
                        CountryMiniCard(country, onCountries)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 10.dp, top = 30.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Akademi Pulse", style = MaterialTheme.typography.titleLarge)
                    Text("Fresh opportunities, advice and videos for your profile", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 2.dp))
                }
                IconButton(onClick = onRefresh) { Icon(Icons.Outlined.Refresh, "Refresh feed", tint = MaterialTheme.colorScheme.primary) }
            }
        }
        items(feed, key = { it.id }) { item ->
            HomeFeedCard(
                item = item,
                opportunity = opportunities.firstOrNull { it.id == item.opportunityId },
                onOpportunity = onOpportunity,
                onOpenWeb = onOpenWeb,
                onOpenExternal = onOpenExternal
            )
        }
        item {
            InfoBanner(
                "Your feed changes with your profile",
                "Update your degree, CGPA, interests, preferred countries or target level and Akademi re-ranks opportunities, research directions and professor searches around you."
            )
        }
    }
}


@Composable
private fun NotificationCenterScreen(
    settings: SettingsState,
    notifications: List<AkademiInboxNotification>,
    opportunities: List<Opportunity>,
    onBack: () -> Unit,
    onMarkAllRead: () -> Unit,
    onClear: () -> Unit,
    onNotification: (AkademiInboxNotification) -> Unit
) {
    var unreadOnly by rememberSaveable { mutableStateOf(false) }
    val visible = remember(notifications, unreadOnly) {
        if (unreadOnly) notifications.filter { !it.isRead } else notifications
    }
    val unreadCount = notifications.count { !it.isRead }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 34.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Outlined.ArrowBack, "Back")
                }
                Column(Modifier.weight(1f).padding(start = 4.dp)) {
                    Text("Notifications", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        if (unreadCount == 0) "You're all caught up" else "$unreadCount unread update${if (unreadCount == 1) "" else "s"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(.56f)
                    )
                }
                if (notifications.isNotEmpty()) {
                    IconButton(onClick = onClear) {
                        Icon(Icons.Outlined.DeleteSweep, "Clear notifications", tint = MaterialTheme.colorScheme.onSurface.copy(.52f))
                    }
                }
            }
        }

        item {
            ElevatedCard(
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 5.dp)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = if (settings.notifications) MaterialTheme.colorScheme.primary.copy(.12f) else MaterialTheme.colorScheme.error.copy(.10f)
                    ) {
                        Icon(
                            if (settings.notifications) Icons.Filled.NotificationsActive else Icons.Outlined.NotificationsOff,
                            null,
                            tint = if (settings.notifications) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(10.dp).size(22.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (settings.notifications) "Akademi alerts are active" else "Akademi alerts are paused",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            if (settings.notifications) "Strong matches and tracked deadlines appear here and can also reach your device." else "Turn notifications back on in Settings when you want match and deadline alerts.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !unreadOnly,
                    onClick = { unreadOnly = false },
                    label = { Text("All") },
                    leadingIcon = if (!unreadOnly) {{ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }} else null
                )
                FilterChip(
                    selected = unreadOnly,
                    onClick = { unreadOnly = true },
                    label = { Text("Unread") },
                    leadingIcon = if (unreadOnly) {{ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }} else null
                )
                Spacer(Modifier.weight(1f))
                if (unreadCount > 0) {
                    TextButton(onClick = onMarkAllRead) { Text("Mark all read") }
                }
            }
        }

        if (visible.isEmpty()) {
            item {
                ElevatedCard(
                    Modifier.padding(horizontal = 20.dp, vertical = 18.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        SmartImage(VisualLibrary.forHomeTip("notifications-empty"), Modifier.fillMaxWidth().height(180.dp))
                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                if (unreadOnly) "No unread notifications" else "Nothing new yet",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                if (unreadOnly) "Switch to All to revisit earlier alerts." else "When Akademi finds a strong match or a tracked deadline gets close, it will appear here.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                                modifier = Modifier.padding(top = 5.dp)
                            )
                        }
                    }
                }
            }
        } else {
            items(visible, key = { it.id }) { notice ->
                val opportunity = opportunities.firstOrNull { it.id == notice.opportunityId }
                NotificationInboxCard(
                    notice = notice,
                    opportunity = opportunity,
                    onClick = { onNotification(notice) }
                )
            }
        }
    }
}

@Composable
private fun NotificationInboxCard(
    notice: AkademiInboxNotification,
    opportunity: Opportunity?,
    onClick: () -> Unit
) {
    val accent = when (notice.type) {
        "DEADLINE" -> MaterialTheme.colorScheme.error
        "MATCH" -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondary
    }
    ElevatedCard(
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 7.dp).fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (notice.isRead) 3.dp else 7.dp)
    ) {
        Column {
            if (opportunity != null) {
                Box(Modifier.fillMaxWidth().height(128.dp)) {
                    SmartImage(VisualLibrary.forOpportunity(opportunity), Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.48f)))))
                    Surface(
                        modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(.94f)
                    ) {
                        Row(Modifier.padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (notice.type == "DEADLINE") Icons.Outlined.Schedule else Icons.Outlined.Star,
                                null,
                                tint = accent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(if (notice.type == "DEADLINE") "Deadline" else "Match", style = MaterialTheme.typography.labelSmall, color = accent)
                        }
                    }
                    if (!notice.isRead) {
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(12.dp).size(10.dp).clip(CircleShape).background(MaterialTheme.colorScheme.error)
                        )
                    }
                    Text(
                        opportunity.country,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White,
                        modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
                    )
                }
            }
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                if (opportunity == null) {
                    Surface(shape = CircleShape, color = accent.copy(.11f)) {
                        Icon(
                            if (notice.type == "DEADLINE") Icons.Outlined.Schedule else Icons.Outlined.Notifications,
                            null,
                            tint = accent,
                            modifier = Modifier.padding(9.dp).size(20.dp)
                        )
                    }
                    Spacer(Modifier.width(11.dp))
                }
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            notice.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = if (notice.isRead) FontWeight.Medium else FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            notificationAge(notice.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(.42f),
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                    Text(
                        notice.body,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(.62f),
                        modifier = Modifier.padding(top = 4.dp),
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (opportunity != null) {
                        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("View opportunity", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Icon(Icons.Outlined.ArrowForward, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 4.dp).size(15.dp))
                        }
                    } else if (!notice.isRead) {
                        Text("Tap to mark as read", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 9.dp))
                    }
                }
            }
        }
    }
}

private fun notificationAge(createdAt: Long): String {
    val minutes = ((System.currentTimeMillis() - createdAt).coerceAtLeast(0L) / 60_000L).toInt()
    return when {
        minutes < 1 -> "now"
        minutes < 60 -> "${minutes}m"
        minutes < 1_440 -> "${minutes / 60}h"
        minutes < 10_080 -> "${minutes / 1_440}d"
        else -> "${minutes / 10_080}w"
    }
}

@Composable
private fun HomeProfileHero(profile: UserProfile, settings: SettingsState) {
    val visual = VisualLibrary.forHero(profile)
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp).fillMaxWidth(),
        shape = RoundedCornerShape(30.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 10.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Box(Modifier.fillMaxWidth().height(292.dp)) {
            SmartImage(visual, Modifier.fillMaxSize())
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(.08f), Color.Transparent, Color.Black.copy(.70f))
                    )
                )
            )
            Surface(
                modifier = Modifier.align(Alignment.TopEnd).padding(14.dp),
                shape = CircleShape,
                color = Color.White.copy(.92f),
                shadowElevation = 5.dp
            ) {
                Icon(Icons.Outlined.FlightTakeoff, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(9.dp).size(20.dp))
            }
            Row(
                Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(18.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                Surface(
                    modifier = Modifier.size(74.dp),
                    shape = CircleShape,
                    color = Color.White,
                    border = BorderStroke(3.dp, Color.White),
                    shadowElevation = 8.dp
                ) {
                    if (profile.profileImagePath.isNotBlank()) {
                        SmartImage(profile.profileImagePath, Modifier.fillMaxSize().clip(CircleShape))
                    } else {
                        Box(
                            Modifier.fillMaxSize().background(Brush.linearGradient(accentGradient(settings.accent))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(profile.name.trim().take(1).ifBlank { "A" }.uppercase(), color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        profile.name.ifBlank { "Your Akademi profile" },
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White
                    )
                    Text(
                        profile.headline.ifBlank { "Postgraduate opportunity explorer" },
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(.84f),
                        maxLines = 2
                    )
                    val cgpa = if (profile.cgpa > 0.0) "${profile.cgpa}/${profile.cgpaScale}" else "Add CGPA"
                    Text(
                        "${profile.degree.ifBlank { "Add degree" }} • $cgpa • ${profile.targetLevel}",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(.92f),
                        modifier = Modifier.padding(top = 5.dp)
                    )
                }
            }
        }
        Surface(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            shape = RoundedCornerShape(18.dp),
            color = Color(0xFFF7F9FC),
            border = BorderStroke(1.dp, Color(0xFFE9EDF4))
        ) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Search, null, tint = MaterialTheme.colorScheme.onSurface.copy(.42f), modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(9.dp))
                Text("Where do you want your degree to take you?", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.55f), modifier = Modifier.weight(1f))
                Surface(shape = RoundedCornerShape(11.dp), color = MaterialTheme.colorScheme.primary) {
                    Icon(Icons.Outlined.ArrowForward, null, tint = Color.White, modifier = Modifier.padding(7.dp).size(17.dp))
                }
            }
        }
    }
}

@Composable
private fun TravelActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    val visual = remember(title) {
        when (title) {
            "Opportunities" -> VisualLibrary.all[22]
            "Professors" -> VisualLibrary.all[14]
            "Countries" -> VisualLibrary.all[23]
            "Stories" -> VisualLibrary.all[9]
            else -> VisualLibrary.generic(title)
        }
    }
    ElevatedCard(
        modifier = Modifier.width(158.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 5.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(92.dp)) {
                SmartImage(visual, Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.35f)))))
                Surface(modifier = Modifier.align(Alignment.TopStart).padding(9.dp), shape = CircleShape, color = Color.White.copy(.92f)) {
                    Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(7.dp).size(18.dp))
                }
            }
            Column(Modifier.padding(horizontal = 13.dp, vertical = 12.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.56f), modifier = Modifier.padding(top = 2.dp), maxLines = 1)
            }
        }
    }
}


@Composable
private fun CountryMiniCard(country: String, onClick: () -> Unit) {
    ElevatedCard(
        modifier = Modifier.width(136.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            SmartImage(VisualLibrary.forCountry(country), Modifier.fillMaxWidth().height(86.dp))
            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.LocationOn, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(4.dp))
                Text(country, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun HomeFeedCard(
    item: HomeFeedItem,
    opportunity: Opportunity?,
    onOpportunity: (Opportunity) -> Unit,
    onOpenWeb: (String) -> Unit,
    onOpenExternal: (String) -> Unit
) {
    var expanded by rememberSaveable(item.id) { mutableStateOf(false) }
    val visual = item.imageUrl.ifBlank { VisualLibrary.generic(item.id) }
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp, vertical = 10.dp).fillMaxWidth()
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(26.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 9.dp else 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(if (expanded) 224.dp else 176.dp)) {
                SmartImage(visual, Modifier.fillMaxSize(), fallbackSource = opportunity?.let { VisualLibrary.fallbackForOpportunity(it) } ?: VisualLibrary.generic(item.id))
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.50f)))))
                Surface(
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp),
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(.93f)
                ) {
                    Text(item.badge, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                }
                if (item.type == "video") {
                    Surface(modifier = Modifier.align(Alignment.Center), shape = CircleShape, color = Color.White.copy(.94f), shadowElevation = 8.dp) {
                        Icon(Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(14.dp).size(28.dp))
                    }
                }
                Text(item.source, style = MaterialTheme.typography.labelMedium, color = Color.White, modifier = Modifier.align(Alignment.BottomStart).padding(14.dp))
            }
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Text(item.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.onSurface.copy(.40f))
                }
                Text(item.body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(.66f), maxLines = if (expanded) 8 else 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                AnimatedVisibility(expanded) {
                    Column(Modifier.padding(top = 12.dp)) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.07f))
                        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (opportunity != null) {
                                Button(onClick = { onOpportunity(opportunity) }, modifier = Modifier.weight(1f)) { Text("View inside") }
                                OutlinedButton(onClick = { onOpenExternal(opportunity.sourceUrl) }, modifier = Modifier.weight(1f)) { Icon(Icons.Outlined.OpenInNew, null, Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text("Source") }
                            } else if (item.url.isNotBlank()) {
                                Button(onClick = { onOpenWeb(item.url) }, modifier = Modifier.weight(1f)) { Text(if (item.type == "video") "Watch inside" else "Open inside") }
                                OutlinedButton(onClick = { onOpenExternal(item.url) }, modifier = Modifier.weight(1f)) { Text("External") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier, shape = RoundedCornerShape(18.dp), elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(.62f), modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable private fun QuickAction(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    ElevatedCard(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(18.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f), maxLines = 2)
        }
    }
}

@Composable private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 12.dp))
}

@Composable
private fun DiscoverScreen(
    modifier: Modifier, profile: UserProfile, opportunities: List<Opportunity>, remoteMessage: String?, onRefresh: () -> Unit,
    onOpportunity: (Opportunity) -> Unit, onOpenExternal: (String) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var level by rememberSaveable { mutableStateOf("All") }
    var funding by rememberSaveable { mutableStateOf("All") }
    val filtered = remember(query, level, funding, opportunities, profile) {
        opportunities.filter { o ->
            (query.isBlank() || (o.title + o.provider + o.country + o.field).contains(query, true)) &&
                (level == "All" || o.level.contains(level, true)) &&
                (funding == "All" || o.funding.contains(funding, true))
        }.map { MatchEngine.score(profile, it) }.sortedByDescending { it.score }
    }
    Column(modifier.fillMaxSize()) {
        PageHeader("Explore", "Find your next postgraduate destination") {
            FilledIconButton(onClick = onRefresh, colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary.copy(.10f), contentColor = MaterialTheme.colorScheme.primary)) {
                Icon(Icons.Outlined.Refresh, "Refresh")
            }
        }
        Surface(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(18.dp),
            shadowElevation = 2.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(.06f))
        ) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                leadingIcon = { Icon(Icons.Outlined.Search, null) }, placeholder = { Text("Search field, country, scholarship, PhD…") },
                trailingIcon = { Icon(Icons.Outlined.Tune, null, tint = MaterialTheme.colorScheme.primary) },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent)
            )
        }
        Text("Categories", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp))
        Row(Modifier.padding(horizontal = 20.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Master's", "PhD").forEach { v -> FilterChip(selected = level == v, onClick = { level = v }, label = { Text(v) }) }
            listOf("All", "Fully", "Salary", "Partial").forEach { v -> FilterChip(selected = funding == v, onClick = { funding = v }, label = { Text(if (v == "All") "Any funding" else v) }) }
        }
        remoteMessage?.let { Text(it, Modifier.padding(horizontal = 20.dp, vertical = 6.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.58f)) }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("For your profile", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Text("${filtered.size} results", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(filtered, key = { it.opportunity.id }) { s ->
                OpportunityCard(s, onViewDetails = { onOpportunity(s.opportunity) }, onExternal = { onOpenExternal(s.opportunity.sourceUrl) })
            }
        }
    }
}

@Composable
private fun OpportunityCard(s: ScoredOpportunity, onViewDetails: () -> Unit, onExternal: () -> Unit) {
    val o = s.opportunity
    var expanded by rememberSaveable(o.id) { mutableStateOf(false) }
    val visual = remember(o.id, o.imageUrl) { VisualLibrary.forOpportunity(o) }
    val fallbackVisual = remember(o.id) { VisualLibrary.fallbackForOpportunity(o) }
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp, vertical = 9.dp).fillMaxWidth()
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(26.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 9.dp else 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(if (expanded) 224.dp else 176.dp)) {
                SmartImage(visual, Modifier.fillMaxSize(), fallbackSource = fallbackVisual)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.48f)))))
                Surface(modifier = Modifier.align(Alignment.TopStart).padding(12.dp), shape = RoundedCornerShape(50), color = Color.White.copy(.94f)) {
                    Text(o.funding, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                }
                Surface(modifier = Modifier.align(Alignment.TopEnd).padding(12.dp), shape = CircleShape, color = Color.White.copy(.95f), shadowElevation = 5.dp) {
                    Column(Modifier.size(52.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("${s.score}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        Text("MATCH", fontSize = 7.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f), fontWeight = FontWeight.Bold)
                    }
                }
                Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
                    Text(o.country, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.92f))
                    Text(o.provider, style = MaterialTheme.typography.bodySmall, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
            Column(Modifier.padding(16.dp)) {
                Text(o.title, style = MaterialTheme.typography.titleMedium)
                Row(Modifier.padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    SmallMeta(Icons.Outlined.School, o.level)
                    SmallMeta(Icons.Outlined.Event, o.deadline)
                }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(o.status, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary, modifier = Modifier.weight(1f))
                    Text(if (expanded) "Less" else "Quick view", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                }
                AnimatedVisibility(expanded) {
                    Column(Modifier.padding(top = 12.dp)) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.07f))
                        Text(o.aiSummary.ifBlank { o.summary }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(.68f), modifier = Modifier.padding(top = 12.dp))
                        if (s.reasons.isNotEmpty()) {
                            Text("Why it matches", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
                            s.reasons.take(3).forEach { reason -> CheckRow(reason) }
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onViewDetails, modifier = Modifier.weight(1f)) { Text("View inside") }
                            OutlinedButton(onClick = onExternal, modifier = Modifier.weight(1f)) { Icon(Icons.Outlined.OpenInNew, null, Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text("Source") }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun SmallMeta(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurface.copy(.55f))
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun OpportunityDetailScreen(
    scored: ScoredOpportunity?,
    tracked: Boolean,
    profile: UserProfile,
    settings: SettingsState,
    onBack: () -> Unit,
    onOpenInside: () -> Unit,
    onOpenExternal: () -> Unit,
    onApplyInside: () -> Unit,
    onTrack: () -> Unit
) {
    if (scored == null) return
    val o = scored.opportunity
    val visual = remember(o.id, o.imageUrl) { VisualLibrary.forOpportunity(o) }
    val fallbackVisual = remember(o.id) { VisualLibrary.fallbackForOpportunity(o) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val keyStore = remember { SecureGeminiKeyStore(context) }
    val aiCache = remember { AiInsightCache(context) }
    val scope = rememberCoroutineScope()
    var aiInsight by remember(o.id, settings.aiModel) {
        mutableStateOf(if (settings.aiCacheEnabled) aiCache.get(o.id, settings.aiModel) else null)
    }
    var aiLoading by remember(o.id) { mutableStateOf(false) }
    var aiMessage by remember(o.id) { mutableStateOf<String?>(null) }
    var aiQuestion by rememberSaveable(o.id) { mutableStateOf("") }
    var aiAnswer by remember(o.id) { mutableStateOf<String?>(null) }
    var questionLoading by remember(o.id) { mutableStateOf(false) }
    val aiConfigured = keyStore.hasKey()

    Scaffold(
        topBar = {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }
                Text("Opportunity details", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onOpenExternal) { Icon(Icons.Outlined.OpenInNew, "Open externally") }
            }
        }
    ) { p ->
        LazyColumn(Modifier.padding(p).fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp)) {
            item {
                ElevatedCard(
                    Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    shape = RoundedCornerShape(28.dp),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(Modifier.fillMaxWidth().height(228.dp)) {
                        SmartImage(visual, Modifier.fillMaxSize(), fallbackSource = fallbackVisual)
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.52f)))))
                        Surface(modifier = Modifier.align(Alignment.TopEnd).padding(12.dp), shape = CircleShape, color = Color.White.copy(.94f)) {
                            Icon(if (tracked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(9.dp).size(20.dp))
                        }
                        Column(Modifier.align(Alignment.BottomStart).padding(15.dp)) {
                            Text(o.country, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.88f))
                            Text(o.provider, style = MaterialTheme.typography.titleSmall, color = Color.White)
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = {}, label = { Text(o.funding.uppercase(), fontSize = 10.sp) })
                    if (o.verified) AssistChip(onClick = {}, leadingIcon = { Icon(Icons.Filled.Verified, null, Modifier.size(15.dp)) }, label = { Text("SOURCE CHECKED", fontSize = 10.sp) })
                }
            }
            item { Text(o.title, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 32.sp) }
            item { Text("${o.provider} • ${o.country}", color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 5.dp)) }
            if (o.lastChecked.isNotBlank()) item { Text("Last checked: ${o.lastChecked}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.48f), modifier = Modifier.padding(top = 3.dp)) }
            item {
                ElevatedCard(Modifier.fillMaxWidth().padding(top = 18.dp), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Your match strength", fontWeight = FontWeight.SemiBold)
                                Text(matchLabel(scored.score), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                            Text("${scored.score}/100", fontWeight = FontWeight.Bold, fontSize = 24.sp)
                        }
                        Spacer(Modifier.height(14.dp))
                        LinearProgressIndicator({ scored.score / 100f }, Modifier.fillMaxWidth())
                        Text("Profile-fit score, not an acceptance probability.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.52f), modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
            item { SectionTitleNoIndent("Why Akademi matched it") }
            items(scored.reasons) { reason -> CheckRow(reason) }

            if (o.aiSummary.isNotBlank()) {
                item { SectionTitleNoIndent("Akademi AI source brief") }
                item {
                    ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text("Collector-enriched summary", fontWeight = FontWeight.Bold)
                            }
                            Text(o.aiSummary, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 10.dp))
                            if (o.aiFundingNotes.isNotBlank()) Text("Funding note: ${o.aiFundingNotes}", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                            if (o.aiUpdatedAt.isNotBlank()) Text("AI checked ${o.aiUpdatedAt} • ${o.aiModel}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.48f), modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                if (o.aiRequirements.isNotEmpty()) {
                    item { Text("Important requirements", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(o.aiRequirements) { CheckRow(it, checked = false) }
                }
                if (o.aiSelectionSignals.isNotEmpty()) {
                    item { Text("What appears to matter", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(o.aiSelectionSignals) { CheckRow(it) }
                }
                if (o.aiRisks.isNotEmpty()) {
                    item { Text("Watch-outs", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(o.aiRisks) { CheckRow(it, checked = false) }
                }
                if (o.aiActions.isNotEmpty()) {
                    item { Text("Application strategy", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(o.aiActions) { step -> NumberedInfoRow(step, o.aiActions.indexOf(step) + 1) }
                }
            }

            item { SectionTitleNoIndent("Personalized Gemini analysis") }
            item {
                ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Psychology, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Akademi Intelligence", fontWeight = FontWeight.Bold)
                                Text(settings.aiModel, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.52f))
                            }
                        }
                        when {
                            !settings.aiEnabled -> Text("AI is optional and currently off. Enable Gemini in Settings to get a profile-specific review.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 10.dp))
                            !aiConfigured -> Text("Gemini is enabled, but no API key is stored. Add your key in Settings → Gemini AI.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 10.dp))
                            aiInsight == null -> {
                                Text("Analyze this opportunity against your saved profile. Results can be cached locally so reopening the card does not consume another API call.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 10.dp))
                                Button(
                                    onClick = {
                                        val key = keyStore.load()
                                        if (key.isNullOrBlank()) aiMessage = "Gemini API key could not be read. Re-save it in Settings."
                                        else scope.launch {
                                            aiLoading = true; aiMessage = null
                                            GeminiClient.analyzeOpportunity(key, settings.aiModel, profile, scored)
                                                .onSuccess {
                                                    aiInsight = it
                                                    if (settings.aiCacheEnabled) aiCache.put(o.id, it)
                                                }
                                                .onFailure { aiMessage = it.message ?: "Gemini analysis failed" }
                                            aiLoading = false
                                        }
                                    },
                                    enabled = !aiLoading,
                                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                                ) {
                                    if (aiLoading) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)) }
                                    Text(if (aiLoading) "Analyzing…" else "Analyze with Gemini")
                                }
                            }
                        }
                        aiMessage?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
                    }
                }
            }
            aiInsight?.let { insight ->
                item { Text(insight.headline, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 14.dp)) }
                item { Text(insight.summary, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 6.dp)) }
                if (insight.strengths.isNotEmpty()) {
                    item { Text("Your strengths", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(insight.strengths) { CheckRow(it) }
                }
                if (insight.risks.isNotEmpty()) {
                    item { Text("Possible weaknesses / unknowns", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(insight.risks) { CheckRow(it, checked = false) }
                }
                if (insight.actions.isNotEmpty()) {
                    item { Text("What to do next", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(insight.actions) { step -> NumberedInfoRow(step, insight.actions.indexOf(step) + 1) }
                }
                if (insight.questionsToVerify.isNotEmpty()) {
                    item { Text("Verify on the official source", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp)) }
                    items(insight.questionsToVerify) { CheckRow(it, checked = false) }
                }
            }

            if (settings.aiEnabled && aiConfigured) {
                item {
                    OutlinedTextField(
                        value = aiQuestion,
                        onValueChange = { aiQuestion = it },
                        label = { Text("Ask Akademi about this opportunity") },
                        placeholder = { Text("e.g. What should my motivation letter emphasize?") },
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                        minLines = 2,
                        maxLines = 5
                    )
                    Button(
                        onClick = {
                            val key = keyStore.load()
                            if (!key.isNullOrBlank() && aiQuestion.isNotBlank()) scope.launch {
                                questionLoading = true; aiAnswer = null
                                GeminiClient.askOpportunity(key, settings.aiModel, profile, scored, aiQuestion)
                                    .onSuccess { aiAnswer = it }
                                    .onFailure { aiAnswer = "Gemini request failed: ${it.message ?: "unknown error"}" }
                                questionLoading = false
                            }
                        },
                        enabled = aiQuestion.isNotBlank() && !questionLoading,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) {
                        if (questionLoading) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)) }
                        Text(if (questionLoading) "Thinking…" else "Ask Gemini")
                    }
                }
                aiAnswer?.let { answer ->
                    item {
                        Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Text(answer, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(15.dp))
                        }
                    }
                }
            }

            item { SectionTitleNoIndent("Major details") }
            item {
                DetailRow("Type", o.opportunityType)
                DetailRow("Level", o.level)
                DetailRow("Field", o.field)
                DetailRow("Country", o.country)
                DetailRow("Study mode", o.studyMode)
                DetailRow("Duration", o.duration)
                DetailRow("Start", o.startDate)
                DetailRow("Deadline", o.deadline)
                DetailRow("Status", o.status)
                DetailRow("Supervisor", o.requiresSupervisor)
                DetailRow("Application fee", o.applicationFee)
            }

            item { SectionTitleNoIndent("Funding & benefits") }
            item {
                DetailRow("Funding", o.funding)
                DetailRow("Tuition", o.tuitionCoverage)
                DetailRow("Stipend", o.stipend)
                DetailRow("Living support", o.livingAllowance)
                DetailRow("Travel", o.travelSupport)
            }
            if (o.benefits.isNotEmpty()) items(o.benefits) { CheckRow(it) }

            if (o.eligibility.isNotEmpty() || o.eligibleNationalities.isNotEmpty()) {
                item { SectionTitleNoIndent("Eligibility") }
                if (o.eligibleNationalities.isNotEmpty()) item { DetailRow("Nationality", o.eligibleNationalities.joinToString(", ")) }
                items(o.eligibility) { CheckRow(it, checked = false) }
            }

            item { SectionTitleNoIndent("Requirements") }
            if (o.requirements.isEmpty()) item { Text("No structured requirements extracted yet. Verify the original source before applying.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f)) }
            items(o.requirements) { CheckRow(it, checked = false) }
            if (o.languageRequirements.isNotEmpty()) {
                item { Text("Language", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp)) }
                items(o.languageRequirements) { CheckRow(it, checked = false) }
            }

            if (o.documents.isNotEmpty()) {
                item { SectionTitleNoIndent("Documents") }
                items(o.documents) { CheckRow(it, checked = false) }
            }
            if (o.howToApply.isNotEmpty()) {
                item { SectionTitleNoIndent("How to apply") }
                items(o.howToApply) { step -> NumberedInfoRow(step, o.howToApply.indexOf(step) + 1) }
            }
            if (o.selectionProcess.isNotEmpty()) {
                item { SectionTitleNoIndent("Selection process") }
                items(o.selectionProcess) { CheckRow(it, checked = false) }
            }

            item { SectionTitleNoIndent("About this opportunity") }
            item { Text(o.summary.ifBlank { "Akademi found this opportunity from its source network. Open the official source below for the original wording and final verification." }, color = MaterialTheme.colorScheme.onSurface.copy(.75f), lineHeight = 22.sp) }
            item {
                Spacer(Modifier.height(22.dp))
                Button(onClick = onTrack, enabled = !tracked, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) {
                    Icon(if (tracked) Icons.Filled.Check else Icons.Outlined.BookmarkAdd, null)
                    Spacer(Modifier.width(8.dp)); Text(if (tracked) "Already in tracker" else "Save & start application")
                }
                if (o.applicationUrl.isNotBlank()) {
                    Button(onClick = onApplyInside, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(50.dp), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Outlined.Send, null); Spacer(Modifier.width(8.dp)); Text("Open application page inside Akademi")
                    }
                }
                OutlinedButton(onClick = onOpenInside, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(50.dp), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Outlined.Language, null); Spacer(Modifier.width(8.dp)); Text("View original source inside Akademi")
                }
                TextButton(onClick = onOpenExternal, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Icon(Icons.Outlined.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text("Open original source in external browser")
                }
                Text("The official source is always the final authority for eligibility, deadlines and funding. AI analysis is advisory and may be wrong.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.5f), modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
            }
        }
    }
}

@Composable private fun NumberedInfoRow(text: String, number: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.12f)) {
            Text(number.toString(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
        }
        Spacer(Modifier.width(9.dp)); Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f), lineHeight = 19.sp)
    }
}

@Composable private fun SectionTitleNoIndent(text: String) = Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 28.dp, bottom = 12.dp))
@Composable private fun CheckRow(text: String, checked: Boolean = true) { Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) { Icon(if (checked) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked, null, tint = if (checked) Teal else MaterialTheme.colorScheme.onSurface.copy(.35f), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f)) } }
@Composable private fun DetailRow(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(label, Modifier.width(92.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f)); Text(value, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f)) } }
private fun matchLabel(score: Int) = when { score >= 85 -> "Excellent fit"; score >= 70 -> "Strong fit"; score >= 55 -> "Possible fit"; else -> "Needs review" }

@Composable
private fun ResearchScreen(
    modifier: Modifier,
    profile: UserProfile,
    onOpen: (String) -> Unit,
    onOpenExternal: (String) -> Unit,
    onStories: () -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize()) {
        PageHeader("Research", "Professors, papers and directions matched to your profile")
        TabRow(selectedTabIndex = tab) {
            Tab(tab == 0, onClick = { tab = 0 }, text = { Text("Professors") })
            Tab(tab == 1, onClick = { tab = 1 }, text = { Text("Directions") })
            Tab(tab == 2, onClick = { tab = 2 }, text = { Text("Stories") })
        }
        AnimatedContent(targetState = tab, label = "researchTabs", transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) }) { selectedTab ->
            Box(Modifier.fillMaxSize()) {
                when (selectedTab) {
                    0 -> ProfessorFinder(profile, onOpen, onOpenExternal)
                    1 -> ResearchDirections(profile, onOpen, onOpenExternal)
                    else -> StoryPreview(onStories)
                }
            }
        }
    }
}

@Composable
private fun ProfessorFinder(profile: UserProfile, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    val defaultTopic = profile.researchInterests.split(',').map { it.trim() }.firstOrNull { it.isNotBlank() }
        ?: profile.field.ifBlank { "postgraduate research" }
    var query by rememberSaveable { mutableStateOf(defaultTopic) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Search current OpenAlex publications to surface researchers working in any field you choose.") }
    var researchers by remember { mutableStateOf<List<Researcher>>(emptyList()) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                query, { query = it }, Modifier.weight(1f), singleLine = true,
                label = { Text("Research topic") }, placeholder = { Text("e.g. renewable energy, finance, genomics, AI") }, shape = RoundedCornerShape(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = {
                loading = true; message = "Searching current research…"
                scope.launch {
                    OpenAlexRepository.searchResearchers(query)
                        .onSuccess { researchers = it; message = "${it.size} researchers surfaced from publications related to your search." }
                        .onFailure { message = "Search failed: ${it.message}" }
                    loading = false
                }
            }) { Icon(Icons.Outlined.Search, "Search") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(message, Modifier.padding(horizontal = 20.dp, vertical = 7.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (researchers.isEmpty()) {
                item { InfoBanner("Search anything", "Akademi is not limited to one degree. Try your discipline, a specific research problem, methodology or interdisciplinary topic.") }
            }
            items(researchers, key = { it.id }) { r ->
                ProfessorCard(r, query, onOpen, onOpenExternal)
            }
        }
    }
}

@Composable
private fun ProfessorCard(r: Researcher, query: String, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    var expanded by rememberSaveable(r.id) { mutableStateOf(false) }
    val visual = remember(r.id, r.topics) { VisualLibrary.forResearcher(r) }
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp, vertical = 9.dp).fillMaxWidth()
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(26.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 9.dp else 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(if (expanded) 188.dp else 138.dp)) {
                SmartImage(visual, Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.42f)))))
                Surface(modifier = Modifier.align(Alignment.TopStart).padding(11.dp), shape = RoundedCornerShape(50), color = Color.White.copy(.93f)) {
                    Text("RESEARCH MATCH", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                }
                Surface(modifier = Modifier.align(Alignment.TopEnd).padding(11.dp), shape = CircleShape, color = Color.White.copy(.95f)) {
                    Column(Modifier.size(49.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("${r.fitScore}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        Text("FIT", fontSize = 7.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f), fontWeight = FontWeight.Bold)
                    }
                }
            }
            Column(Modifier.padding(16.dp)) {
                Text(r.name, style = MaterialTheme.typography.titleMedium)
                Text(r.institution, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.62f), maxLines = 2, modifier = Modifier.padding(top = 3.dp))
                if (r.country.isNotBlank()) {
                    Row(Modifier.padding(top = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Place, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(4.dp))
                        Text(r.country, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }
                if (r.topics.isNotEmpty()) {
                    Text(r.topics.take(3).joinToString(" • "), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 10.dp), color = MaterialTheme.colorScheme.onSurface.copy(.68f), maxLines = if (expanded) 4 else 2)
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (expanded) "Hide research preview" else "Expand researcher", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                    Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.primary)
                }
                AnimatedVisibility(expanded) {
                    Column(Modifier.padding(top = 10.dp)) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.07f))
                        Text("Why this person surfaced", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 13.dp))
                        Text("Their recent OpenAlex-indexed publications overlap with your search for “$query”. The image above is an Akademi research visual, not a portrait of this researcher. Verify current projects and supervision availability on official profiles.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.68f), modifier = Modifier.padding(top = 5.dp))
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip(onClick = {}, label = { Text("${r.worksCount} works") })
                            AssistChip(onClick = {}, label = { Text("${r.citedByCount} citations") })
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onOpen(r.openAlexUrl) }, modifier = Modifier.weight(1f)) { Text("Research inside") }
                            OutlinedButton(onClick = { onOpenExternal(r.openAlexUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (r.orcid.isNotBlank()) {
                                val orcidUrl = if (r.orcid.startsWith("http")) r.orcid else "https://orcid.org/${r.orcid}"
                                OutlinedButton(onClick = { onOpen(orcidUrl) }, modifier = Modifier.weight(1f)) { Text("ORCID") }
                            }
                            val linkedIn = "https://www.linkedin.com/search/results/people/?keywords=${Uri.encode(r.name + " " + r.institution)}"
                            OutlinedButton(onClick = { onOpenExternal(linkedIn) }, modifier = Modifier.weight(1f)) { Text("LinkedIn") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResearchDirections(profile: UserProfile, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    val dirs = remember(profile) { DirectionEngine.recommend(profile) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
        item { InfoBanner("Directions adapt to you", "These routes use your degree, field and interests. Update your profile and the recommendations change automatically.") }
        items(dirs, key = { it.title }) { d ->
            var expanded by rememberSaveable(d.title) { mutableStateOf(false) }
            val visual = remember(d.title, d.detail) { VisualLibrary.forDirection(d.title, d.detail) }
            ElevatedCard(
                Modifier.fillMaxWidth().padding(vertical = 9.dp)
                    .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
                    .clickable { expanded = !expanded },
                shape = RoundedCornerShape(26.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 9.dp else 4.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column {
                    Box(Modifier.fillMaxWidth().height(if (expanded) 190.dp else 142.dp)) {
                        SmartImage(visual, Modifier.fillMaxSize())
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.48f)))))
                        Surface(modifier = Modifier.align(Alignment.TopStart).padding(11.dp), shape = RoundedCornerShape(50), color = Color.White.copy(.94f)) {
                            Text(d.category.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                        }
                        Surface(modifier = Modifier.align(Alignment.TopEnd).padding(11.dp), shape = CircleShape, color = Color.White.copy(.95f)) {
                            Text("${d.fitScore}%", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                        }
                    }
                    Column(Modifier.padding(16.dp)) {
                        Text(d.title, style = MaterialTheme.typography.titleMedium)
                        Text(d.headline, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp))
                        Text(d.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.68f), modifier = Modifier.padding(top = 9.dp), maxLines = if (expanded) 8 else 3, overflow = TextOverflow.Ellipsis)
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (expanded) "Show less" else "See topics & research", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                            Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        AnimatedVisibility(expanded) {
                            Column(Modifier.padding(top = 8.dp)) {
                                Text("Example topics", style = MaterialTheme.typography.titleSmall)
                                d.exampleTopics.forEach { topic -> CheckRow(topic) }
                                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { onOpen(d.externalUrl) }, modifier = Modifier.weight(1f)) { Text("Explore inside") }
                                    OutlinedButton(onClick = { onOpenExternal(d.externalUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun StoryPreview(onStories: () -> Unit) {
    Column(Modifier.padding(20.dp)) {
        InfoBanner("Learn from real applicants", "Akademi keeps official requirements separate from anecdotal experience. Search winner stories, interviews and forum discussions, then verify requirements at the source.")
        Button(onClick = onStories, modifier = Modifier.fillMaxWidth()) { Text("Open success-story hub") }
    }
}

@Composable
private fun SuccessStoriesScreen(onBack: () -> Unit, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    Scaffold(topBar = { SimpleBackBar("Success stories & application intelligence", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
            item { InfoBanner("Official facts vs personal experience", "Forum, YouTube and blog stories are useful for strategy, but Akademi treats them as anecdotal and keeps official programme requirements separate.") }
            item { StoryLink("Erasmus Mundus student stories", "Search YouTube for detailed application walkthroughs", "https://www.youtube.com/results?search_query=Erasmus+Mundus+scholarship+international+student+experience", onOpen, onOpenExternal) }
            item { StoryLink("DAAD scholarship experiences", "Find interviews and applicant processes", "https://www.youtube.com/results?search_query=DAAD+scholarship+international+student+experience", onOpen, onOpenExternal) }
            item { StoryLink("Commonwealth scholarship experiences", "Winner advice, essays and interviews", "https://www.youtube.com/results?search_query=Commonwealth+scholarship+winner+experience", onOpen, onOpenExternal) }
            item { StoryLink("Reddit scholarship discussions", "Search community threads and compare multiple perspectives", "https://www.google.com/search?q=site%3Areddit.com+scholarship+masters+phd+international+student+experience", onOpen, onOpenExternal) }
            item { StoryLink("Motivation-letter research", "Search scholarship-specific guidance rather than generic templates", "https://www.google.com/search?q=scholarship+motivation+letter+official+university+guidance", onOpen, onOpenExternal) }
        }
    }
}

@Composable private fun StoryLink(title: String, body: String, url: String, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    var expanded by rememberSaveable(title) { mutableStateOf(false) }
    val visual = remember(title) { VisualLibrary.forStory(title) }
    ElevatedCard(
        Modifier.fillMaxWidth().padding(vertical = 9.dp).animateContentSize().clickable { expanded = !expanded },
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 8.dp else 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(if (expanded) 186.dp else 132.dp)) {
                SmartImage(visual, Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.45f)))))
                Surface(modifier = Modifier.align(Alignment.Center), shape = CircleShape, color = Color.White.copy(.94f), shadowElevation = 6.dp) {
                    Icon(Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(11.dp).size(24.dp))
                }
            }
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(title, style = MaterialTheme.typography.titleSmall)
                        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.62f), maxLines = if (expanded) 4 else 2, modifier = Modifier.padding(top = 4.dp))
                    }
                    Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurface.copy(.42f))
                }
                AnimatedVisibility(expanded) {
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onOpen(url) }, modifier = Modifier.weight(1f)) { Text("Open inside") }
                        OutlinedButton(onClick = { onOpenExternal(url) }, modifier = Modifier.weight(1f)) { Text("External") }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackerScreen(modifier: Modifier, opportunities: List<Opportunity>, tracker: List<TrackerItem>, onTracker: (List<TrackerItem>) -> Unit, onOpen: (Opportunity) -> Unit) {
    Column(modifier.fillMaxSize()) {
        PageHeader("My tracker", "Plan, apply and follow up")
        val preparing = tracker.count { it.status == "Preparing" }; val applied = tracker.count { it.status == "Applied" }; val interview = tracker.count { it.status == "Interview" }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("$preparing", "Preparing", Modifier.weight(1f)); StatCard("$applied", "Applied", Modifier.weight(1f)); StatCard("$interview", "Interview", Modifier.weight(1f))
        }
        if (tracker.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Outlined.Bookmarks, null, Modifier.size(52.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(14.dp)); Text("Nothing saved yet", fontWeight = FontWeight.Bold); Text("Open an opportunity and tap “Save & start application”.", textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)) {
                items(tracker, key = { it.opportunityId }) { t ->
                    val o = opportunities.firstOrNull { it.id == t.opportunityId }
                    if (o != null) TrackerCard(o, t, onChange = { changed -> onTracker(tracker.map { if (it.opportunityId == t.opportunityId) changed else it }) }, onRemove = { onTracker(tracker.filterNot { it.opportunityId == t.opportunityId }) }, onOpen = { onOpen(o) })
                }
            }
        }
    }
}

@Composable private fun TrackerCard(o: Opportunity, t: TrackerItem, onChange: (TrackerItem) -> Unit, onRemove: () -> Unit, onOpen: () -> Unit) {
    val visual = remember(o.id, o.imageUrl) { VisualLibrary.forOpportunity(o) }
    val fallbackVisual = remember(o.id) { VisualLibrary.fallbackForOpportunity(o) }
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                SmartImage(visual, Modifier.size(78.dp).clip(RoundedCornerShape(17.dp)), fallbackSource = fallbackVisual)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(o.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(o.provider, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 3.dp))
                    Text(t.status, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 5.dp))
                }
                IconButton(onClick = onRemove) { Icon(Icons.Outlined.Delete, "Remove", tint = MaterialTheme.colorScheme.onSurface.copy(.38f)) }
            }
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 14.dp)) {
                LinearProgressIndicator({ t.progress / 100f }, Modifier.fillMaxWidth().padding(vertical = 7.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${t.progress}%", modifier = Modifier.width(45.dp), style = MaterialTheme.typography.labelMedium)
                    Slider(value = t.progress.toFloat(), onValueChange = { onChange(t.copy(progress = it.toInt())) }, valueRange = 0f..100f, steps = 9, modifier = Modifier.weight(1f))
                }
                Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Preparing", "Applied", "Interview", "Offer").forEach { status -> FilterChip(selected = t.status == status, onClick = { onChange(t.copy(status = status)) }, label = { Text(status, fontSize = 10.sp) }) }
                }
                TextButton(onClick = onOpen, contentPadding = PaddingValues(horizontal = 0.dp)) { Text("Open opportunity"); Spacer(Modifier.width(4.dp)); Icon(Icons.Outlined.ArrowForward, null, Modifier.size(15.dp)) }
            }
        }
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier, profile: UserProfile, settings: SettingsState, onProfile: (UserProfile) -> Unit, onSettings: () -> Unit, onCountries: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var editing by rememberSaveable { mutableStateOf(false) }
    var name by remember(profile.name) { mutableStateOf(profile.name) }
    var headline by remember(profile.headline) { mutableStateOf(profile.headline) }
    var nationality by remember(profile.nationality) { mutableStateOf(profile.nationality) }
    var degree by remember(profile.degree) { mutableStateOf(profile.degree) }
    var field by remember(profile.field) { mutableStateOf(profile.field) }
    var cgpa by remember(profile.cgpa) { mutableStateOf(profile.cgpa.toString()) }
    var cgpaScale by remember(profile.cgpaScale) { mutableStateOf(profile.cgpaScale.toString()) }
    var interests by remember(profile.researchInterests) { mutableStateOf(profile.researchInterests) }
    var publications by remember(profile.publications) { mutableStateOf(profile.publications.toString()) }
    var targetLevel by remember(profile.targetLevel) { mutableStateOf(profile.targetLevel) }
    var researchExperience by remember(profile.researchExperience) { mutableStateOf(profile.researchExperience) }
    var preferredCountries by remember(profile.preferredCountries) { mutableStateOf(profile.preferredCountries) }
    var fullFundingPreferred by remember(profile.fullFundingPreferred) { mutableStateOf(profile.fullFundingPreferred) }
    var prPriority by remember(profile.prPriority) { mutableIntStateOf(profile.prPriority) }

    fun keepUri(uri: Uri?, banner: Boolean) {
        if (uri == null) return
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        onProfile(if (banner) profile.copy(bannerImagePath = uri.toString()) else profile.copy(profileImagePath = uri.toString()))
    }

    val profilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> keepUri(uri, false) }
    val bannerPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> keepUri(uri, true) }

    Column(modifier.fillMaxSize()) {
        PageHeader("Profile", "Your profile personalizes the entire Akademi experience") { IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, "Settings") } }
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp)) {
            item { HomeProfileHero(profile, settings) }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { profilePicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Outlined.PhotoCamera, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Profile photo") }
                    OutlinedButton(onClick = { bannerPicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Outlined.Image, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Banner") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { onProfile(profile.copy(bannerImagePath = "", bannerStyle = (profile.bannerStyle + 1) % 5)) }) {
                        Icon(Icons.Outlined.AutoAwesome, null, Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Shuffle banner")
                    }
                    if (profile.profileImagePath.isNotBlank() || profile.bannerImagePath.isNotBlank()) {
                        TextButton(onClick = { onProfile(profile.copy(profileImagePath = "", bannerImagePath = "")) }) { Text("Clear images") }
                    }
                }
            }
            item { SectionTitleNoIndent("Academic profile") }
            item {
                if (editing) {
                    OutlinedTextField(name, { name = it }, label = { Text("Name / profile label") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(headline, { headline = it }, label = { Text("Headline") }, placeholder = { Text("e.g. Environmental scientist exploring funded MSc/PhD routes") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(nationality, { nationality = it }, label = { Text("Nationality") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(degree, { degree = it }, label = { Text("Degree / qualification") }, placeholder = { Text("Any field is supported") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(field, { field = it }, label = { Text("Main field") }, placeholder = { Text("e.g. Economics, Engineering, Botany, Computer Science") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(cgpa, { cgpa = it }, label = { Text("CGPA") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(cgpaScale, { cgpaScale = it }, label = { Text("Scale") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Text("Target level", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
                    Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("Master's", "PhD", "Both").forEach { option -> FilterChip(selected = targetLevel == option, onClick = { targetLevel = option }, label = { Text(option) }) }
                    }
                    Text("Preferred destinations", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
                    Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("Germany", "Canada", "Australia", "New Zealand", "Netherlands", "Ireland", "Sweden", "Finland", "Denmark", "United Kingdom", "United States").forEach { country ->
                            FilterChip(
                                selected = country in preferredCountries,
                                onClick = { preferredCountries = if (country in preferredCountries) preferredCountries - country else preferredCountries + country },
                                label = { Text(country) }
                            )
                        }
                    }
                    ToggleRow("Prioritize full funding", "Rank fully funded and salaried research routes more strongly", fullFundingPreferred) { fullFundingPreferred = it }
                    Text("Post-study stay / PR importance: $prPriority%", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Slider(value = prPriority.toFloat(), onValueChange = { prPriority = it.toInt() }, valueRange = 0f..100f, steps = 9)
                    OutlinedTextField(interests, { interests = it }, label = { Text("Research / study interests") }, placeholder = { Text("Separate several interests with commas") }, minLines = 3, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(publications, { publications = it }, label = { Text("Publications") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    ToggleRow("Research experience", "Include this signal in personalized guidance", researchExperience) { researchExperience = it }
                    Button(
                        onClick = {
                            val scale = cgpaScale.toDoubleOrNull()?.takeIf { it > 0 } ?: profile.cgpaScale
                            val grade = cgpa.toDoubleOrNull()?.coerceIn(0.0, scale) ?: profile.cgpa
                            onProfile(
                                profile.copy(
                                    name = name.trim().ifBlank { "My Profile" }, headline = headline.trim(), nationality = nationality.trim().ifBlank { "Nigeria" },
                                    degree = degree.trim(), field = field.trim(), cgpa = grade, cgpaScale = scale, targetLevel = targetLevel,
                                    researchInterests = interests.trim(), researchExperience = researchExperience, publications = publications.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                                    preferredCountries = preferredCountries, fullFundingPreferred = fullFundingPreferred, prPriority = prPriority
                                )
                            )
                            editing = false
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                    ) { Text("Save & re-personalize Akademi") }
                } else {
                    ProfileLine("Nationality", profile.nationality)
                    ProfileLine("Degree", profile.degree.ifBlank { "Not set" })
                    ProfileLine("Field", profile.field.ifBlank { "Not set" })
                    ProfileLine("CGPA", if (profile.cgpa > 0.0) "${profile.cgpa}/${profile.cgpaScale}" else "Not set")
                    ProfileLine("Target", profile.targetLevel)
                    ProfileLine("Countries", profile.preferredCountries.joinToString().ifBlank { "Any" })
                    ProfileLine("Funding", if (profile.fullFundingPreferred) "Full funding preferred" else "Any funding")
                    ProfileLine("Stay priority", "${profile.prPriority}%")
                    ProfileLine("Research", if (profile.researchExperience) "Experience added" else "Not added")
                    ProfileLine("Publications", profile.publications.toString())
                    ProfileLine("Interests", profile.researchInterests.ifBlank { "Not set" })
                    OutlinedButton(onClick = { editing = true }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Icon(Icons.Outlined.Edit, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Edit profile & CGPA") }
                }
            }
            item { SectionTitleNoIndent("Strategy") }
            item { SettingAction(Icons.Outlined.Public, "Country & stay-potential insights", "Expandable country profiles with official external sources", onCountries) }
            item { SettingAction(Icons.Outlined.Settings, "Settings", "Theme, lively color palettes, Gemini, notifications and browsing", onSettings) }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable private fun ProfileLine(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) { Text(label, Modifier.width(115.dp), color = MaterialTheme.colorScheme.onSurface.copy(.55f), style = MaterialTheme.typography.bodySmall); Text(value, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium) } }

@Composable
private fun CountryInsightsScreen(onBack: () -> Unit, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    Scaffold(topBar = { SimpleBackBar("Country insights", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
            item { InfoBanner("Study destination + long-term strategy", "Stay potential is a planning signal, not immigration advice. Expand each destination, then verify the current rules on the official immigration website.") }
            items(SeedData.countries, key = { it.country }) { c ->
                var expanded by rememberSaveable(c.country) { mutableStateOf(false) }
                val visual = remember(c.country) { VisualLibrary.forCountry(c.country) }
                ElevatedCard(
                    Modifier.fillMaxWidth().padding(vertical = 9.dp)
                        .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
                        .clickable { expanded = !expanded },
                    shape = RoundedCornerShape(26.dp),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 9.dp else 4.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        Box(Modifier.fillMaxWidth().height(if (expanded) 220.dp else 168.dp)) {
                            SmartImage(visual, Modifier.fillMaxSize())
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.58f)))))
                            Surface(modifier = Modifier.align(Alignment.TopEnd).padding(12.dp), shape = RoundedCornerShape(50), color = Color.White.copy(.94f)) {
                                Text("${c.stayPotential}/100 stay fit", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                            }
                            Column(Modifier.align(Alignment.BottomStart).padding(15.dp)) {
                                Text(c.country, style = MaterialTheme.typography.headlineSmall, color = Color.White)
                                Text(c.headline, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.86f), modifier = Modifier.padding(top = 2.dp))
                            }
                        }
                        Column(Modifier.padding(16.dp)) {
                            Text(c.detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(.68f), maxLines = if (expanded) 8 else 3, overflow = TextOverflow.Ellipsis)
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (expanded) "Hide destination profile" else "Explore destination", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                                Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.primary)
                            }
                            AnimatedVisibility(expanded) {
                                Column(Modifier.padding(top = 8.dp)) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.07f))
                                    Text("Akademi considers study options, your destination preferences and post-study planning. Immigration rules change, so the official source remains the final authority.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.55f), modifier = Modifier.padding(top = 12.dp))
                                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = { onOpen(c.officialUrl) }, modifier = Modifier.weight(1f)) { Text("View inside") }
                                        OutlinedButton(onClick = { onOpenExternal(c.officialUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    settings: SettingsState, onSettings: (SettingsState) -> Unit, remoteMessage: String?, onRefresh: (String?) -> Unit,
    onBack: () -> Unit, onReset: () -> Unit
) {
    var feed by remember(settings.liveFeedUrl) { mutableStateOf(settings.liveFeedUrl) }
    val settingsContext = androidx.compose.ui.platform.LocalContext.current
    val instantPushConfigured = remember { settingsContext.resources.getIdentifier("google_app_id", "string", settingsContext.packageName) != 0 }
    val keyStore = remember { SecureGeminiKeyStore(settingsContext) }
    val aiCache = remember { AiInsightCache(settingsContext) }
    val scope = rememberCoroutineScope()
    var apiKeyInput by rememberSaveable { mutableStateOf("") }
    var keyConfigured by remember { mutableStateOf(keyStore.hasKey()) }
    var aiStatus by remember { mutableStateOf<String?>(null) }
    var testingAi by remember { mutableStateOf(false) }

    Scaffold(topBar = { SimpleBackBar("Settings", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp)) {
            item { SettingsHeading("Appearance") }
            item {
                Text("Theme", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(Modifier.padding(vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ThemeMode.entries.forEach { m -> FilterChip(selected = settings.themeMode == m, onClick = { onSettings(settings.copy(themeMode = m)) }, label = { Text(m.name.lowercase().replaceFirstChar { it.uppercase() }) }) }
                }
            }
            item {
                Text("Accent color", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Choose a lively palette inspired by the Akademi logo. The selection updates cards, buttons, highlights and profile banners.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 3.dp))
                LazyRow(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(AccentPreset.entries) { a -> AccentPaletteCard(a, settings.accent == a) { onSettings(settings.copy(accent = a)) } }
                }
            }
            item { SettingsHeading("App behaviour") }
            item { ToggleRow("Notifications", "Master switch for Akademi alerts", settings.notifications) { onSettings(settings.copy(notifications = it)) } }
            item { ToggleRow("New opportunity alerts", "Notify when the live collector finds new strong profile matches", settings.opportunityAlerts) { onSettings(settings.copy(opportunityAlerts = it)) } }
            item { ToggleRow("Deadline alerts", "Remind you about tracked applications as deadlines approach", settings.deadlineAlerts) { onSettings(settings.copy(deadlineAlerts = it)) } }
            item { ToggleRow("Refresh live feed on launch", "Refresh the collector feed whenever Akademi opens", settings.refreshOnLaunch) { onSettings(settings.copy(refreshOnLaunch = it)) } }
            item { ToggleRow("Allow external browser by default", "Off by default. Opportunity details still open in Akademi first", settings.openLinksExternally) { onSettings(settings.copy(openLinksExternally = it)) } }
            item { ToggleRow("Web-page popups & new-window links", "Allow target=_blank and JavaScript window links while browsing sources inside Akademi", settings.webPopupsEnabled) { onSettings(settings.copy(webPopupsEnabled = it)) } }
            item { Text(if (instantPushConfigured) "Instant push: Firebase Cloud Messaging configured" else "Instant push: optional Firebase config not installed; background live-feed alerts remain active", fontSize = 11.sp, color = if (instantPushConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 6.dp)) }

            item { SettingsHeading("Gemini AI (optional)") }
            item { ToggleRow("Enable Akademi Intelligence", "Adds AI summaries, personalized opportunity analysis and scholarship Q&A. Core Akademi remains fully usable when off.", settings.aiEnabled) { onSettings(settings.copy(aiEnabled = it)) } }
            item {
                Text("Model", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                Row(Modifier.padding(vertical = 8.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GeminiClient.supportedModels.forEach { model ->
                        FilterChip(selected = settings.aiModel == model, onClick = { onSettings(settings.copy(aiModel = model)) }, label = { Text(model.removePrefix("gemini-")) })
                    }
                }
                Text("3.6 Flash is the default configured model. Check AI Studio for the current free-tier quota and model availability, since provider limits can change.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f))
            }
            item {
                Text("API key", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
                Text(if (keyConfigured) "A Gemini key is securely stored on this device." else "No Gemini key is stored on this device.", fontSize = 11.sp, color = if (keyConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 3.dp))
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it; aiStatus = null },
                    label = { Text(if (keyConfigured) "Replace Gemini API key" else "Gemini API key") },
                    placeholder = { Text("Paste key from Google AI Studio") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            runCatching { keyStore.save(apiKeyInput) }
                                .onSuccess { keyConfigured = true; apiKeyInput = ""; aiStatus = "Gemini key saved securely on this device." }
                                .onFailure { aiStatus = it.message ?: "Could not save key" }
                        },
                        enabled = apiKeyInput.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) { Text("Save key") }
                    Button(
                        onClick = {
                            val testKey = apiKeyInput.trim().ifBlank { keyStore.load().orEmpty() }
                            if (testKey.isBlank()) aiStatus = "Add or save a Gemini API key first."
                            else scope.launch {
                                testingAi = true; aiStatus = "Testing Gemini…"
                                GeminiClient.test(testKey, settings.aiModel)
                                    .onSuccess { aiStatus = it }
                                    .onFailure { aiStatus = it.message ?: "Gemini connection failed" }
                                testingAi = false
                            }
                        },
                        enabled = !testingAi && (apiKeyInput.isNotBlank() || keyConfigured),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (testingAi) { CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp); Spacer(Modifier.width(6.dp)) }
                        Text(if (testingAi) "Testing…" else "Test connection")
                    }
                }
                if (keyConfigured) TextButton(onClick = { keyStore.clear(); keyConfigured = false; aiStatus = "Gemini key removed from this device." }) { Text("Remove stored key") }
                aiStatus?.let { Text(it, fontSize = 11.sp, color = if (it.contains("error", true) || it.contains("failed", true)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 4.dp)) }
            }
            item { ToggleRow("Cache personalized AI reviews", "Recommended. Reopening the same scholarship will reuse its local AI analysis instead of spending another request.", settings.aiCacheEnabled) { onSettings(settings.copy(aiCacheEnabled = it)) } }
            item {
                OutlinedButton(onClick = { aiCache.clear(); aiStatus = "Local Gemini analysis cache cleared." }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Icon(Icons.Outlined.DeleteSweep, null); Spacer(Modifier.width(8.dp)); Text("Clear AI analysis cache")
                }
            }
            item {
                Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Text("Privacy note: Gemini free-tier prompts may be used by Google to improve its products. Avoid submitting unnecessary sensitive information in CVs, research proposals or personal statements. Collector enrichment uses public scholarship information only.", fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurface.copy(.68f))
                }
            }

            item { SettingsHeading("Live opportunity feed") }
            item { Text("The included collector publishes a normalized HTTPS scholarship feed. When the GitHub GEMINI_API_KEY secret is configured, the collector can enrich newly found opportunities once and cache those summaries in the feed; otherwise collection continues without AI.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), lineHeight = 18.sp) }
            item {
                OutlinedTextField(feed, { feed = it }, label = { Text("HTTPS feed URL") }, placeholder = { Text("https://…/opportunities.json") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), singleLine = true)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onSettings(settings.copy(liveFeedUrl = feed.trim())) }, modifier = Modifier.weight(1f)) { Text("Save feed") }
                    Button(onClick = { val u = feed.trim(); onSettings(settings.copy(liveFeedUrl = u)); onRefresh(u) }, modifier = Modifier.weight(1f)) { Text("Save & refresh") }
                }
                remoteMessage?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f), modifier = Modifier.padding(top = 6.dp)) }
            }
            item { SettingsHeading("Privacy & data") }
            item { Text("Profile, tracker, appearance preferences and optional AI cache are stored locally. The Gemini key is encrypted with Android Keystore. Professor searches are sent directly to OpenAlex when requested.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f)) }
            item { OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Icon(Icons.Outlined.RestartAlt, null); Spacer(Modifier.width(8.dp)); Text("Reset local app data") } }
            item { SettingsHeading("About") }
            item { AkademiWordmark(); Text("Version 0.4.0 • Visual travel discovery UX • 26 bundled editorial assets • Inter typography • Pure white cards • Gemini Intelligence • Live collector • Dynamic feed • Expandable cards • Full-screen video", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f), modifier = Modifier.padding(top = 8.dp, bottom = 30.dp)) }
        }
    }
}


@Composable
private fun AccentPaletteCard(preset: AccentPreset, selected: Boolean, onClick: () -> Unit) {
    val colors = accentGradient(preset)
    Surface(
        modifier = Modifier.width(132.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.10f)),
        shadowElevation = if (selected) 7.dp else 2.dp,
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.padding(8.dp)) {
            Box(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(colors))) {
                if (selected) Surface(Modifier.align(Alignment.TopEnd).padding(6.dp), shape = CircleShape, color = Color.White.copy(.92f)) { Icon(Icons.Filled.Check, null, tint = colors.first(), modifier = Modifier.padding(4.dp).size(14.dp)) }
            }
            Text(preset.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 3.dp, top = 7.dp, bottom = 2.dp))
        }
    }
}

@Composable private fun SettingsHeading(text: String) { Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp, bottom = 12.dp)) }
@Composable private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onCheck: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleSmall); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 3.dp)) }; Switch(checked = checked, onCheckedChange = onCheck) } }
@Composable private fun SettingAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) { ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable(onClick = onClick), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleSmall); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.6f), modifier = Modifier.padding(top = 3.dp)) }; Icon(Icons.Outlined.ChevronRight, null) } } }

@Composable private fun SimpleBackBar(title: String, onBack: () -> Unit) { Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }; Text(title, style = MaterialTheme.typography.titleLarge) } }

@Composable private fun InfoBanner(title: String, body: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.Top) { Icon(Icons.Outlined.Info, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp)); Column { Text(title, style = MaterialTheme.typography.titleSmall); Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.67f), modifier = Modifier.padding(top = 4.dp)) } }
    }
}

@Composable
private fun WebScreen(url: String, popupsEnabled: Boolean, onExternal: () -> Unit, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as? android.app.Activity
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageTitle by remember { mutableStateOf("Source") }
    var loading by remember { mutableStateOf(true) }
    var customView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    fun hideFullscreenVideo() {
        val view = customView ?: return
        val decor = activity?.window?.decorView as? ViewGroup
        decor?.removeView(view)
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    fun handleBack() {
        if (customView != null) hideFullscreenVideo()
        else {
            val view = webView
            if (view?.canGoBack() == true) view.goBack() else onBack()
        }
    }

    BackHandler { handleBack() }
    DisposableEffect(Unit) {
        onDispose {
            hideFullscreenVideo()
            webView?.stopLoading()
            webView?.destroy()
        }
    }

    Scaffold(topBar = {
        if (customView == null) {
            Column {
                Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { handleBack() }) { Icon(Icons.Outlined.ArrowBack, "Back") }
                    Column(Modifier.weight(1f)) {
                        Text(pageTitle.ifBlank { "Source" }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(webView?.url ?: url, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                    }
                    IconButton(onClick = { webView?.reload() }) { Icon(Icons.Outlined.Refresh, "Reload") }
                    IconButton(onClick = onExternal) { Icon(Icons.Outlined.OpenInNew, "Open externally") }
                }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        }
    }) { p ->
        AndroidView(
            modifier = Modifier.padding(if (customView == null) p else PaddingValues(0.dp)).fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    webView = this
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadsImagesAutomatically = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.javaScriptCanOpenWindowsAutomatically = popupsEnabled
                    settings.setSupportMultipleWindows(popupsEnabled)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val target = request?.url?.toString().orEmpty()
                            return if (target.startsWith("http://") || target.startsWith("https://")) {
                                view?.loadUrl(target); true
                            } else false
                        }
                        override fun onPageFinished(view: WebView?, url: String?) { loading = false }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) { loading = newProgress < 100 }
                        override fun onReceivedTitle(view: WebView?, title: String?) { pageTitle = title.orEmpty() }
                        override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                            if (view == null || activity == null) { callback?.onCustomViewHidden(); return }
                            if (customView != null) { callback?.onCustomViewHidden(); return }
                            customView = view
                            customViewCallback = callback
                            val decor = activity.window.decorView as ViewGroup
                            decor.addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                            activity.window.decorView.systemUiVisibility =
                                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        }
                        override fun onHideCustomView() { hideFullscreenVideo() }
                        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                            if (!popupsEnabled || view == null || resultMsg == null) return false
                            val popup = WebView(ctx)
                            popup.settings.javaScriptEnabled = true
                            popup.settings.domStorageEnabled = true
                            popup.settings.javaScriptCanOpenWindowsAutomatically = true
                            popup.settings.setSupportMultipleWindows(true)
                            popup.webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                                    val target = request?.url?.toString().orEmpty()
                                    if (target.startsWith("http")) {
                                        view.loadUrl(target)
                                        popup.destroy()
                                        return true
                                    }
                                    return false
                                }
                                override fun onPageStarted(v: WebView?, popupUrl: String?, favicon: android.graphics.Bitmap?) {
                                    if (!popupUrl.isNullOrBlank() && popupUrl != "about:blank") {
                                        view.loadUrl(popupUrl)
                                        popup.destroy()
                                    }
                                }
                            }
                            val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                            transport.webView = popup
                            resultMsg.sendToTarget()
                            return true
                        }
                    }
                    loadUrl(url)
                }
            },
            update = { view ->
                view.settings.javaScriptCanOpenWindowsAutomatically = popupsEnabled
                view.settings.setSupportMultipleWindows(popupsEnabled)
            }
        )
    }
}

private fun openUrl(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
