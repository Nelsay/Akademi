# Akademi v0.4.1 — notification center build

1. Upload `Akademi-v0.4.1-notifications-source.zip` to the repository root.
2. Put `build-akademi-v0.4.1-notifications.yml` in `.github/workflows/`.
3. Replace the old collector workflow with `collect-akademi-live-feed-v0.4.1.yml` if the collector still points to the v0.4.0 ZIP.
4. Keep your existing `GEMINI_API_KEY` repository secret if you already created it.
5. Run **Actions → Build Akademi v0.4.1 Notifications → Run workflow**.
6. Download the `Akademi-v0.4.1-debug-apk` artifact when the run is green.

The Home notification bell is now interactive. It opens Akademi's local notification center, shows unread badges, stores match/deadline alerts, and deep-links linked alerts to the relevant opportunity inside the app.

The APK build does not need to wait for the live collector.
