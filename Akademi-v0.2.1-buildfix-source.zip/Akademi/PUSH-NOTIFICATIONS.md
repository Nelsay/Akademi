# Akademi notifications

Akademi has two notification paths.

## Works immediately — no account required

The app uses Android WorkManager to check the live feed periodically while network is available. It can notify about:

- newly discovered opportunities that score 70/100 or above for the local profile;
- tracked application deadlines at 30, 14, 7, 3, 1 and 0 days.

On Android 13+ the app requests the normal notification permission.

## Optional true server push — Firebase Cloud Messaging

The project is FCM-ready but keeps Firebase configuration optional so a missing Firebase file never blocks the APK build.

1. Create a Firebase project on the no-cost plan.
2. Register Android package `com.akademi.app`.
3. Download `google-services.json` and place it in `app/google-services.json` inside the Akademi source before zipping/building.
4. In Firebase/Google Cloud, create a service account credential allowed to send FCM messages.
5. In the GitHub repository, create Actions secret `FIREBASE_SERVICE_ACCOUNT_JSON` containing the service-account JSON.
6. Rebuild the APK.

When configured, installed Akademi apps subscribe to topic `akademi_opportunities`. After each collector run, the workflow compares the previous and new feeds and sends a topic push if new records were discovered.

If Firebase is not configured, this feature quietly stays disabled and the free WorkManager background alerts continue to work.
