# Akademi v0.1.0 - no custom ProGuard rules yet.
