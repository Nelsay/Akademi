package com.akademi.app.data

object SeedData {
    val opportunities = listOf(
        Opportunity(
            id = "erasmus-mundus",
            title = "Erasmus Mundus Joint Masters",
            provider = "European Union",
            country = "Europe",
            level = "Master's",
            field = "Multiple disciplines",
            funding = "Fully funded",
            deadline = "Varies by programme",
            sourceUrl = "https://erasmus-plus.ec.europa.eu/opportunities/opportunities-for-individuals/students/erasmus-mundus-joint-masters",
            summary = "Joint master's programmes delivered by international university consortia. Scholarship availability and deadlines vary by programme.",
            eligibleNationalities = listOf("All", "Nigeria"),
            keywords = listOf("plant", "environment", "agriculture", "biodiversity", "biotechnology", "climate"),
            requirements = listOf("Relevant bachelor's degree", "Programme-specific academic requirements", "Language requirements", "Motivation/application documents"),
            prScore = 65
        ),
        Opportunity(
            id = "daad-epos",
            title = "DAAD Development-Related Postgraduate Courses (EPOS)",
            provider = "DAAD",
            country = "Germany",
            level = "Master's / PhD",
            field = "Development-related disciplines",
            funding = "Fully funded",
            deadline = "Varies by course",
            sourceUrl = "https://www.daad.de/en/studying-in-germany/scholarships/daad-funding-programmes/",
            summary = "DAAD funding route for selected development-related postgraduate programmes in Germany. Individual course requirements apply.",
            eligibleNationalities = listOf("Developing countries", "Nigeria"),
            keywords = listOf("environment", "agriculture", "natural resources", "climate", "biology", "plant"),
            requirements = listOf("Relevant degree", "Programme-specific work experience", "Motivation", "Language requirements"),
            prScore = 90
        ),
        Opportunity(
            id = "commonwealth-masters",
            title = "Commonwealth Master's Scholarships",
            provider = "Commonwealth Scholarship Commission",
            country = "United Kingdom",
            level = "Master's",
            field = "Multiple disciplines",
            funding = "Fully funded",
            deadline = "Annual cycle — verify current call",
            sourceUrl = "https://cscuk.fcdo.gov.uk/scholarships/commonwealth-masters-scholarships/",
            summary = "Postgraduate scholarship route for eligible Commonwealth-country applicants. Check the current annual call and nominating route.",
            eligibleNationalities = listOf("Nigeria"),
            keywords = listOf("biology", "plant", "environment", "agriculture", "development", "climate"),
            requirements = listOf("Eligible Commonwealth citizenship", "Academic qualification", "Development impact case", "References"),
            prScore = 55
        ),
        Opportunity(
            id = "commonwealth-phd",
            title = "Commonwealth PhD Scholarships",
            provider = "Commonwealth Scholarship Commission",
            country = "United Kingdom",
            level = "PhD",
            field = "Multiple disciplines",
            funding = "Fully funded",
            deadline = "Annual cycle — verify current call",
            sourceUrl = "https://cscuk.fcdo.gov.uk/scholarships/commonwealth-phd-scholarships-for-least-developed-countries-and-fragile-states/",
            summary = "Doctoral funding route within the Commonwealth scholarship system. Eligibility varies by scheme and annual call.",
            eligibleNationalities = listOf("Nigeria", "Check current scheme"),
            keywords = listOf("biology", "botany", "plant", "environment", "agriculture", "research"),
            requirements = listOf("Relevant academic qualification", "Research proposal", "References", "Scheme-specific eligibility"),
            prScore = 55
        ),
        Opportunity(
            id = "euraxess-doctoral",
            title = "EURAXESS Funded Doctoral Positions",
            provider = "EURAXESS",
            country = "Europe",
            level = "PhD",
            field = "Research positions",
            funding = "Salary / funded position",
            deadline = "Continuous listings",
            sourceUrl = "https://euraxess.ec.europa.eu/jobs/search",
            summary = "European research jobs portal with doctoral and research positions. Many PhD opportunities are employment-style funded positions rather than scholarships.",
            eligibleNationalities = listOf("Varies", "International"),
            keywords = listOf("plant", "biology", "biotechnology", "ecology", "environment", "agriculture", "genomics"),
            requirements = listOf("Relevant degree", "Research fit", "Project-specific skills", "Application documents"),
            prScore = 75
        ),
        Opportunity(
            id = "find-supervisor",
            title = "Professor-Funded Plant Science Research Route",
            provider = "University research groups",
            country = "Global",
            level = "Master's / PhD",
            field = "Plant Science / Botany",
            funding = "Varies",
            deadline = "Rolling / project dependent",
            sourceUrl = "https://openalex.org/",
            summary = "Use Akademi's Research screen to discover researchers publishing in your chosen plant-science area, then verify vacancies and funding on their university pages.",
            eligibleNationalities = listOf("Varies"),
            keywords = listOf("botany", "plant science", "plant biotechnology", "genomics", "ecology", "climate resilience"),
            requirements = listOf("Research-topic alignment", "Strong academic CV", "Focused outreach", "Supervisor/project funding availability"),
            prScore = 70
        )
    )

    val countries = listOf(
        CountryInsight("Germany", 90, "Strong study-to-work potential", "Large research ecosystem and a strong fit for plant, environmental and agricultural sciences. Always verify current residence rules on the official government portal.", "https://www.make-it-in-germany.com/en/"),
        CountryInsight("Canada", 78, "Good long-term pathway, competitive", "Post-study work and permanent-residence routes exist, but eligibility and selection rules change. Treat PR as a separate competitive process, not an automatic outcome of study.", "https://www.canada.ca/en/immigration-refugees-citizenship.html"),
        CountryInsight("Australia", 78, "Strong research and skilled-migration ecosystem", "Excellent agricultural, ecological and plant-science research landscape. Post-study and skilled migration routes depend on current occupation, points and visa rules.", "https://immi.homeaffairs.gov.au/"),
        CountryInsight("New Zealand", 76, "Smaller market, strong bioscience alignment", "Particularly relevant for agriculture, ecology, conservation and plant sciences. Check current post-study work and residence pathways before committing.", "https://www.immigration.govt.nz/"),
        CountryInsight("United Kingdom", 58, "Excellent universities, weaker PR-first fit", "Strong scholarship and research options, but if permanent residence is a top priority compare the full post-study work and settlement pathway against other countries.", "https://www.gov.uk/browse/visas-immigration")
    )
}
