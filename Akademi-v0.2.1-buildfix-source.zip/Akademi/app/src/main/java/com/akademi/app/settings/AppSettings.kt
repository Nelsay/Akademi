package com.akademi.app.settings

import android.content.Context
import com.akademi.app.BuildConfig
import com.akademi.app.data.TrackerItem
import com.akademi.app.data.UserProfile
import org.json.JSONArray
import org.json.JSONObject

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class AccentPreset { AKADEMI, NAVY, GOLD, AQUA }

data class SettingsState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: AccentPreset = AccentPreset.AKADEMI,
    val notifications: Boolean = true,
    val opportunityAlerts: Boolean = true,
    val deadlineAlerts: Boolean = true,
    val refreshOnLaunch: Boolean = true,
    val openLinksExternally: Boolean = false,
    val webPopupsEnabled: Boolean = true,
    val liveFeedUrl: String = BuildConfig.DEFAULT_LIVE_FEED_URL
)

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("akademi_preferences", Context.MODE_PRIVATE)

    fun loadSettings() = SettingsState(
        themeMode = runCatching { ThemeMode.valueOf(prefs.getString("theme", ThemeMode.SYSTEM.name)!!) }.getOrDefault(ThemeMode.SYSTEM),
        accent = runCatching { AccentPreset.valueOf(prefs.getString("accent", AccentPreset.AKADEMI.name)!!) }.getOrDefault(AccentPreset.AKADEMI),
        notifications = prefs.getBoolean("notifications", true),
        opportunityAlerts = prefs.getBoolean("opportunityAlerts", true),
        deadlineAlerts = prefs.getBoolean("deadlineAlerts", true),
        refreshOnLaunch = prefs.getBoolean("refreshOnLaunch", true),
        openLinksExternally = prefs.getBoolean("externalLinks", false),
        webPopupsEnabled = prefs.getBoolean("webPopups", true),
        liveFeedUrl = prefs.getString("liveFeedUrl", BuildConfig.DEFAULT_LIVE_FEED_URL) ?: BuildConfig.DEFAULT_LIVE_FEED_URL
    )

    fun saveSettings(s: SettingsState) {
        prefs.edit()
            .putString("theme", s.themeMode.name)
            .putString("accent", s.accent.name)
            .putBoolean("notifications", s.notifications)
            .putBoolean("opportunityAlerts", s.opportunityAlerts)
            .putBoolean("deadlineAlerts", s.deadlineAlerts)
            .putBoolean("refreshOnLaunch", s.refreshOnLaunch)
            .putBoolean("externalLinks", s.openLinksExternally)
            .putBoolean("webPopups", s.webPopupsEnabled)
            .putString("liveFeedUrl", s.liveFeedUrl)
            .apply()
    }

    fun loadProfile(): UserProfile {
        val countries = prefs.getStringSet("countries", setOf("Germany", "Canada", "Australia", "New Zealand")) ?: emptySet()
        return UserProfile(
            name = prefs.getString("name", "My Profile") ?: "My Profile",
            nationality = prefs.getString("nationality", "Nigeria") ?: "Nigeria",
            degree = prefs.getString("degree", "BSc Botany") ?: "BSc Botany",
            field = prefs.getString("field", "Botany") ?: "Botany",
            cgpa = java.lang.Double.longBitsToDouble(prefs.getLong("cgpa", java.lang.Double.doubleToLongBits(4.33))),
            cgpaScale = java.lang.Double.longBitsToDouble(prefs.getLong("cgpaScale", java.lang.Double.doubleToLongBits(5.0))),
            targetLevel = prefs.getString("targetLevel", "Both") ?: "Both",
            researchInterests = prefs.getString("interests", "Plant science, biotechnology, ecology, climate resilience") ?: "",
            researchExperience = prefs.getBoolean("researchExperience", false),
            publications = prefs.getInt("publications", 0),
            preferredCountries = countries,
            fullFundingPreferred = prefs.getBoolean("fullFunding", true),
            prPriority = prefs.getInt("prPriority", 80)
        )
    }

    fun saveProfile(p: UserProfile) {
        prefs.edit()
            .putString("name", p.name)
            .putString("nationality", p.nationality)
            .putString("degree", p.degree)
            .putString("field", p.field)
            .putLong("cgpa", java.lang.Double.doubleToRawLongBits(p.cgpa))
            .putLong("cgpaScale", java.lang.Double.doubleToRawLongBits(p.cgpaScale))
            .putString("targetLevel", p.targetLevel)
            .putString("interests", p.researchInterests)
            .putBoolean("researchExperience", p.researchExperience)
            .putInt("publications", p.publications)
            .putStringSet("countries", p.preferredCountries)
            .putBoolean("fullFunding", p.fullFundingPreferred)
            .putInt("prPriority", p.prPriority)
            .apply()
    }

    fun loadTracker(): List<TrackerItem> {
        val raw = prefs.getString("tracker", "[]") ?: "[]"
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                TrackerItem(o.getString("id"), o.optString("status", "Preparing"), o.optInt("progress", 20), o.optString("notes", ""))
            }
        }.getOrDefault(emptyList())
    }

    fun saveTracker(items: List<TrackerItem>) {
        val a = JSONArray()
        items.forEach { item ->
            a.put(JSONObject().put("id", item.opportunityId).put("status", item.status).put("progress", item.progress).put("notes", item.notes))
        }
        prefs.edit().putString("tracker", a.toString()).apply()
    }

    fun reset() = prefs.edit().clear().apply()
}
