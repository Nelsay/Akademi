package com.akademi.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object RemoteOpportunityRepository {
    suspend fun fetch(feedUrl: String): Result<List<Opportunity>> = withContext(Dispatchers.IO) {
        runCatching {
            require(feedUrl.startsWith("https://")) { "Feed must use HTTPS" }
            val conn = URL(feedUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 12000
            conn.readTimeout = 20000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "Akademi-Android/0.2")
            conn.setRequestProperty("Accept", "application/json")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = if (text.trimStart().startsWith("{")) {
                JSONObject(text).optJSONArray("opportunities") ?: JSONArray()
            } else JSONArray(text)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val source = o.optString("sourceUrl")
                if (!source.startsWith("http")) return@mapNotNull null
                Opportunity(
                    id = o.optString("id").ifBlank { source.hashCode().toString() },
                    title = o.optString("title", "Untitled opportunity"),
                    provider = o.optString("provider", "Unknown provider"),
                    country = o.optString("country", "Global"),
                    level = o.optString("level", "Postgraduate"),
                    field = o.optString("field", "Multiple disciplines"),
                    funding = o.optString("funding", "Check source"),
                    deadline = o.optString("deadline", "Check source"),
                    status = o.optString("status", "Open/verify"),
                    sourceUrl = source,
                    summary = o.optString("summary", ""),
                    minCgpa = if (o.has("minCgpa") && !o.isNull("minCgpa")) o.optDouble("minCgpa") else null,
                    eligibleNationalities = jsonStrings(o.optJSONArray("eligibleNationalities")),
                    keywords = jsonStrings(o.optJSONArray("keywords")),
                    requirements = jsonStrings(o.optJSONArray("requirements")),
                    prScore = o.optInt("prScore", 60),
                    sourceType = o.optString("sourceType", "Live collector"),
                    opportunityType = o.optString("opportunityType", "Scholarship"),
                    studyMode = o.optString("studyMode", "On campus"),
                    duration = o.optString("duration", "Check source"),
                    startDate = o.optString("startDate", "Check source"),
                    tuitionCoverage = o.optString("tuitionCoverage", "Check source"),
                    stipend = o.optString("stipend", "Check source"),
                    livingAllowance = o.optString("livingAllowance", "Check source"),
                    travelSupport = o.optString("travelSupport", "Check source"),
                    applicationFee = o.optString("applicationFee", "Check source"),
                    languageRequirements = jsonStrings(o.optJSONArray("languageRequirements")),
                    documents = jsonStrings(o.optJSONArray("documents")),
                    benefits = jsonStrings(o.optJSONArray("benefits")),
                    eligibility = jsonStrings(o.optJSONArray("eligibility")),
                    howToApply = jsonStrings(o.optJSONArray("howToApply")),
                    selectionProcess = jsonStrings(o.optJSONArray("selectionProcess")),
                    requiresSupervisor = o.optString("requiresSupervisor", "Check source"),
                    applicationUrl = o.optString("applicationUrl", source),
                    lastChecked = o.optString("lastChecked", ""),
                    verified = o.optBoolean("verified", false)
                )
            }
        }
    }

    private fun jsonStrings(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
}
