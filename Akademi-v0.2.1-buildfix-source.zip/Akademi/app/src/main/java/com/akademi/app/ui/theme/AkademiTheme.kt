package com.akademi.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.akademi.app.settings.AccentPreset
import com.akademi.app.settings.SettingsState
import com.akademi.app.settings.ThemeMode

val Navy = Color(0xFF0B1D3A)
val Teal = Color(0xFF0F7C86)
val Aqua = Color(0xFF7FD1C9)
val Gold = Color(0xFFD4AF37)
val Mist = Color(0xFFF5F7FA)

private fun accent(preset: AccentPreset) = when (preset) {
    AccentPreset.AKADEMI -> Teal
    AccentPreset.NAVY -> Navy
    AccentPreset.GOLD -> Gold
    AccentPreset.AQUA -> Color(0xFF2A9D9F)
}

@Composable
fun AkademiTheme(settings: SettingsState, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val primary = accent(settings.accent)
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !dark
        }
    }
    val scheme = if (dark) {
        darkColorScheme(
            primary = if (primary == Navy) Aqua else primary,
            secondary = Aqua,
            tertiary = Gold,
            background = Color(0xFF071426),
            surface = Color(0xFF0E213B),
            surfaceVariant = Color(0xFF152A47),
            onPrimary = Color.White,
            onBackground = Color(0xFFF4F7FB),
            onSurface = Color(0xFFF4F7FB)
        )
    } else {
        lightColorScheme(
            primary = primary,
            secondary = Navy,
            tertiary = Gold,
            background = Mist,
            surface = Color.White,
            surfaceVariant = Color(0xFFEDF3F5),
            onPrimary = Color.White,
            onBackground = Navy,
            onSurface = Navy
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
