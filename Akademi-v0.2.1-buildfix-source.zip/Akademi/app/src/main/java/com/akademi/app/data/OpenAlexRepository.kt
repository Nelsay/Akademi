package com.akademi.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object OpenAlexRepository {
    suspend fun searchResearchers(topic: String): Result<List<Researcher>> = withContext(Dispatchers.IO) {
        runCatching {
            val q = URLEncoder.encode(topic.ifBlank { "plant science" }, StandardCharsets.UTF_8.toString())
            val endpoint = "https://api.openalex.org/works?search=$q&per-page=25&sort=cited_by_count:desc"
            val conn = URL(endpoint).openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.setRequestProperty("User-Agent", "Akademi/0.1 (research discovery app)")
            val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val works = root.getJSONArray("results")
            data class MutableAuthor(var name: String, var institution: String, var country: String, var hits: Int, val topics: MutableSet<String>)
            val authors = linkedMapOf<String, MutableAuthor>()
            for (i in 0 until works.length()) {
                val w = works.getJSONObject(i)
                val title = w.optString("title")
                val concepts = mutableListOf<String>()
                val topics = w.optJSONArray("topics")
                if (topics != null) for (t in 0 until minOf(3, topics.length())) concepts += topics.getJSONObject(t).optString("display_name")
                val a = w.optJSONArray("authorships") ?: continue
                for (j in 0 until minOf(a.length(), 8)) {
                    val auth = a.getJSONObject(j)
                    val ao = auth.optJSONObject("author") ?: continue
                    val id = ao.optString("id")
                    val name = ao.optString("display_name")
                    if (id.isBlank() || name.isBlank()) continue
                    val insts = auth.optJSONArray("institutions")
                    val inst = if (insts != null && insts.length() > 0) insts.getJSONObject(0) else null
                    val institution = inst?.optString("display_name") ?: "Institution not listed"
                    val country = inst?.optString("country_code") ?: ""
                    val entry = authors.getOrPut(id) { MutableAuthor(name, institution, country, 0, mutableSetOf()) }
                    entry.hits++
                    entry.topics += concepts.filter { it.isNotBlank() }
                    if (entry.topics.isEmpty() && title.isNotBlank()) entry.topics += title.take(50)
                }
            }
            val maxHits = authors.values.maxOfOrNull { it.hits }?.coerceAtLeast(1) ?: 1
            authors.entries.sortedByDescending { it.value.hits }.take(20).map { (id, a) ->
                val fit = (72 + (a.hits.toDouble() / maxHits * 24)).toInt().coerceAtMost(96)
                Researcher(id, a.name, a.institution, countryName(a.country), a.topics.take(3), fit, id)
            }
        }
    }

    private fun countryName(code: String) = mapOf(
        "DE" to "Germany", "CA" to "Canada", "AU" to "Australia", "NZ" to "New Zealand", "GB" to "United Kingdom",
        "US" to "United States", "NL" to "Netherlands", "SE" to "Sweden", "CH" to "Switzerland", "FR" to "France"
    )[code] ?: if (code.isBlank()) "" else code
}
