package com.akademi.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.akademi.app.R

@Composable
fun AkademiMark(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.akademi_mark),
        contentDescription = "Akademi logo",
        modifier = modifier
    )
}

@Composable
fun AkademiWordmark(compact: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        AkademiMark(Modifier.size(if (compact) 36.dp else 48.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            "Akademi",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.SemiBold,
            fontSize = if (compact) 23.sp else 30.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
