package com.akademi.app.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.akademi.app.MainActivity
import com.akademi.app.R
import com.akademi.app.data.MatchEngine
import com.akademi.app.data.RemoteOpportunityRepository
import com.akademi.app.data.SeedData
import com.akademi.app.settings.AppPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit

object AkademiNotificationManager {
    private const val OPPORTUNITY_CHANNEL = "akademi_opportunities"
    private const val DEADLINE_CHANNEL = "akademi_deadlines"
    private const val UNIQUE_WORK = "akademi_live_watch"

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                OPPORTUNITY_CHANNEL,
                "New opportunities",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Strong scholarship and funded-position matches found by Akademi" }
        )
        manager.createNotificationChannel(
            NotificationChannel(
                DEADLINE_CHANNEL,
                "Application deadlines",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Reminders for opportunities saved in your Akademi tracker" }
        )
    }

    fun schedule(context: Context, enabled: Boolean) {
        createChannels(context)
        val wm = WorkManager.getInstance(context)
        if (!enabled) {
            wm.cancelUniqueWork(UNIQUE_WORK)
            return
        }
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = PeriodicWorkRequestBuilder<OpportunityWatchWorker>(6, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        wm.enqueueUniquePeriodicWork(UNIQUE_WORK, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun showOpportunity(context: Context, title: String, body: String, notificationId: Int) {
        if (!canNotify(context)) return
        notify(context, OPPORTUNITY_CHANNEL, title, body, notificationId)
    }

    fun showDeadline(context: Context, title: String, body: String, notificationId: Int) {
        if (!canNotify(context)) return
        notify(context, DEADLINE_CHANNEL, title, body, notificationId)
    }

    private fun notify(context: Context, channel: String, title: String, body: String, id: Int) {
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        NotificationManagerCompat.from(context).notify(id, n)
    }
}

class OpportunityWatchWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val appPrefs = AppPreferences(applicationContext)
        val settings = appPrefs.loadSettings()
        if (!settings.notifications || settings.liveFeedUrl.isBlank()) return@withContext Result.success()

        val remote = RemoteOpportunityRepository.fetch(settings.liveFeedUrl).getOrElse { return@withContext Result.retry() }
        val profile = appPrefs.loadProfile()
        val tracker = appPrefs.loadTracker()
        val state = applicationContext.getSharedPreferences("akademi_notification_state", Context.MODE_PRIVATE)

        if (settings.opportunityAlerts) {
            val seen = state.getStringSet("seen_remote_ids", emptySet()) ?: emptySet()
            if (seen.isNotEmpty()) {
                remote.filter { it.id !in seen }
                    .map { MatchEngine.score(profile, it) }
                    .filter { it.score >= 70 }
                    .sortedByDescending { it.score }
                    .take(4)
                    .forEach { scored ->
                        val o = scored.opportunity
                        AkademiNotificationManager.showOpportunity(
                            applicationContext,
                            "${scored.score}/100 match: ${o.title}",
                            "${o.funding} • ${o.country} • Deadline: ${o.deadline}",
                            ("new:" + o.id).hashCode()
                        )
                    }
            }
            state.edit().putStringSet("seen_remote_ids", remote.map { it.id }.toSet()).apply()
        }

        if (settings.deadlineAlerts && tracker.isNotEmpty()) {
            val byId = (remote + SeedData.opportunities).associateBy { it.id }
            val today = LocalDate.now()
            tracker.forEach { item ->
                val o = byId[item.opportunityId] ?: return@forEach
                val due = parseIsoDate(o.deadline) ?: return@forEach
                val days = ChronoUnit.DAYS.between(today, due).toInt()
                if (days in listOf(30, 14, 7, 3, 1, 0)) {
                    val key = "deadline:${o.id}:$days"
                    if (!state.getBoolean(key, false)) {
                        val label = when (days) { 0 -> "today"; 1 -> "tomorrow"; else -> "in $days days" }
                        AkademiNotificationManager.showDeadline(
                            applicationContext,
                            "Akademi deadline $label",
                            "${o.title} • ${o.provider}",
                            key.hashCode()
                        )
                        state.edit().putBoolean(key, true).apply()
                    }
                }
            }
        }
        Result.success()
    }

    private fun parseIsoDate(value: String): LocalDate? = runCatching {
        LocalDate.parse(Regex("\\b\\d{4}-\\d{2}-\\d{2}\\b").find(value)?.value ?: value)
    }.getOrNull()
}
