# Akademi Android — v0.2.0 Live Collector

Akademi is a postgraduate opportunity-intelligence Android app for scholarships, funded Master's/PhD positions, professors/research discovery, application tracking, country strategy and applicant research.

## No paid AI dependency

The core app and live collector do not require a paid AI API. Scholarship matching is transparent rule-based profile fit. Live discovery is a deterministic crawler/normalizer. Professor discovery uses OpenAlex.

## New in v0.2.0

- Live scholarship/funded-position collector under `collector/`.
- Expandable source registry with official/high-authority funding sources across Europe, Germany, UK, Canada, Australia, New Zealand and additional global programmes.
- Sitemap-based source discovery where available and robots.txt checks.
- Structured extraction of funding, deadlines, eligibility clues, requirements, documents, benefits, application steps and selection information.
- GitHub Action that runs every 6 hours and publishes a `live-feed` branch.
- APK build workflow automatically embeds the raw `live-feed/opportunities.json` URL for the repository that builds the app.
- Opportunity cards open a full Akademi detail page first. The detail page contains major information before the original site is needed.
- Explicit **View original source inside Akademi** and **Open original source in external browser** actions.
- In-app WebView source browser with Back history, loading state, title display and configurable new-window/JavaScript popup handling.
- Notification channels and Android 13+ runtime notification permission.
- Optional Firebase Cloud Messaging topic subscription for true server push when a Firebase config is supplied; background polling alerts remain the no-account fallback.
- Background WorkManager check every 6 hours for new strong profile matches.
- Deadline alerts for saved/tracked opportunities.
- Settings for notification master switch, new-opportunity alerts, deadline alerts, source refresh, external-browser default, popup handling, theme and accent colors.

## Important data principle

Akademi shows structured details extracted from source pages, but the original scholarship/university page remains the final authority. The app deliberately labels source verification/freshness instead of inventing certainty.

## Phone-friendly GitHub setup

Upload the source ZIP to the repository root. Put the two supplied YAML files in `.github/workflows/`:

- `build-akademi-v0.2.0-from-zip.yml`
- `collect-akademi-live-feed.yml`

The collector publishes:

`https://raw.githubusercontent.com/OWNER/REPOSITORY/live-feed/opportunities.json`

The APK build automatically injects that URL into `BuildConfig.DEFAULT_LIVE_FEED_URL`.

## Collector source expansion

Edit `collector/sources.json` to add another official scholarship portal or university funding domain. No Android code change is required.

## Package

`com.akademi.app`
