#!/usr/bin/env python3
"""Akademi zero-paid-API scholarship/funded-position collector.

Discovers postgraduate funding pages from an expandable registry of official and
high-authority sources, follows sitemaps when allowed, extracts structured data
with deterministic rules, de-duplicates records, and writes the JSON feed used
by the Android app.
"""
from __future__ import annotations
import argparse, hashlib, json, re, time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser
import requests
from bs4 import BeautifulSoup

UA = "AkademiCollector/0.2 (+scholarship opportunity research; no paid API)"
DISCOVERY_TERMS = (
    "scholarship", "scholarships", "funding", "funded", "fellowship", "fellowships",
    "studentship", "doctoral", "doctorate", "phd", "masters", "master-", "postgraduate",
    "graduate-research", "research-training", "award", "bursary"
)
PAGE_REQUIRED = ("scholarship", "funding", "funded", "fellowship", "studentship", "stipend", "tuition", "award", "bursary")
POSTGRAD = ("master", "doctoral", "phd", "postgraduate", "graduate research", "research degree", "doctoral candidate")
FIELD_MAP = {
    "Plant Science / Botany": ["botany","plant science","plant biology","plant biotechnology","crop","agronomy","plant pathology","plant genomics"],
    "Environment / Ecology": ["ecology","biodiversity","environment","conservation","climate","forestry","natural resources"],
    "Biotechnology / Life Sciences": ["biotechnology","bioscience","biology","genomics","molecular biology","life science"],
    "Agriculture / Food Security": ["agriculture","agricultural","food security","crop science","horticulture","soil science"],
}
COUNTRY_PR = {"Germany":90,"Canada":78,"Australia":78,"New Zealand":76,"Ireland":72,"Sweden":70,"Switzerland":65,"France":63,"Europe":68,"United Kingdom":58,"United States":55,"Global":65}

@dataclass
class Source:
    name: str; country: str; base: str; start_urls: list[str]; sitemap: bool=True; priority: int=5

class Collector:
    def __init__(self, max_pages_per_source=36, timeout=18):
        self.max_pages=max_pages_per_source; self.timeout=timeout
        self.s=requests.Session(); self.s.headers.update({"User-Agent":UA,"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.7"})
        self.robot_cache={}

    def robots_allowed(self,url):
        u=urlparse(url); root=f"{u.scheme}://{u.netloc}"
        if root not in self.robot_cache:
            rp=RobotFileParser(); rp.set_url(root+"/robots.txt")
            try: rp.read(); self.robot_cache[root]=rp
            except Exception: self.robot_cache[root]=None
        rp=self.robot_cache[root]
        return True if rp is None else rp.can_fetch(UA,url)

    def get(self,url):
        if not self.robots_allowed(url): return None
        try:
            r=self.s.get(url,timeout=self.timeout,allow_redirects=True)
            if r.status_code != 200: return None
            ctype=r.headers.get("content-type","")
            if not any(x in ctype for x in ("html","xml","json","text")): return None
            return r
        except requests.RequestException: return None

    def discover_sitemap(self,source):
        found=[]; visited=set(); queue=[urljoin(source.base,"/sitemap.xml"),urljoin(source.base,"/sitemap_index.xml")]
        while queue and len(found)<self.max_pages*4 and len(visited)<12:
            sm=queue.pop(0)
            if sm in visited: continue
            visited.add(sm); r=self.get(sm)
            if not r: continue
            soup=BeautifulSoup(r.text,"xml")
            locs=[x.get_text(strip=True) for x in soup.find_all("loc")]
            for loc in locs:
                low=loc.lower()
                if low.endswith(".xml") or "sitemap" in low:
                    if len(visited)+len(queue)<12: queue.append(loc)
                elif urlparse(loc).netloc==urlparse(source.base).netloc and any(k in low for k in DISCOVERY_TERMS):
                    found.append(loc)
        return found

    def candidates(self,source):
        urls=list(source.start_urls)
        if source.sitemap: urls += self.discover_sitemap(source)
        out=[]; seen=set()
        for u in urls:
            u=u.split("#")[0]
            if u not in seen: seen.add(u); out.append(u)
            if len(out)>=self.max_pages: break
        return out

    def parse(self,source,url):
        r=self.get(url)
        if not r: return None
        soup=BeautifulSoup(r.text,"html.parser")
        for tag in soup(["script","style","noscript","svg"]): tag.decompose()
        title=(soup.find("h1") or soup.find("title"))
        title=clean(title.get_text(" ",strip=True) if title else urlparse(r.url).path.rsplit("/",1)[-1].replace("-"," ").title())
        meta=soup.find("meta",attrs={"name":"description"}) or soup.find("meta",attrs={"property":"og:description"})
        desc=clean(meta.get("content","") if meta else "")
        body=clean(soup.get_text(" ",strip=True))[:120000]
        low=(title+" "+desc+" "+body).lower()
        if not any(x in low for x in PAGE_REQUIRED): return None
        if not any(x in low for x in POSTGRAD) and "research position" not in low: return None

        status="Open / verify on source"
        if re.search(r"applications?\s+(are\s+)?open|now\s+open|apply\s+now",low): status="Open"
        elif re.search(r"applications?\s+(are\s+)?closed|closed\s+for\s+applications",low): status="Closed / next cycle"

        level="Postgraduate"
        has_m=bool(re.search(r"\b(master'?s?|msc|ma\b)",low)); has_p=bool(re.search(r"\b(phd|doctoral|doctorate)\b",low))
        if has_m and has_p: level="Master's / PhD"
        elif has_p: level="PhD"
        elif has_m: level="Master's"

        funding="Funding available"
        if any(x in low for x in ("fully funded","full scholarship","full tuition")): funding="Fully funded"
        elif any(x in low for x in ("salary","salaried doctoral","employment contract")): funding="Salary / funded position"
        elif any(x in low for x in ("partial scholarship","partially funded","tuition discount")): funding="Partially funded"

        field="Multiple disciplines"
        hits=[]
        for name,keys in FIELD_MAP.items():
            score=sum(low.count(k) for k in keys)
            if score: hits.append((score,name))
        if hits: field=max(hits)[1]

        deadline=extract_deadline(body)
        summary=desc or first_useful_paragraph(soup) or body[:500]
        nationalities=["International"]
        if "nigeria" in low: nationalities.insert(0,"Nigeria")
        elif "commonwealth" in low and source.name.lower().startswith("commonwealth"): nationalities=["Nigeria","Eligible Commonwealth countries"]

        req=extract_relevant_list(soup,["eligibility","requirements","eligible","entry requirements"],("degree","gpa","cgpa","ielts","toefl","experience","citizen","national","academic","research"),8)
        docs=extract_relevant_list(soup,["documents","application documents","what you need"],("cv","transcript","reference","recommend","statement","proposal","passport","certificate","letter"),8)
        apply=extract_relevant_list(soup,["how to apply","application process","apply"],("apply","submit","portal","application","nomination","contact"),6)
        selection=extract_relevant_list(soup,["selection","assessment","selection process"],("selection","interview","shortlist","assessment","review"),5)
        benefits=extract_benefits(soup)

        tuition="Full / see source" if "full tuition" in low or "tuition fees" in low and funding=="Fully funded" else "See source"
        stipend=extract_money_sentence(body,"stipend") or extract_money_sentence(body,"monthly allowance") or "See source"
        living=extract_money_sentence(body,"living allowance") or extract_money_sentence(body,"living costs") or "See source"
        travel="Included / see source" if any(x in low for x in ("travel allowance","airfare","flight allowance","travel costs")) else "See source"
        app_fee="No fee stated" if any(x in low for x in ("no application fee","application is free","free to apply")) else "Check source"
        supervisor="Required / likely" if any(x in low for x in ("contact a supervisor","identify a supervisor","supervisor approval")) else ("Usually project-specific" if level=="PhD" else "Not stated")
        language=[]
        for term in ("IELTS","TOEFL","English language requirement"):
            if term.lower() in low: language.append(term+" — verify required score")

        return {
            "id": hashlib.sha1(r.url.encode()).hexdigest()[:18], "title":title[:180], "provider":source.name,
            "country":source.country, "level":level, "field":field, "funding":funding, "deadline":deadline,
            "status":status, "sourceUrl":r.url, "applicationUrl":r.url, "summary":summary[:1200],
            "eligibleNationalities":nationalities, "keywords":make_keywords(low), "requirements":req,
            "prScore":COUNTRY_PR.get(source.country,60), "sourceType":"Official/high-authority source collector",
            "opportunityType":"Funded research position" if "position" in title.lower() or funding.startswith("Salary") else "Scholarship / funding",
            "studyMode":"On campus / verify", "duration":"Check source", "startDate":"Check source",
            "tuitionCoverage":tuition, "stipend":stipend, "livingAllowance":living, "travelSupport":travel,
            "applicationFee":app_fee, "languageRequirements":language, "documents":docs, "benefits":benefits,
            "eligibility":req, "howToApply":apply, "selectionProcess":selection, "requiresSupervisor":supervisor,
            "lastChecked":datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), "verified":True,
            "collectorPriority":source.priority
        }

def clean(s): return re.sub(r"\s+"," ",(s or "")).strip()

def first_useful_paragraph(soup):
    for p in soup.find_all("p"):
        t=clean(p.get_text(" ",strip=True))
        if 80<=len(t)<=900: return t
    return ""

def extract_deadline(text):
    pats=[r"(?:deadline|closing date|applications? close(?:s)?)[^\n\r.]{0,70}?\b(20\d{2}-\d{2}-\d{2})\b",
          r"(?:deadline|closing date|applications? close(?:s)?)[^\n\r.]{0,70}?\b((?:[0-3]?\d)\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+20\d{2})\b",
          r"(?:deadline|closing date|applications? close(?:s)?)[^\n\r.]{0,70}?\b((?:January|February|March|April|May|June|July|August|September|October|November|December)\s+[0-3]?\d,?\s+20\d{2})\b"]
    for p in pats:
        m=re.search(p,text,re.I)
        if m: return clean(m.group(1))
    return "Check source"

def extract_money_sentence(text,needle):
    for sent in re.split(r"(?<=[.!?])\s+",text):
        if needle in sent.lower() and re.search(r"[$€£]|\b(?:EUR|USD|GBP|AUD|CAD|NZD)\b|\d",sent,re.I): return clean(sent)[:220]
    return ""

def extract_benefits(soup):
    vals=[]
    for li in soup.find_all("li"):
        t=clean(li.get_text(" ",strip=True))
        low=t.lower()
        if 15<len(t)<260 and any(k in low for k in ("tuition","stipend","allowance","travel","airfare","insurance","accommodation","living")):
            vals.append(t)
        if len(vals)>=7: break
    return dedupe(vals)

def extract_relevant_list(soup,headings,needles,limit):
    vals=[]
    for h in soup.find_all(re.compile(r"^h[1-6]$")):
        ht=clean(h.get_text(" ",strip=True)).lower()
        if not any(x in ht for x in headings): continue
        node=h.find_next_sibling()
        steps=0
        while node is not None and steps<6:
            if getattr(node,"name","") and re.match(r"^h[1-6]$",node.name): break
            for li in node.find_all("li") if hasattr(node,"find_all") else []:
                t=clean(li.get_text(" ",strip=True)); low=t.lower()
                if 10<len(t)<350 and any(n in low for n in needles): vals.append(t)
                if len(vals)>=limit: return dedupe(vals)
            node=node.find_next_sibling(); steps+=1
    if not vals:
        for li in soup.find_all("li"):
            t=clean(li.get_text(" ",strip=True)); low=t.lower()
            if 10<len(t)<280 and any(n in low for n in needles): vals.append(t)
            if len(vals)>=limit: break
    return dedupe(vals)

def make_keywords(low):
    keys=[]
    for k in ("botany","plant science","plant biotechnology","genomics","ecology","biodiversity","environment","climate","agriculture","crop","food security","biology","biotechnology"):
        if k in low: keys.append(k)
    return keys or ["postgraduate","scholarship"]

def dedupe(xs):
    out=[]; seen=set()
    for x in xs:
        k=x.lower()
        if k not in seen: seen.add(k); out.append(x)
    return out

def load_sources(path):
    raw=json.loads(Path(path).read_text())
    return [Source(**x) for x in raw]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--sources",default="collector/sources.json"); ap.add_argument("--output",default="feed/opportunities.json"); ap.add_argument("--meta",default="feed/meta.json"); ap.add_argument("--max-pages",type=int,default=36)
    args=ap.parse_args(); sources=sorted(load_sources(args.sources),key=lambda x:-x.priority); c=Collector(args.max_pages)
    records=[]; stats={}
    for src in sources:
        count=0; checked=0
        for url in c.candidates(src):
            checked+=1; rec=c.parse(src,url)
            if rec: records.append(rec); count+=1
            time.sleep(.12)
        stats[src.name]={"checked":checked,"accepted":count}
        print(f"{src.name}: {count}/{checked}")
    unique={}
    for r in records:
        key=(r["sourceUrl"].rstrip("/").lower())
        if key not in unique or r.get("collectorPriority",0)>unique[key].get("collectorPriority",0): unique[key]=r
    records=list(unique.values())
    for r in records: r.pop("collectorPriority",None)
    records.sort(key=lambda x:(x["status"]!="Open", -x.get("prScore",0), x["country"], x["title"]))
    out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(records,indent=2,ensure_ascii=False)+"\n")
    meta={"generatedAt":datetime.now(timezone.utc).isoformat(),"records":len(records),"sources":len(sources),"stats":stats,"collector":"Akademi deterministic collector v0.2","note":"Always verify final eligibility, funding and deadlines on the original source."}
    Path(args.meta).write_text(json.dumps(meta,indent=2)+"\n")
    print(f"Wrote {len(records)} opportunities to {out}")

if __name__=="__main__": main()
