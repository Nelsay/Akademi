#!/usr/bin/env python3
import argparse, json, os, sys
import requests
from google.auth.transport.requests import Request
from google.oauth2 import service_account

SCOPE = "https://www.googleapis.com/auth/firebase.messaging"

def load(path):
    try:
        with open(path, encoding="utf-8") as f: return json.load(f)
    except Exception:
        return []

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--previous",required=True); ap.add_argument("--current",required=True); ap.add_argument("--topic",default="akademi_opportunities")
    a=ap.parse_args()
    raw=os.environ.get("FIREBASE_SERVICE_ACCOUNT_JSON","").strip()
    if not raw:
        print("FCM service-account secret not configured; background polling notifications remain active.")
        return 0
    info=json.loads(raw)
    prev=load(a.previous); cur=load(a.current)
    prev_ids={x.get("id") for x in prev if isinstance(x,dict)}
    new=[x for x in cur if isinstance(x,dict) and x.get("id") not in prev_ids]
    if not new:
        print("No new records; no FCM push sent.")
        return 0
    open_new=[x for x in new if str(x.get("status","")).lower().startswith("open")]
    chosen=open_new or new
    first=chosen[0]
    title=f"Akademi found {len(new)} new opportunit{'y' if len(new)==1 else 'ies'}"
    body=f"{first.get('title','New postgraduate opportunity')} • {first.get('country','Global')} • {first.get('funding','Funding available')}"
    creds=service_account.Credentials.from_service_account_info(info,scopes=[SCOPE]); creds.refresh(Request())
    project=info["project_id"]
    endpoint=f"https://fcm.googleapis.com/v1/projects/{project}/messages:send"
    payload={"message":{"topic":a.topic,"notification":{"title":title,"body":body},"data":{"title":title,"body":body,"kind":"new_opportunities"},"android":{"priority":"high"}}}
    r=requests.post(endpoint,headers={"Authorization":f"Bearer {creds.token}","Content-Type":"application/json"},json=payload,timeout=20)
    if r.status_code>=300:
        print("FCM send failed",r.status_code,r.text[:500],file=sys.stderr); return 1
    print("FCM push sent:",title)
    return 0

if __name__=="__main__": raise SystemExit(main())
