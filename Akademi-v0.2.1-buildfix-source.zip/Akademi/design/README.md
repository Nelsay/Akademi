# Design source of truth

- `akademi-ui-reference.png`: approved overall UI/UX direction and screen hierarchy.
- `akademi-brand-reference.png`: approved replacement logo/brand mark.

The UI reference was generated before the logo was changed. Keep its layout/spacing/interface direction, but always use the newer logo from `akademi-brand-reference.png` and `app/src/main/res/drawable-nodpi/akademi_mark.png`.
