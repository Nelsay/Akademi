# Akademi Live Collector

Akademi v0.2 includes a zero-paid-API collector. It is designed for the phone-friendly GitHub workflow where the repository contains the Akademi source ZIP plus workflow YAML files.

## What it does

- Runs every 6 hours from GitHub Actions.
- Reads `collector/sources.json` from the ZIP.
- Crawls configured official/high-authority scholarship, research and university funding sources.
- Uses robots.txt checks and sitemap discovery where available.
- Detects scholarship/funding/doctoral/postgraduate pages.
- Extracts structured fields with deterministic rules: title, provider, country, level, funding, opening signal, deadline, eligibility clues, requirements, documents, benefits, application steps and funding details.
- De-duplicates records.
- Publishes `opportunities.json` to a `live-feed` branch.
- The APK build workflow automatically embeds that repository's raw `live-feed/opportunities.json` URL, so there is no API key to type into the app.

## Repository root files

Upload these next to the source ZIP:

- `Akademi-v0.2.0-live-source.zip`
- `build-akademi-v0.2.0-from-zip.yml` under `.github/workflows/`
- `collect-akademi-live-feed.yml` under `.github/workflows/`

GitHub Actions needs `contents: write` permission for the collector workflow because it publishes the generated `live-feed` branch.

## Important limitation

No free crawler can literally guarantee every scholarship page on the entire public internet. This collector uses an expandable high-value source network and can be widened by adding source domains to `collector/sources.json`. Official programme pages remain the final authority.
