package com.akademi.app.data

data class UserProfile(
    val name: String = "My Profile",
    val nationality: String = "Nigeria",
    val degree: String = "",
    val field: String = "",
    val cgpa: Double = 0.0,
    val cgpaScale: Double = 5.0,
    val targetLevel: String = "Both",
    val researchInterests: String = "",
    val researchExperience: Boolean = false,
    val publications: Int = 0,
    val preferredCountries: Set<String> = setOf("Germany", "Canada", "Australia", "New Zealand"),
    val fullFundingPreferred: Boolean = true,
    val prPriority: Int = 80,
    val profileImagePath: String = "",
    val bannerImagePath: String = "",
    val bannerStyle: Int = 0,
    val headline: String = "Postgraduate opportunity explorer"
)

data class Opportunity(
    val id: String,
    val title: String,
    val provider: String,
    val country: String,
    val level: String,
    val field: String,
    val funding: String,
    val deadline: String,
    val status: String = "Verify opening",
    val sourceUrl: String,
    val summary: String,
    val minCgpa: Double? = null,
    val eligibleNationalities: List<String> = listOf("All"),
    val keywords: List<String> = emptyList(),
    val requirements: List<String> = emptyList(),
    val prScore: Int = 60,
    val sourceType: String = "Official source",
    val opportunityType: String = "Scholarship",
    val studyMode: String = "On campus",
    val duration: String = "Check source",
    val startDate: String = "Check source",
    val tuitionCoverage: String = "Check source",
    val stipend: String = "Check source",
    val livingAllowance: String = "Check source",
    val travelSupport: String = "Check source",
    val applicationFee: String = "Check source",
    val languageRequirements: List<String> = emptyList(),
    val documents: List<String> = emptyList(),
    val benefits: List<String> = emptyList(),
    val eligibility: List<String> = emptyList(),
    val howToApply: List<String> = emptyList(),
    val selectionProcess: List<String> = emptyList(),
    val requiresSupervisor: String = "Check source",
    val applicationUrl: String = "",
    val lastChecked: String = "",
    val verified: Boolean = false,
    val imageUrl: String = "",
    val aiSummary: String = "",
    val aiRequirements: List<String> = emptyList(),
    val aiActions: List<String> = emptyList(),
    val aiSelectionSignals: List<String> = emptyList(),
    val aiRisks: List<String> = emptyList(),
    val aiFundingNotes: String = "",
    val aiConfidence: String = "",
    val aiModel: String = "",
    val aiUpdatedAt: String = ""
)

data class ScoredOpportunity(val opportunity: Opportunity, val score: Int, val reasons: List<String>)

data class Researcher(
    val id: String,
    val name: String,
    val institution: String,
    val country: String,
    val topics: List<String>,
    val fitScore: Int,
    val openAlexUrl: String,
    val worksCount: Int = 0,
    val citedByCount: Int = 0,
    val orcid: String = "",
    val homepage: String = ""
)

data class TrackerItem(
    val opportunityId: String,
    val status: String = "Preparing",
    val progress: Int = 20,
    val notes: String = ""
)

data class CountryInsight(
    val country: String,
    val stayPotential: Int,
    val headline: String,
    val detail: String,
    val officialUrl: String
)
