package com.akademi.app.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

@Composable
fun SmartImage(
    source: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    placeholderColor: Color = Color(0xFFE9EEF8),
    fallback: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current
    val bitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(initialValue = null, source) {
        value = if (source.isBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = when {
                    source.startsWith("content://") || source.startsWith("file://") -> {
                        context.contentResolver.openInputStream(Uri.parse(source))?.use(BitmapFactory::decodeStream)
                    }
                    source.startsWith("http://") || source.startsWith("https://") -> {
                        val connection = URL(source).openConnection() as HttpURLConnection
                        connection.connectTimeout = 8000
                        connection.readTimeout = 10000
                        connection.instanceFollowRedirects = true
                        connection.setRequestProperty("User-Agent", "Akademi/0.3")
                        connection.inputStream.use { BitmapFactory.decodeStream(it) }.also { connection.disconnect() }
                    }
                    else -> null
                }
                bitmap?.asImageBitmap()
            }.getOrNull()
        }
    }

    if (bitmap != null) {
        Image(bitmap = bitmap!!, contentDescription = null, modifier = modifier, contentScale = contentScale)
    } else {
        Box(modifier = modifier.background(placeholderColor), contentAlignment = Alignment.Center) {
            fallback?.invoke()
        }
    }
}
