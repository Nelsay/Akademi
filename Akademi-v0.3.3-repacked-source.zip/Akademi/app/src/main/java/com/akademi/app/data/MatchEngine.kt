package com.akademi.app.data

import kotlin.math.roundToInt

object MatchEngine {
    fun score(profile: UserProfile, o: Opportunity): ScoredOpportunity {
        var points = 0.0
        val reasons = mutableListOf<String>()

        val safeScale = profile.cgpaScale.takeIf { it > 0 } ?: 1.0
        val gpaPct = (profile.cgpa / safeScale).coerceIn(0.0, 1.0)
        val academic = 25 * gpaPct
        points += academic
        if (gpaPct >= .80) reasons += "Strong academic performance (${profile.cgpa}/${profile.cgpaScale})"

        val haystack = (o.title + " " + o.field + " " + o.keywords.joinToString(" ")).lowercase()
        val profileTerms = (profile.field + " " + profile.researchInterests)
            .lowercase().split(Regex("[^a-z]+"))
            .filter { it.length > 3 }.toSet()
        val overlap = profileTerms.count { haystack.contains(it) }
        val fieldPoints = (overlap * 5).coerceAtMost(25)
        points += fieldPoints
        if (fieldPoints >= 10) reasons += "Good subject/research-interest alignment"

        val nationalityFit = o.eligibleNationalities.any {
            it.equals("All", true) || it.equals("International", true) || it.contains(profile.nationality, true) || it.contains("Varies", true)
        }
        if (nationalityFit) {
            points += 10
            reasons += "Nationality appears eligible or open internationally"
        }

        val levelFit = profile.targetLevel == "Both" || o.level.contains(profile.targetLevel.removeSuffix("'s"), true)
        if (levelFit) {
            points += 15
            reasons += "Matches your postgraduate level preference"
        }

        val fundingFit = !profile.fullFundingPreferred || o.funding.contains("Fully", true) || o.funding.contains("Salary", true)
        if (fundingFit) {
            points += 10
            reasons += "Funding structure matches your preference"
        }

        if (profile.preferredCountries.contains(o.country) || o.country in listOf("Europe", "Global")) {
            points += 10
            reasons += "Fits your target-country strategy"
        }

        val prWeight = (profile.prPriority / 100.0) * 5
        points += (o.prScore / 100.0) * prWeight
        if (o.prScore >= 75 && profile.prPriority >= 60) reasons += "Relatively strong stay/work potential"

        return ScoredOpportunity(o, points.roundToInt().coerceIn(0, 100), reasons.take(5))
    }
}
