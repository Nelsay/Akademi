package com.akademi.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object OpenAlexRepository {
    suspend fun searchResearchers(topic: String): Result<List<Researcher>> = withContext(Dispatchers.IO) {
        runCatching {
            val search = topic.ifBlank { "postgraduate research" }
            val q = URLEncoder.encode(search, StandardCharsets.UTF_8.toString())
            val endpoint = "https://api.openalex.org/works?search=$q&per-page=30&sort=cited_by_count:desc"
            val conn = URL(endpoint).openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 18000
            conn.setRequestProperty("User-Agent", "Akademi/0.3 (research discovery app)")
            conn.setRequestProperty("Accept", "application/json")
            val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val works = root.getJSONArray("results")

            data class MutableAuthor(
                var name: String,
                var institution: String,
                var country: String,
                var hits: Int,
                var citations: Int,
                var orcid: String,
                val topics: MutableSet<String>
            )

            val authors = linkedMapOf<String, MutableAuthor>()
            for (i in 0 until works.length()) {
                val w = works.getJSONObject(i)
                val title = w.optString("title")
                val workCitations = w.optInt("cited_by_count", 0)
                val concepts = mutableListOf<String>()
                val topics = w.optJSONArray("topics")
                if (topics != null) {
                    for (t in 0 until minOf(4, topics.length())) {
                        topics.optJSONObject(t)?.optString("display_name")?.takeIf(String::isNotBlank)?.let(concepts::add)
                    }
                }
                val authorships = w.optJSONArray("authorships") ?: continue
                for (j in 0 until minOf(authorships.length(), 10)) {
                    val auth = authorships.optJSONObject(j) ?: continue
                    val authorObj = auth.optJSONObject("author") ?: continue
                    val id = authorObj.optString("id")
                    val name = authorObj.optString("display_name")
                    if (id.isBlank() || name.isBlank()) continue
                    val insts = auth.optJSONArray("institutions")
                    val inst = if (insts != null && insts.length() > 0) insts.optJSONObject(0) else null
                    val institution = inst?.optString("display_name").orEmpty().ifBlank { "Institution not listed" }
                    val country = inst?.optString("country_code").orEmpty()
                    val orcid = authorObj.optString("orcid").orEmpty()
                    val entry = authors.getOrPut(id) {
                        MutableAuthor(name, institution, country, 0, 0, orcid, mutableSetOf())
                    }
                    entry.hits++
                    entry.citations += workCitations
                    if (entry.orcid.isBlank() && orcid.isNotBlank()) entry.orcid = orcid
                    entry.topics += concepts.filter { it.isNotBlank() }
                    if (entry.topics.isEmpty() && title.isNotBlank()) entry.topics += title.take(70)
                }
            }

            val maxHits = authors.values.maxOfOrNull { it.hits }?.coerceAtLeast(1) ?: 1
            authors.entries.sortedWith(compareByDescending<Map.Entry<String, MutableAuthor>> { it.value.hits }.thenByDescending { it.value.citations })
                .take(20)
                .map { (id, a) ->
                    val fit = (70 + (a.hits.toDouble() / maxHits * 26)).toInt().coerceAtMost(96)
                    Researcher(
                        id = id,
                        name = a.name,
                        institution = a.institution,
                        country = countryName(a.country),
                        topics = a.topics.take(4),
                        fitScore = fit,
                        openAlexUrl = id,
                        worksCount = a.hits,
                        citedByCount = a.citations,
                        orcid = a.orcid
                    )
                }
        }
    }

    private fun countryName(code: String) = mapOf(
        "DE" to "Germany", "CA" to "Canada", "AU" to "Australia", "NZ" to "New Zealand", "GB" to "United Kingdom",
        "US" to "United States", "NL" to "Netherlands", "SE" to "Sweden", "CH" to "Switzerland", "FR" to "France",
        "IE" to "Ireland", "FI" to "Finland", "DK" to "Denmark", "NO" to "Norway", "BE" to "Belgium", "AT" to "Austria",
        "IT" to "Italy", "ES" to "Spain", "JP" to "Japan", "SG" to "Singapore", "ZA" to "South Africa"
    )[code] ?: if (code.isBlank()) "" else code
}
