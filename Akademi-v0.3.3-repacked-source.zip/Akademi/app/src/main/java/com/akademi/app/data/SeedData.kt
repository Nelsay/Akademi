package com.akademi.app.data

object SeedData {
    val opportunities = listOf(
        Opportunity(
            id = "erasmus-mundus",
            title = "Erasmus Mundus Joint Masters",
            provider = "European Union",
            country = "Europe",
            level = "Master's",
            field = "Multiple disciplines",
            funding = "Fully funded",
            deadline = "Varies by programme",
            sourceUrl = "https://erasmus-plus.ec.europa.eu/opportunities/opportunities-for-individuals/students/erasmus-mundus-joint-masters",
            summary = "Joint master's programmes delivered by international university consortia. Scholarship availability and deadlines vary by programme.",
            eligibleNationalities = listOf("All", "Nigeria"),
            keywords = listOf("science", "engineering", "technology", "health", "business", "environment", "agriculture", "social science", "arts"),
            requirements = listOf("Relevant bachelor's degree", "Programme-specific academic requirements", "Language requirements", "Motivation/application documents"),
            prScore = 65
        ),
        Opportunity(
            id = "daad-epos",
            title = "DAAD Development-Related Postgraduate Courses (EPOS)",
            provider = "DAAD",
            country = "Germany",
            level = "Master's / PhD",
            field = "Development-related disciplines",
            funding = "Fully funded",
            deadline = "Varies by course",
            sourceUrl = "https://www.daad.de/en/studying-in-germany/scholarships/daad-funding-programmes/",
            summary = "DAAD funding route for selected development-related postgraduate programmes in Germany. Individual course requirements apply.",
            eligibleNationalities = listOf("Developing countries", "Nigeria"),
            keywords = listOf("development", "engineering", "environment", "agriculture", "public health", "economics", "management", "science"),
            requirements = listOf("Relevant degree", "Programme-specific work experience", "Motivation", "Language requirements"),
            prScore = 90
        ),
        Opportunity(
            id = "commonwealth-masters",
            title = "Commonwealth Master's Scholarships",
            provider = "Commonwealth Scholarship Commission",
            country = "United Kingdom",
            level = "Master's",
            field = "Multiple disciplines",
            funding = "Fully funded",
            deadline = "Annual cycle — verify current call",
            sourceUrl = "https://cscuk.fcdo.gov.uk/scholarships/commonwealth-masters-scholarships/",
            summary = "Postgraduate scholarship route for eligible Commonwealth-country applicants. Check the current annual call and nominating route.",
            eligibleNationalities = listOf("Nigeria"),
            keywords = listOf("development", "science", "technology", "health", "education", "economics", "environment", "social science"),
            requirements = listOf("Eligible Commonwealth citizenship", "Academic qualification", "Development impact case", "References"),
            prScore = 55
        ),
        Opportunity(
            id = "commonwealth-phd",
            title = "Commonwealth PhD Scholarships",
            provider = "Commonwealth Scholarship Commission",
            country = "United Kingdom",
            level = "PhD",
            field = "Multiple disciplines",
            funding = "Fully funded",
            deadline = "Annual cycle — verify current call",
            sourceUrl = "https://cscuk.fcdo.gov.uk/scholarships/commonwealth-phd-scholarships-for-least-developed-countries-and-fragile-states/",
            summary = "Doctoral funding route within the Commonwealth scholarship system. Eligibility varies by scheme and annual call.",
            eligibleNationalities = listOf("Nigeria", "Check current scheme"),
            keywords = listOf("research", "science", "engineering", "health", "education", "economics", "environment", "social science"),
            requirements = listOf("Relevant academic qualification", "Research proposal", "References", "Scheme-specific eligibility"),
            prScore = 55
        ),
        Opportunity(
            id = "euraxess-doctoral",
            title = "EURAXESS Funded Doctoral Positions",
            provider = "EURAXESS",
            country = "Europe",
            level = "PhD",
            field = "Research positions",
            funding = "Salary / funded position",
            deadline = "Continuous listings",
            sourceUrl = "https://euraxess.ec.europa.eu/jobs/search",
            summary = "European research jobs portal with doctoral and research positions. Many PhD opportunities are employment-style funded positions rather than scholarships.",
            eligibleNationalities = listOf("Varies", "International"),
            keywords = listOf("research", "science", "engineering", "technology", "health", "business", "environment", "agriculture", "social science", "humanities"),
            requirements = listOf("Relevant degree", "Research fit", "Project-specific skills", "Application documents"),
            prScore = 75
        ),
        Opportunity(
            id = "find-supervisor",
            title = "Professor & Project-Funded Research Route",
            provider = "University research groups",
            country = "Global",
            level = "Master's / PhD",
            field = "Any research discipline",
            funding = "Varies",
            deadline = "Rolling / project dependent",
            sourceUrl = "https://openalex.org/",
            summary = "Use Akademi's Research screen to discover active researchers in your own field, inspect their recent work, and then verify vacancies, supervision and project funding on official university pages.",
            eligibleNationalities = listOf("Varies"),
            keywords = listOf("research", "professor", "supervisor", "doctoral", "masters", "project funding", "research assistantship"),
            requirements = listOf("Research-topic alignment", "Strong academic CV", "Focused outreach", "Supervisor/project funding availability"),
            prScore = 70
        )
    )

    val countries = listOf(
        CountryInsight("Germany", 90, "Strong study-to-work potential", "Large research ecosystem across science, engineering, technology, health, business, social science and environmental fields. Always verify current residence rules on the official government portal.", "https://www.make-it-in-germany.com/en/"),
        CountryInsight("Canada", 78, "Good long-term pathway, competitive", "Post-study work and permanent-residence routes exist, but eligibility and selection rules change. Treat PR as a separate competitive process, not an automatic outcome of study.", "https://www.canada.ca/en/immigration-refugees-citizenship.html"),
        CountryInsight("Australia", 78, "Strong research and skilled-migration ecosystem", "Strong university and research ecosystem across many professional and academic disciplines. Post-study and skilled migration routes depend on current occupation, points and visa rules.", "https://immi.homeaffairs.gov.au/"),
        CountryInsight("New Zealand", 76, "Smaller market, strong bioscience alignment", "A smaller but high-quality research market across science, technology, environment, agriculture, health and other disciplines. Check current post-study work and residence pathways before committing.", "https://www.immigration.govt.nz/"),
        CountryInsight("United Kingdom", 58, "Excellent universities, weaker PR-first fit", "Strong scholarship and research options, but if permanent residence is a top priority compare the full post-study work and settlement pathway against other countries.", "https://www.gov.uk/browse/visas-immigration")
    )
}
