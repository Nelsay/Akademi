package com.akademi.app.ai

import com.akademi.app.data.ScoredOpportunity
import com.akademi.app.data.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    const val DEFAULT_MODEL = "gemini-3.6-flash"
    val supportedModels = listOf("gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.5-flash-lite")

    suspend fun test(apiKey: String, model: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject()
                .put("model", normalizeModel(model))
                .put("input", "Reply with exactly: Akademi Gemini connection OK")
                .put("store", false)
                .put("generation_config", JSONObject().put("max_output_tokens", 40).put("thinking_level", "low"))
            extractText(post(apiKey, body)).ifBlank { "Gemini responded successfully." }
        }
    }

    suspend fun analyzeOpportunity(
        apiKey: String,
        model: String,
        profile: UserProfile,
        scored: ScoredOpportunity
    ): Result<AiOpportunityInsight> = withContext(Dispatchers.IO) {
        runCatching {
            val o = scored.opportunity
            val prompt = buildString {
                appendLine("Assess this postgraduate opportunity for the supplied student profile.")
                appendLine("The deterministic Akademi match score is ${scored.score}/100. Do NOT convert it into an acceptance probability and do not invent odds.")
                appendLine("Only use the facts supplied below. Where information is unclear, say it must be verified on the official source.")
                appendLine()
                appendLine("STUDENT PROFILE")
                appendLine("Nationality: ${profile.nationality}")
                appendLine("Degree: ${profile.degree}")
                appendLine("Field: ${profile.field}")
                appendLine("CGPA: ${profile.cgpa}/${profile.cgpaScale}")
                appendLine("Target level: ${profile.targetLevel}")
                appendLine("Research interests: ${profile.researchInterests}")
                appendLine("Research experience: ${profile.researchExperience}")
                appendLine("Publications: ${profile.publications}")
                appendLine("Preferred countries: ${profile.preferredCountries.joinToString()}")
                appendLine("PR/stay priority: ${profile.prPriority}/100")
                appendLine()
                appendLine("OPPORTUNITY")
                appendLine("Title: ${o.title}")
                appendLine("Provider: ${o.provider}")
                appendLine("Country: ${o.country}")
                appendLine("Level: ${o.level}")
                appendLine("Field: ${o.field}")
                appendLine("Funding: ${o.funding}")
                appendLine("Deadline: ${o.deadline}")
                appendLine("Status: ${o.status}")
                appendLine("Summary: ${o.summary}")
                appendLine("Eligibility: ${(o.eligibility + o.requirements).joinToString(" | ")}")
                appendLine("Benefits: ${o.benefits.joinToString(" | ")}")
                appendLine("Language: ${o.languageRequirements.joinToString(" | ")}")
                appendLine("Documents: ${o.documents.joinToString(" | ")}")
                appendLine("Supervisor: ${o.requiresSupervisor}")
                appendLine("Application fee: ${o.applicationFee}")
                appendLine("Deterministic reasons: ${scored.reasons.joinToString(" | ")}")
            }

            val schema = JSONObject()
                .put("type", "object")
                .put("properties", JSONObject()
                    .put("headline", stringSchema("A concise verdict such as Strong fit, promising but verify X, or lower priority."))
                    .put("summary", stringSchema("Two to four concise sentences explaining the fit without claiming guaranteed eligibility."))
                    .put("strengths", stringArraySchema("Specific strengths supported by supplied facts."))
                    .put("risks", stringArraySchema("Weaknesses, missing evidence, uncertainties, or requirements to verify."))
                    .put("actions", stringArraySchema("Highest-impact concrete actions before applying."))
                    .put("selection_signals", stringArraySchema("What this opportunity appears to value, based only on supplied facts."))
                    .put("questions_to_verify", stringArraySchema("Important facts that should be checked on the official source."))
                    .put("confidence", JSONObject().put("type", "string").put("enum", JSONArray(listOf("low", "medium", "high"))))
                )
                .put("required", JSONArray(listOf("headline", "summary", "strengths", "risks", "actions", "selection_signals", "questions_to_verify", "confidence")))

            val body = JSONObject()
                .put("model", normalizeModel(model))
                .put("input", prompt)
                .put("system_instruction", "You are Akademi's postgraduate application intelligence assistant. Be conservative, evidence-based and practical. Never fabricate scholarship rules, professor interest, acceptance odds, or migration guarantees.")
                .put("store", false)
                .put("generation_config", JSONObject().put("max_output_tokens", 1200).put("thinking_level", "low"))
                .put("response_format", JSONObject().put("type", "text").put("mime_type", "application/json").put("schema", schema))

            AiOpportunityInsight.fromJson(JSONObject(extractText(post(apiKey, body))), normalizeModel(model))
        }
    }

    suspend fun askOpportunity(
        apiKey: String,
        model: String,
        profile: UserProfile,
        scored: ScoredOpportunity,
        question: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val o = scored.opportunity
            val prompt = """
                Student: ${profile.nationality}; ${profile.degree}; CGPA ${profile.cgpa}/${profile.cgpaScale}; interests: ${profile.researchInterests}.
                Opportunity: ${o.title} — ${o.provider}, ${o.country}; ${o.level}; ${o.funding}; deadline ${o.deadline}.
                Extracted summary: ${o.summary}
                Requirements/eligibility: ${(o.requirements + o.eligibility).joinToString(" | ")}
                Benefits: ${o.benefits.joinToString(" | ")}
                Match score from Akademi's deterministic engine: ${scored.score}/100 (this is fit, NOT acceptance probability).

                User question: ${question.trim()}

                Answer specifically and practically. Never invent missing facts. Clearly label anything that must be verified on the official source. Keep the answer under 500 words.
            """.trimIndent()
            val body = JSONObject()
                .put("model", normalizeModel(model))
                .put("input", prompt)
                .put("system_instruction", "You are Akademi, a cautious postgraduate scholarship application adviser. Do not invent facts or acceptance probabilities.")
                .put("store", false)
                .put("generation_config", JSONObject().put("max_output_tokens", 900).put("thinking_level", "low"))
            extractText(post(apiKey, body))
        }
    }

    private fun post(apiKey: String, body: JSONObject): JSONObject {
        require(apiKey.isNotBlank()) { "Gemini API key is not configured" }
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/interactions").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("x-goog-api-key", apiKey.trim())
        conn.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body.toString()) }

        val code = conn.responseCode
        val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) {
            val message = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull().orEmpty()
            throw IllegalStateException("Gemini API error $code${if (message.isNotBlank()) ": $message" else ""}")
        }
        return JSONObject(raw)
    }

    private fun extractText(response: JSONObject): String {
        val steps = response.optJSONArray("steps") ?: JSONArray()
        for (i in steps.length() - 1 downTo 0) {
            val step = steps.optJSONObject(i) ?: continue
            if (step.optString("type") != "model_output") continue
            val content = step.optJSONArray("content") ?: continue
            val parts = buildList {
                for (j in 0 until content.length()) {
                    val item = content.optJSONObject(j) ?: continue
                    if (item.optString("type") == "text") item.optString("text").takeIf(String::isNotBlank)?.let(::add)
                }
            }
            if (parts.isNotEmpty()) return parts.joinToString("\n")
        }
        throw IllegalStateException("Gemini returned no text output")
    }

    private fun normalizeModel(model: String): String = model.trim().takeIf { it in supportedModels } ?: DEFAULT_MODEL
    private fun stringSchema(description: String) = JSONObject().put("type", "string").put("description", description)
    private fun stringArraySchema(description: String) = JSONObject().put("type", "array").put("items", JSONObject().put("type", "string")).put("description", description).put("maxItems", 6)
}

data class AiOpportunityInsight(
    val headline: String,
    val summary: String,
    val strengths: List<String>,
    val risks: List<String>,
    val actions: List<String>,
    val selectionSignals: List<String>,
    val questionsToVerify: List<String>,
    val confidence: String,
    val model: String,
    val generatedAt: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject()
        .put("headline", headline)
        .put("summary", summary)
        .put("strengths", JSONArray(strengths))
        .put("risks", JSONArray(risks))
        .put("actions", JSONArray(actions))
        .put("selectionSignals", JSONArray(selectionSignals))
        .put("questionsToVerify", JSONArray(questionsToVerify))
        .put("confidence", confidence)
        .put("model", model)
        .put("generatedAt", generatedAt)

    companion object {
        fun fromJson(o: JSONObject, modelOverride: String? = null): AiOpportunityInsight = AiOpportunityInsight(
            headline = o.optString("headline", "AI review"),
            summary = o.optString("summary", ""),
            strengths = jsonStrings(o.optJSONArray("strengths")),
            risks = jsonStrings(o.optJSONArray("risks")),
            actions = jsonStrings(o.optJSONArray("actions")),
            selectionSignals = jsonStrings(o.optJSONArray("selection_signals") ?: o.optJSONArray("selectionSignals")),
            questionsToVerify = jsonStrings(o.optJSONArray("questions_to_verify") ?: o.optJSONArray("questionsToVerify")),
            confidence = o.optString("confidence", "medium"),
            model = modelOverride ?: o.optString("model", GeminiClient.DEFAULT_MODEL),
            generatedAt = o.optLong("generatedAt", System.currentTimeMillis())
        )

        private fun jsonStrings(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
    }
}
