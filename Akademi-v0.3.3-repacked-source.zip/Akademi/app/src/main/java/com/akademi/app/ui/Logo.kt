package com.akademi.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.akademi.app.R

@Composable
fun AkademiMark(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.akademi_app_icon),
        contentDescription = "Akademi logo",
        contentScale = ContentScale.Fit,
        modifier = modifier
    )
}

@Composable
fun AkademiWordmark(compact: Boolean = false, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(if (compact) 38.dp else 54.dp)
            .clip(RoundedCornerShape(if (compact) 12.dp else 16.dp))
            .background(Color.White.copy(alpha = .97f))
            .padding(horizontal = if (compact) 7.dp else 10.dp, vertical = if (compact) 4.dp else 6.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.akademi_header_logo),
            contentDescription = "Akademi",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )
    }
}
