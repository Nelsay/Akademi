package com.akademi.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.text.googlefonts.R as GoogleFontsR
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.akademi.app.settings.AccentPreset
import com.akademi.app.settings.SettingsState
import com.akademi.app.settings.ThemeMode

val Navy = Color(0xFF071B4B)
val ElectricBlue = Color(0xFF1C8DFF)
val Cyan = Color(0xFF14C7E8)
val Violet = Color(0xFF7B3FF2)
val Magenta = Color(0xFFE61E93)
val Coral = Color(0xFFFF5B70)
val Orange = Color(0xFFFF9418)
val Mint = Color(0xFF14B8A6)
val Gold = Color(0xFFF2B633)
val Teal = Color(0xFF0C9BA8)
val Aqua = Color(0xFF77DDE7)
val Mist = Color(0xFFF7F9FC)

fun accentColor(preset: AccentPreset) = when (preset) {
    AccentPreset.AURORA -> Color(0xFF3567F1)
    AccentPreset.OCEAN -> Color(0xFF0789C8)
    AccentPreset.VIOLET -> Color(0xFF7547E8)
    AccentPreset.CORAL -> Color(0xFFFF5B70)
    AccentPreset.SUNSET -> Color(0xFFF47435)
    AccentPreset.MINT -> Color(0xFF10A990)
    AccentPreset.MIDNIGHT -> Navy
}

fun accentGradient(preset: AccentPreset): List<Color> = when (preset) {
    AccentPreset.AURORA -> listOf(ElectricBlue, Color(0xFF4F46E5), Violet, Magenta, Orange)
    AccentPreset.OCEAN -> listOf(Color(0xFF18C8EC), Color(0xFF1688F8), Color(0xFF4258E8))
    AccentPreset.VIOLET -> listOf(Color(0xFF5A67F2), Violet, Magenta)
    AccentPreset.CORAL -> listOf(Color(0xFFFF7C68), Coral, Color(0xFFE9368F))
    AccentPreset.SUNSET -> listOf(Color(0xFFFFB52E), Orange, Color(0xFFFF4F6D), Magenta)
    AccentPreset.MINT -> listOf(Color(0xFF4BE0C4), Mint, Color(0xFF149ED1))
    AccentPreset.MIDNIGHT -> listOf(Navy, Color(0xFF173B78), Color(0xFF335BD7))
}

/*
 * Akademi uses Inter through Android's downloadable Google Fonts provider.
 * Nothing is bundled into the APK, and Android falls back naturally if the
 * provider is unavailable. This keeps the source lightweight while giving the
 * interface the clean, premium travel-product typography requested for Akademi.
 */
private val googleFontProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = GoogleFontsR.array.com_google_android_gms_fonts_certs,
)
private val interFont = GoogleFont("Inter")

private val InterFamily = FontFamily(
    Font(googleFont = interFont, fontProvider = googleFontProvider, weight = FontWeight.Normal),
    Font(googleFont = interFont, fontProvider = googleFontProvider, weight = FontWeight.Medium),
    Font(googleFont = interFont, fontProvider = googleFontProvider, weight = FontWeight.SemiBold),
    Font(googleFont = interFont, fontProvider = googleFontProvider, weight = FontWeight.Bold),
)

val AkademiTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 44.sp,
        lineHeight = 50.sp,
        letterSpacing = (-1.1).sp,
    ),
    displayMedium = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 36.sp,
        lineHeight = 42.sp,
        letterSpacing = (-0.8).sp,
    ),
    displaySmall = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 31.sp,
        lineHeight = 37.sp,
        letterSpacing = (-0.55).sp,
    ),
    headlineLarge = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 34.sp,
        letterSpacing = (-0.45).sp,
    ),
    headlineMedium = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.3).sp,
    ),
    headlineSmall = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 21.sp,
        lineHeight = 27.sp,
        letterSpacing = (-0.2).sp,
    ),
    titleLarge = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 19.sp,
        lineHeight = 25.sp,
        letterSpacing = (-0.15).sp,
    ),
    titleMedium = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        letterSpacing = (-0.05).sp,
    ),
    titleSmall = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
    ),
    bodyLarge = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 23.sp,
        letterSpacing = 0.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.5.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.sp,
    ),
    bodySmall = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.05.sp,
    ),
    labelLarge = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.05.sp,
    ),
    labelMedium = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.5.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.1.sp,
    ),
    labelSmall = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 10.5.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.15.sp,
    ),
)

val AkademiShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(13.dp),
    medium = RoundedCornerShape(17.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun AkademiTheme(settings: SettingsState, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val primary = accentColor(settings.accent)
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !dark
        }
    }
    val scheme = if (dark) {
        darkColorScheme(
            primary = if (primary == Navy) Color(0xFF7AA7FF) else primary,
            secondary = Cyan,
            tertiary = Gold,
            background = Color(0xFF070B16),
            surface = Color(0xFF10182A),
            surfaceVariant = Color(0xFF17233A),
            onPrimary = Color.White,
            onBackground = Color(0xFFF5F7FB),
            onSurface = Color(0xFFF5F7FB)
        )
    } else {
        lightColorScheme(
            primary = primary,
            secondary = Navy,
            tertiary = Gold,
            background = Mist,
            // All light-mode cards remain pure white. Accent is reserved for
            // imagery, controls, chips, icon tiles, gradients and interaction.
            surface = Color.White,
            surfaceVariant = Color.White,
            surfaceDim = Color.White,
            surfaceBright = Color.White,
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = Color.White,
            surfaceContainer = Color.White,
            surfaceContainerHigh = Color.White,
            surfaceContainerHighest = Color.White,
            onPrimary = Color.White,
            onBackground = Color(0xFF111827),
            onSurface = Color(0xFF111827)
        )
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = AkademiTypography,
        shapes = AkademiShapes,
    ) {
        ProvideTextStyle(value = AkademiTypography.bodyLarge, content = content)
    }
}
