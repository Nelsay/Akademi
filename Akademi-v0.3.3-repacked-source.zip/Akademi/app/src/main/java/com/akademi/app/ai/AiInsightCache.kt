package com.akademi.app.ai

import android.content.Context
import org.json.JSONObject

class AiInsightCache(context: Context) {
    private val prefs = context.getSharedPreferences("akademi_ai_cache", Context.MODE_PRIVATE)

    fun get(opportunityId: String, model: String): AiOpportunityInsight? = runCatching {
        prefs.getString(key(opportunityId, model), null)?.let { AiOpportunityInsight.fromJson(JSONObject(it)) }
    }.getOrNull()

    fun put(opportunityId: String, insight: AiOpportunityInsight) {
        prefs.edit().putString(key(opportunityId, insight.model), insight.toJson().toString()).apply()
    }

    fun clear() = prefs.edit().clear().apply()

    private fun key(id: String, model: String) = "${model.trim()}::$id"
}
