package com.akademi.app.data

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

data class ResearchDirection(
    val title: String,
    val category: String,
    val fitScore: Int,
    val headline: String,
    val detail: String,
    val exampleTopics: List<String>,
    val externalUrl: String
)

object DirectionEngine {
    fun recommend(profile: UserProfile): List<ResearchDirection> {
        val text = (profile.field + " " + profile.degree + " " + profile.researchInterests).lowercase()
        val base = when {
            text.containsAny("computer", "software", "data", "artificial intelligence", "machine learning", "information technology") -> listOf(
                direction("Artificial intelligence & data", "Computing", 94, "High-growth research route", "Machine learning, data systems and intelligent applications can connect academic research with a broad international technology market.", listOf("machine learning", "data science", "responsible AI", "computer vision")),
                direction("Cybersecurity & trustworthy systems", "Computing", 88, "Strong funded-research ecosystem", "Security, privacy and resilient infrastructure are common themes across university and industry-funded postgraduate projects.", listOf("cybersecurity", "privacy", "networks", "secure systems")),
                direction("Human-computer interaction", "Computing", 82, "Interdisciplinary option", "Combines computing with design, psychology and accessibility and can suit candidates who want a people-centred research direction.", listOf("HCI", "UX research", "accessibility", "interactive systems")),
                direction("Software & distributed systems", "Computing", 84, "Research + industry alignment", "A practical route spanning cloud systems, software engineering, distributed computing and scalable infrastructure.", listOf("software engineering", "cloud", "distributed systems", "systems research"))
            )
            text.containsAny("engineering", "mechanical", "electrical", "civil", "chemical", "mechatronic") -> listOf(
                direction("Sustainable engineering", "Engineering", 92, "Strong international funding relevance", "Energy transition, resource efficiency and climate-resilient infrastructure attract substantial postgraduate research activity.", listOf("renewable energy", "sustainable systems", "climate resilience", "energy efficiency")),
                direction("Robotics & intelligent systems", "Engineering", 87, "Advanced technical route", "Combines control, automation, sensors, embedded systems and AI across engineering disciplines.", listOf("robotics", "automation", "control", "embedded systems")),
                direction("Advanced materials", "Engineering", 83, "Research-intensive direction", "Materials research links manufacturing, energy, electronics, construction and biomedical applications.", listOf("materials science", "nanomaterials", "composites", "manufacturing")),
                direction("Infrastructure & systems design", "Engineering", 80, "Applied global route", "Suitable for candidates interested in resilient infrastructure, transport, water, energy or large-scale technical systems.", listOf("infrastructure", "transport", "water systems", "systems engineering"))
            )
            text.containsAny("business", "economics", "finance", "accounting", "management", "marketing") -> listOf(
                direction("Business analytics", "Business", 91, "Strong employability bridge", "Combines management decisions with statistics, data and digital transformation and is widely available at master's level.", listOf("business analytics", "strategy", "data", "digital transformation")),
                direction("Development economics & policy", "Economics", 86, "Strong scholarship relevance", "Connects economic analysis with development, public policy and international institutions.", listOf("development economics", "public policy", "impact evaluation", "international development")),
                direction("Finance & fintech", "Business", 83, "Industry-linked route", "Covers financial systems, digital finance, markets and emerging technology with academic and professional pathways.", listOf("fintech", "financial economics", "markets", "risk")),
                direction("Entrepreneurship & innovation", "Business", 79, "Applied leadership route", "A useful interdisciplinary direction for candidates interested in venture creation, innovation systems and SME growth.", listOf("entrepreneurship", "innovation", "SMEs", "venture strategy"))
            )
            text.containsAny("medicine", "medical", "health", "nursing", "pharmacy", "biomedical", "public health") -> listOf(
                direction("Global & public health", "Health", 93, "High international relevance", "Public health programmes connect research, policy and population outcomes and often have dedicated international funding routes.", listOf("global health", "health systems", "community health", "health policy")),
                direction("Epidemiology & biostatistics", "Health", 89, "Quantitative research route", "A strong path for candidates interested in disease patterns, evidence generation and population-level decision making.", listOf("epidemiology", "biostatistics", "clinical data", "population health")),
                direction("Biomedical research", "Health", 86, "Research-intensive route", "Links laboratory science, translational research and clinical innovation depending on your prior training.", listOf("biomedical science", "molecular medicine", "translational research", "diagnostics")),
                direction("Health technology & informatics", "Health", 82, "Interdisciplinary route", "Connects healthcare with data, digital systems and service innovation.", listOf("health informatics", "digital health", "medical AI", "health technology"))
            )
            text.containsAny("agriculture", "botany", "plant", "biology", "biotechnology", "ecology", "environment", "forestry", "zoology", "microbiology", "life science") -> listOf(
                direction("Biotechnology & molecular bioscience", "Life sciences", 93, "Broad research opportunity", "A flexible route spanning molecular methods, genetics, diagnostics, industrial biology and applied life-science research.", listOf("biotechnology", "molecular biology", "genetics", "genomics")),
                direction("Climate, ecology & resilience", "Environment", 91, "Strong global funding relevance", "Links biological or environmental training with climate adaptation, ecosystems and resilience research.", listOf("climate resilience", "ecology", "biodiversity", "conservation")),
                direction("Food systems & sustainable agriculture", "Agriculture", 88, "Strong development relevance", "Connects biological sciences with food security, agricultural innovation, sustainable production and resource systems.", listOf("food security", "agriculture", "crop systems", "sustainability")),
                direction("Genomics & bioinformatics", "Life sciences", 86, "High-growth interdisciplinary path", "Combines biological knowledge with computational methods and can open research routes beyond a narrow undergraduate discipline.", listOf("genomics", "bioinformatics", "computational biology", "sequencing"))
            )
            text.containsAny("education", "teaching", "pedagogy", "curriculum") -> listOf(
                direction("Education technology", "Education", 90, "Strong interdisciplinary route", "Combines teaching, digital learning and technology design with growing international research interest.", listOf("EdTech", "digital learning", "learning analytics", "instructional design")),
                direction("Education policy & leadership", "Education", 86, "Policy and systems route", "Suitable for candidates interested in school systems, governance, leadership and education reform.", listOf("education policy", "leadership", "school systems", "governance")),
                direction("Curriculum & learning sciences", "Education", 83, "Research-focused route", "Explores how people learn, how curricula are designed and how outcomes are assessed.", listOf("curriculum", "learning sciences", "assessment", "pedagogy")),
                direction("Inclusive & special education", "Education", 80, "Impact-oriented direction", "Focuses on accessibility, inclusion and support across diverse learning contexts.", listOf("inclusive education", "special education", "accessibility", "student support"))
            )
            text.containsAny("law", "political", "international relations", "sociology", "psychology", "social science", "development studies") -> listOf(
                direction("Public policy & governance", "Social sciences", 91, "Strong international route", "Connects social-science training with policy design, institutions, governance and evidence-based decision making.", listOf("public policy", "governance", "institutions", "policy analysis")),
                direction("International development", "Social sciences", 88, "Scholarship-friendly direction", "A broad route spanning development, inequality, humanitarian work and global institutions.", listOf("development studies", "inequality", "international development", "humanitarian policy")),
                direction("Migration, society & population", "Social sciences", 84, "Cross-border research relevance", "Combines social research with migration, demographics, integration and social change.", listOf("migration", "demography", "social change", "population")),
                direction("Quantitative social research", "Social sciences", 82, "Method-driven option", "Builds transferable research strength through statistics, causal inference, surveys and evidence synthesis.", listOf("research methods", "statistics", "causal inference", "survey research"))
            )
            else -> generic(profile)
        }
        val interest = profile.researchInterests.split(',').map { it.trim() }.firstOrNull { it.length > 3 }
        return if (interest.isNullOrBlank()) base else base.mapIndexed { index, d ->
            if (index == 0) d.copy(headline = "Best fit with your interests", detail = d.detail + " Akademi also detected your stated interest in $interest.") else d
        }
    }

    private fun generic(profile: UserProfile): List<ResearchDirection> {
        val field = profile.field.ifBlank { "your field" }
        return listOf(
            direction("Advanced $field research", "Core field", 90, "Closest academic continuation", "Deepen your existing academic foundation while targeting funded research groups and supervisors working on current problems in $field.", listOf(field, "research methods", "advanced study")),
            direction("Applied $field", "Applied route", 86, "Career-connected direction", "Look for programmes that translate $field into industry, public-sector or real-world applications.", listOf("applied $field", "innovation", "industry")),
            direction("Data & quantitative methods for $field", "Interdisciplinary", 82, "Transferable research skills", "Adding data, statistics or computational methods can broaden programme options and make your profile useful across research teams.", listOf("data analysis", "statistics", field)),
            direction("Policy, sustainability & $field", "Interdisciplinary", 78, "Impact-oriented route", "Explore programmes connecting $field with policy, sustainability, development or societal impact.", listOf("policy", "sustainability", field))
        )
    }

    private fun direction(title: String, category: String, score: Int, headline: String, detail: String, topics: List<String>): ResearchDirection {
        val q = URLEncoder.encode(title, StandardCharsets.UTF_8.toString())
        return ResearchDirection(title, category, score, headline, detail, topics, "https://openalex.org/works?search=$q")
    }

    private fun String.containsAny(vararg terms: String) = terms.any { contains(it) }
}
