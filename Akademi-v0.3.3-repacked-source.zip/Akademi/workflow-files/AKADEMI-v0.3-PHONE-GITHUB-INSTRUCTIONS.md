# Akademi v0.3.0 — phone/GitHub build

## Files to upload
1. Put `Akademi-v0.3.0-social-ai-source.zip` in the repository root.
2. Put `build-akademi-v0.3.0-from-zip.yml` in `.github/workflows/`.
3. Put `collect-akademi-live-feed-v0.3.0.yml` in `.github/workflows/`.

## Add Gemini without exposing the key
In GitHub open **Settings → Secrets and variables → Actions → New repository secret**.

Name it exactly:

`GEMINI_API_KEY`

Paste the Gemini key as the secret value. Do not put the key in the ZIP or YAML.

This secret is only for automatic AI enrichment of public scholarship records collected by GitHub Actions. If the secret is absent or its quota is unavailable, the scholarship collector still runs and publishes the normal feed.

For interactive Gemini features inside the APK (Ask Akademi, personalized opportunity review), enter the Gemini key on the device under **Akademi → Profile → Settings → Gemini AI**. The app stores it encrypted locally with Android Keystore.

## First run
- You may build the APK immediately; you do **not** need to wait for the collector first.
- Open **Actions → Akademi Live Collector v0.3 + Optional Gemini → Run workflow** once to create/update the `live-feed` branch.
- The manual first collector run is deliberately fast and skips sitemap expansion. Later scheduled runs broaden discovery with bounded crawling every six hours.
- Run **Build Akademi v0.3.0 From ZIP** if it did not start automatically after the source ZIP upload.

## Download the APK
When the build has a green check, open it and download the artifact named:

`Akademi-v0.3.0-debug-apk`

The APK inside is `Akademi-v0.3.0-debug.apk`.

## Optional Firebase instant push
Akademi already has periodic background opportunity/deadline notifications without Firebase. FCM remains optional. If you later configure Firebase, add the Android `google-services.json` to `app/` before building and add the collector service-account secret separately as `FIREBASE_SERVICE_ACCOUNT_JSON` for server-originated push.
