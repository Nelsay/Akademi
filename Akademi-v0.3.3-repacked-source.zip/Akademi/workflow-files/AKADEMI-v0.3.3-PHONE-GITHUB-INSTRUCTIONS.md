# Akademi v0.3.3 — phone/GitHub build

## Files to upload
1. Put `Akademi-v0.3.3-premium-ui-source.zip` in the repository root.
2. Put `build-akademi-v0.3.3-from-zip.yml` in `.github/workflows/`.
3. Keep your existing `collect-akademi-live-feed-v0.3.0.yml` workflow in `.github/workflows/`.

## Gemini
If you use automatic Gemini enrichment, keep the GitHub repository secret named exactly `GEMINI_API_KEY`.

For interactive Gemini features inside the APK, enter the key under **Akademi → Profile → Settings → Gemini AI**. The app stores it locally using Android Keystore-backed encrypted storage.

## Build
You can build the APK immediately; the live collector does not have to finish first.

Open **Actions → Build Akademi v0.3.3 From ZIP → Run workflow**.

When it finishes with a green check, download the artifact:

`Akademi-v0.3.3-debug-apk`

The APK inside is `Akademi-v0.3.3-debug.apk`.
