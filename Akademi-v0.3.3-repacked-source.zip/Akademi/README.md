# Akademi Android v0.3.3

Akademi is a personal postgraduate opportunity-intelligence app for scholarships, funded research positions, professors, research directions, country/stay planning, application tracking, success stories and optional Gemini guidance.

## v0.3.3 premium UI pass

- Inter-based typography across the application using Android's downloadable Google Fonts provider rather than bundling font files.
- Stronger hierarchy for display, headline, title, body and label text with tuned line-height and letter-spacing.
- Premium travel-app spacing rhythm: 20dp screen gutters, larger section breaks, roomier card padding and calmer metadata spacing.
- Larger image-led opportunity/feed cards inspired by the supplied travel UI references.
- More refined card radii and soft elevations while keeping all light-mode card surfaces pure `#FFFFFF`.
- More polished LinkedIn-style profile hero proportions and breathing room.
- Search fields, bottom navigation, professor cards, research directions, country cards, tracker cards and Settings all receive the same typography/spacing system.
- Accent colors remain purposeful: buttons, chips, icons, gradients, progress, status and interaction states—not tinted card backgrounds.

## Existing Akademi capabilities preserved

- Works across academic disciplines; research directions and professor searches adapt to the saved profile.
- Editable CGPA and scale, degree, field, nationality, target level, research interests and experience.
- User-selected profile photo and banner image using Android's document picker.
- Animated navigation and expandable opportunity, professor, research-direction, story and country cards.
- Akademi Pulse home feed built from the live opportunity feed, including source images when available and an in-app YouTube video radar.
- In-app browser supports popups/new windows and HTML5/YouTube full-screen video.
- Multiple lively accent palettes, system/light/dark themes, notifications and live-feed preferences.
- Optional Gemini Intelligence with an encrypted local API key and local analysis cache.
- Collector can optionally enrich public opportunity metadata with Gemini via the `GEMINI_API_KEY` GitHub secret.

The core app remains usable without Gemini or Firebase.
