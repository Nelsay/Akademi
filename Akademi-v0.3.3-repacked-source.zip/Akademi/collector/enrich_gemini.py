#!/usr/bin/env python3
"""Optional Gemini enrichment for Akademi's public opportunity feed.

This never sends a user's private profile. It only summarizes public scholarship
metadata collected from official/high-authority sources. Previous AI fields are
reused so scheduled refreshes do not spend quota repeatedly.
"""
from __future__ import annotations
import argparse, json, os, time
from datetime import datetime, timezone
from pathlib import Path
import requests

AI_FIELDS = [
    "aiSummary", "aiRequirements", "aiActions", "aiSelectionSignals", "aiRisks",
    "aiFundingNotes", "aiConfidence", "aiModel", "aiUpdatedAt"
]

SCHEMA = {
    "type":"object",
    "properties":{
        "summary":{"type":"string"},
        "requirements":{"type":"array","items":{"type":"string"}},
        "actions":{"type":"array","items":{"type":"string"}},
        "selection_signals":{"type":"array","items":{"type":"string"}},
        "risks":{"type":"array","items":{"type":"string"}},
        "funding_notes":{"type":"string"},
        "confidence":{"type":"string","enum":["low","medium","high"]}
    },
    "required":["summary","requirements","actions","selection_signals","risks","funding_notes","confidence"]
}

def load(path):
    try: return json.loads(Path(path).read_text())
    except Exception: return []

def output_text(resp):
    for step in reversed(resp.get("steps") or []):
        if step.get("type") == "model_output":
            parts=[p.get("text","") for p in (step.get("content") or []) if p.get("type") == "text"]
            if parts: return "\n".join(parts)
    raise RuntimeError("Gemini returned no text output")

def call(api_key, model, item):
    prompt = f"""Summarize this postgraduate scholarship/funded opportunity for a research app.
Use ONLY the supplied public metadata. Never invent eligibility, deadlines, funding amounts or guarantees.
If a detail is unclear, explicitly say it must be verified at the official source.

Title: {item.get('title','')}
Provider: {item.get('provider','')}
Country: {item.get('country','')}
Level: {item.get('level','')}
Field: {item.get('field','')}
Funding: {item.get('funding','')}
Deadline: {item.get('deadline','')}
Status: {item.get('status','')}
Summary: {item.get('summary','')}
Requirements: {' | '.join(item.get('requirements') or [])}
Eligibility: {' | '.join(item.get('eligibility') or [])}
Benefits: {' | '.join(item.get('benefits') or [])}
Documents: {' | '.join(item.get('documents') or [])}
"""
    body={
        "model":model,
        "input":prompt,
        "system_instruction":"You are Akademi's cautious scholarship metadata analyst. Be concise, useful and evidence-bound.",
        "store":False,
        "generation_config":{"max_output_tokens":900,"thinking_level":"low"},
        "response_format":{"type":"text","mime_type":"application/json","schema":SCHEMA}
    }
    r=requests.post(
        "https://generativelanguage.googleapis.com/v1beta/interactions",
        headers={"x-goog-api-key":api_key,"Content-Type":"application/json"},
        json=body, timeout=60
    )
    if r.status_code >= 300:
        raise RuntimeError(f"Gemini HTTP {r.status_code}: {r.text[:300]}")
    return json.loads(output_text(r.json()))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--current', default='feed/opportunities.json')
    ap.add_argument('--previous', default='')
    ap.add_argument('--max-new', type=int, default=8)
    args=ap.parse_args()
    current=load(args.current)
    previous=load(args.previous) if args.previous else []
    prev={x.get('id') or x.get('sourceUrl'):x for x in previous if isinstance(x,dict)}
    reused=0
    for item in current:
        old=prev.get(item.get('id') or item.get('sourceUrl'))
        if old and old.get('aiSummary'):
            for f in AI_FIELDS:
                if old.get(f) not in (None,"",[]): item[f]=old.get(f)
            reused += 1

    key=os.getenv('GEMINI_API_KEY','').strip()
    model=os.getenv('GEMINI_MODEL','gemini-3.6-flash').strip() or 'gemini-3.6-flash'
    if not key:
        Path(args.current).write_text(json.dumps(current,ensure_ascii=False,indent=2)+"\n")
        print(f"Gemini secret not configured; reused {reused} previous AI enrichments and skipped new calls.")
        return

    enriched=0
    for item in current:
        if enriched >= args.max_new: break
        if item.get('aiSummary'): continue
        try:
            data=call(key,model,item)
            item.update({
                'aiSummary':data.get('summary',''),
                'aiRequirements':data.get('requirements') or [],
                'aiActions':data.get('actions') or [],
                'aiSelectionSignals':data.get('selection_signals') or [],
                'aiRisks':data.get('risks') or [],
                'aiFundingNotes':data.get('funding_notes',''),
                'aiConfidence':data.get('confidence',''),
                'aiModel':model,
                'aiUpdatedAt':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
            })
            enriched += 1
            time.sleep(.35)
        except Exception as e:
            print(f"AI enrichment skipped for {item.get('title','untitled')}: {e}")

    Path(args.current).write_text(json.dumps(current,ensure_ascii=False,indent=2)+"\n")
    print(f"Gemini enrichment complete: {enriched} new, {reused} reused.")

if __name__ == '__main__': main()
