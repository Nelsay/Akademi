# Akademi premium UI direction

The supplied travel-app references are the visual source of truth for this pass.

- Visual-first discovery rather than database-like screens.
- Pure white cards in light mode.
- 20dp primary screen gutters.
- 8/10/12dp micro spacing; 18/20dp card padding; 28/30dp major section spacing.
- 22-28dp card corner radii depending on visual importance.
- Soft shadows with stronger elevation only on expanded/featured cards.
- Inter as the product typeface; large titles use tighter tracking and heavier weights.
- Image headers should feel like travel destinations: wide, cropped, immersive and rounded by the card container.
- Metadata stays secondary and quiet; title, destination/provider and fit score stay dominant.
- Color is used for navigation, status, discovery and personality—not for filling entire card surfaces.
