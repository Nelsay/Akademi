package com.akademi.app.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.akademi.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Information read from the repository's latest GitHub Release. */
data class AppUpdateInfo(
    val versionName: String,
    val tagName: String,
    val apkUrl: String,
    val notes: String,
    val publishedAt: String,
    val sha256: String = ""
)

object UpdateManager {
    suspend fun check(apiUrl: String): Result<AppUpdateInfo?> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = apiUrl.trim()
            require(endpoint.startsWith("https://")) { "Update source must use HTTPS." }
            val conn = URL(endpoint).openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "Akademi/${BuildConfig.VERSION_NAME}")
            val responseCode = conn.responseCode
            if (responseCode !in 200..299) error("Update server returned HTTP $responseCode")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val json = JSONObject(text)
            val tag = json.optString("tag_name").trim()
            val version = tag.removePrefix("v").removePrefix("V").ifBlank { json.optString("name") }
            val assets = json.optJSONArray("assets")
            var apkUrl = ""
            var assetDigest = ""
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val asset = assets.optJSONObject(i) ?: continue
                    val name = asset.optString("name")
                    if (name.endsWith(".apk", true)) {
                        apkUrl = asset.optString("browser_download_url")
                        assetDigest = asset.optString("digest").removePrefix("sha256:")
                        break
                    }
                }
            }
            if (apkUrl.isBlank()) error("Latest release has no APK asset.")
            val body = json.optString("body")
            val bodyDigest = Regex("(?i)SHA-?256\\s*[:=]\\s*([a-f0-9]{64})").find(body)?.groupValues?.getOrNull(1).orEmpty()
            val info = AppUpdateInfo(
                versionName = version,
                tagName = tag,
                apkUrl = apkUrl,
                notes = body,
                publishedAt = json.optString("published_at"),
                sha256 = assetDigest.ifBlank { bodyDigest }
            )
            if (isNewer(info.versionName, BuildConfig.VERSION_NAME)) info else null
        }
    }

    suspend fun download(context: Context, update: AppUpdateInfo): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(update.apkUrl.startsWith("https://")) { "APK download must use HTTPS." }
            val dir = File(context.cacheDir, "updates").apply { mkdirs() }
            val out = File(dir, "Akademi-${update.versionName}.apk")
            val conn = URL(update.apkUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 60_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "Akademi/${BuildConfig.VERSION_NAME}")
            val code = conn.responseCode
            if (code !in 200..299) error("APK download returned HTTP $code")
            conn.inputStream.use { input -> out.outputStream().use { output -> input.copyTo(output) } }
            conn.disconnect()
            require(out.length() > 100_000) { "Downloaded APK is unexpectedly small." }
            if (update.sha256.isNotBlank()) {
                val actual = sha256(out)
                require(actual.equals(update.sha256, true)) { "APK integrity check failed." }
            }
            out
        }
    }

    /**
     * Android never allows a normal app to silently replace itself. This opens
     * the system-owned installer, preserving the user's final confirmation.
     */
    fun install(context: Context, apk: File): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return "Allow Akademi to install its signed updates, then tap Install update again."
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "Android's installer opened. Confirm the signed update to finish."
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(32 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun isNewer(candidate: String, current: String): Boolean {
        val a = numericParts(candidate)
        val b = numericParts(current)
        val max = maxOf(a.size, b.size)
        for (i in 0 until max) {
            val av = a.getOrElse(i) { 0 }
            val bv = b.getOrElse(i) { 0 }
            if (av != bv) return av > bv
        }
        return false
    }

    private fun numericParts(value: String): List<Int> =
        Regex("\\d+").findAll(value).mapNotNull { it.value.toIntOrNull() }.toList().ifEmpty { listOf(0) }
}
