package com.akademi.app.push

import android.content.Context
import com.akademi.app.notifications.AkademiNotificationManager
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

object OptionalFcmPush {
    const val TOPIC = "akademi_opportunities"

    fun initialize(context: Context) {
        // google_app_id exists only when a valid google-services.json has been processed.
        val configured = context.resources.getIdentifier("google_app_id", "string", context.packageName) != 0
        if (!configured) return
        runCatching { FirebaseMessaging.getInstance().subscribeToTopic(TOPIC) }
    }
}

class AkademiMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: "New Akademi opportunity"
        val body = message.notification?.body ?: message.data["body"] ?: "A new scholarship or funded position was found."
        AkademiNotificationManager.showOpportunity(this, title, body, ("fcm:" + message.messageId.orEmpty() + body).hashCode(), message.data["opportunityId"].orEmpty())
    }
}
