package com.akademi.app.settings

import android.content.Context
import com.akademi.app.BuildConfig
import com.akademi.app.data.TrackerItem
import com.akademi.app.data.UserProfile
import com.akademi.app.ai.GeminiClient
import org.json.JSONArray
import org.json.JSONObject

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class AccentPreset { AURORA, OCEAN, VIOLET, CORAL, SUNSET, MINT, MIDNIGHT }

data class SettingsState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accent: AccentPreset = AccentPreset.AURORA,
    val notifications: Boolean = true,
    val opportunityAlerts: Boolean = true,
    val deadlineAlerts: Boolean = true,
    val refreshOnLaunch: Boolean = true,
    val openLinksExternally: Boolean = false,
    val webPopupsEnabled: Boolean = true,
    val liveFeedUrl: String = BuildConfig.DEFAULT_LIVE_FEED_URL,
    val aiEnabled: Boolean = false,
    val aiModel: String = GeminiClient.DEFAULT_MODEL,
    val aiCacheEnabled: Boolean = true,
    val autoUpdateCheck: Boolean = true,
    val updateApiUrl: String = BuildConfig.DEFAULT_UPDATE_API_URL
)

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("akademi_preferences", Context.MODE_PRIVATE)

    fun loadSettings() = SettingsState(
        themeMode = runCatching { ThemeMode.valueOf(prefs.getString("theme", ThemeMode.SYSTEM.name)!!) }.getOrDefault(ThemeMode.SYSTEM),
        accent = runCatching { AccentPreset.valueOf(prefs.getString("accent", AccentPreset.AURORA.name)!!) }.getOrDefault(AccentPreset.AURORA),
        notifications = prefs.getBoolean("notifications", true),
        opportunityAlerts = prefs.getBoolean("opportunityAlerts", true),
        deadlineAlerts = prefs.getBoolean("deadlineAlerts", true),
        refreshOnLaunch = prefs.getBoolean("refreshOnLaunch", true),
        openLinksExternally = prefs.getBoolean("externalLinks", false),
        webPopupsEnabled = prefs.getBoolean("webPopups", true),
        liveFeedUrl = prefs.getString("liveFeedUrl", BuildConfig.DEFAULT_LIVE_FEED_URL) ?: BuildConfig.DEFAULT_LIVE_FEED_URL,
        aiEnabled = prefs.getBoolean("aiEnabled", false),
        aiModel = prefs.getString("aiModel", GeminiClient.DEFAULT_MODEL) ?: GeminiClient.DEFAULT_MODEL,
        aiCacheEnabled = prefs.getBoolean("aiCacheEnabled", true),
        autoUpdateCheck = prefs.getBoolean("autoUpdateCheck", true),
        updateApiUrl = prefs.getString("updateApiUrl", BuildConfig.DEFAULT_UPDATE_API_URL) ?: BuildConfig.DEFAULT_UPDATE_API_URL
    )

    fun saveSettings(s: SettingsState) {
        prefs.edit()
            .putString("theme", s.themeMode.name)
            .putString("accent", s.accent.name)
            .putBoolean("notifications", s.notifications)
            .putBoolean("opportunityAlerts", s.opportunityAlerts)
            .putBoolean("deadlineAlerts", s.deadlineAlerts)
            .putBoolean("refreshOnLaunch", s.refreshOnLaunch)
            .putBoolean("externalLinks", s.openLinksExternally)
            .putBoolean("webPopups", s.webPopupsEnabled)
            .putString("liveFeedUrl", s.liveFeedUrl)
            .putBoolean("aiEnabled", s.aiEnabled)
            .putString("aiModel", s.aiModel)
            .putBoolean("aiCacheEnabled", s.aiCacheEnabled)
            .putBoolean("autoUpdateCheck", s.autoUpdateCheck)
            .putString("updateApiUrl", s.updateApiUrl)
            .apply()
    }

    fun loadProfile(): UserProfile {
        val countries = prefs.getStringSet("countries", setOf("Germany", "Canada", "Australia", "New Zealand")) ?: emptySet()
        return UserProfile(
            name = prefs.getString("name", "My Profile") ?: "My Profile",
            nationality = prefs.getString("nationality", "Nigeria") ?: "Nigeria",
            degree = prefs.getString("degree", "") ?: "",
            field = prefs.getString("field", "") ?: "",
            cgpa = java.lang.Double.longBitsToDouble(prefs.getLong("cgpa", java.lang.Double.doubleToLongBits(0.0))),
            cgpaScale = java.lang.Double.longBitsToDouble(prefs.getLong("cgpaScale", java.lang.Double.doubleToLongBits(5.0))),
            targetLevel = prefs.getString("targetLevel", "Both") ?: "Both",
            researchInterests = prefs.getString("interests", "") ?: "",
            researchExperience = prefs.getBoolean("researchExperience", false),
            publications = prefs.getInt("publications", 0),
            preferredCountries = countries,
            fullFundingPreferred = prefs.getBoolean("fullFunding", true),
            prPriority = prefs.getInt("prPriority", 80),
            profileImagePath = prefs.getString("profileImagePath", "") ?: "",
            bannerImagePath = prefs.getString("bannerImagePath", "") ?: "",
            bannerStyle = prefs.getInt("bannerStyle", 0),
            headline = prefs.getString("headline", "Postgraduate opportunity explorer") ?: "Postgraduate opportunity explorer"
        )
    }

    fun saveProfile(p: UserProfile) {
        prefs.edit()
            .putString("name", p.name)
            .putString("nationality", p.nationality)
            .putString("degree", p.degree)
            .putString("field", p.field)
            .putLong("cgpa", java.lang.Double.doubleToRawLongBits(p.cgpa))
            .putLong("cgpaScale", java.lang.Double.doubleToRawLongBits(p.cgpaScale))
            .putString("targetLevel", p.targetLevel)
            .putString("interests", p.researchInterests)
            .putBoolean("researchExperience", p.researchExperience)
            .putInt("publications", p.publications)
            .putStringSet("countries", p.preferredCountries)
            .putBoolean("fullFunding", p.fullFundingPreferred)
            .putInt("prPriority", p.prPriority)
            .putString("profileImagePath", p.profileImagePath)
            .putString("bannerImagePath", p.bannerImagePath)
            .putInt("bannerStyle", p.bannerStyle)
            .putString("headline", p.headline)
            .apply()
    }

    fun loadTracker(): List<TrackerItem> {
        val raw = prefs.getString("tracker", "[]") ?: "[]"
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                TrackerItem(o.getString("id"), o.optString("status", "Preparing"), o.optInt("progress", 20), o.optString("notes", ""))
            }
        }.getOrDefault(emptyList())
    }

    fun saveTracker(items: List<TrackerItem>) {
        val a = JSONArray()
        items.forEach { item ->
            a.put(JSONObject().put("id", item.opportunityId).put("status", item.status).put("progress", item.progress).put("notes", item.notes))
        }
        prefs.edit().putString("tracker", a.toString()).apply()
    }

    fun reset() = prefs.edit().clear().apply()
}
