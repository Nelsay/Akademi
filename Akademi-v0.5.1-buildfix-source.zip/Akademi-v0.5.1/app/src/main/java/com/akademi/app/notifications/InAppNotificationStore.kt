package com.akademi.app.notifications

import android.content.Context
import com.akademi.app.data.MatchEngine
import com.akademi.app.data.Opportunity
import com.akademi.app.data.TrackerItem
import com.akademi.app.data.UserProfile
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class AkademiInboxNotification(
    val id: String,
    val type: String,
    val title: String,
    val body: String,
    val opportunityId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

object InAppNotificationStore {
    private const val PREFS = "akademi_notification_center"
    private const val KEY_ITEMS = "items"
    private const val KEY_DISMISSED = "dismissed_ids"
    private const val MAX_ITEMS = 60

    fun load(context: Context): List<AkademiInboxNotification> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]") ?: "[]"
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { index ->
                val o = a.getJSONObject(index)
                AkademiInboxNotification(
                    id = o.getString("id"),
                    type = o.optString("type", "UPDATE"),
                    title = o.optString("title", "Akademi update"),
                    body = o.optString("body", ""),
                    opportunityId = o.optString("opportunityId", ""),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                    isRead = o.optBoolean("isRead", false)
                )
            }.sortedByDescending { it.createdAt }
        }.getOrDefault(emptyList())
    }

    fun unreadCount(context: Context): Int = load(context).count { !it.isRead }

    fun add(context: Context, item: AkademiInboxNotification): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val dismissed = prefs.getStringSet(KEY_DISMISSED, emptySet()) ?: emptySet()
        if (item.id in dismissed) return false
        val current = load(context).toMutableList()
        val existing = current.indexOfFirst { it.id == item.id }
        if (existing >= 0) return false
        current.add(0, item)
        save(context, current.take(MAX_ITEMS))
        return true
    }

    fun markRead(context: Context, id: String) {
        val updated = load(context).map { if (it.id == id) it.copy(isRead = true) else it }
        save(context, updated)
    }

    fun markAllRead(context: Context) {
        save(context, load(context).map { it.copy(isRead = true) })
    }

    fun clear(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val dismissed = (prefs.getStringSet(KEY_DISMISSED, emptySet()) ?: emptySet()).toMutableSet()
        dismissed += load(context).map { it.id }
        prefs.edit().remove(KEY_ITEMS).putStringSet(KEY_DISMISSED, dismissed.toList().takeLast(200).toSet()).apply()
    }

    fun reset(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun markOpportunityRead(context: Context, opportunityId: String) {
        if (opportunityId.isBlank()) return
        val updated = load(context).map {
            if (it.opportunityId == opportunityId) it.copy(isRead = true) else it
        }
        save(context, updated)
    }

    /**
     * Adds useful in-app alerts from the data Akademi already has. IDs are stable,
     * so an item does not become unread again every time the app launches.
     */
    fun sync(
        context: Context,
        profile: UserProfile,
        opportunities: List<Opportunity>,
        tracker: List<TrackerItem>
    ): Boolean {
        var changed = false
        val scored = opportunities
            .map { MatchEngine.score(profile, it) }
            .filter { it.score >= 75 }
            .sortedByDescending { it.score }
            .take(8)

        scored.forEach { match ->
            val o = match.opportunity
            changed = add(
                context,
                AkademiInboxNotification(
                    id = "match:${o.id}",
                    type = "MATCH",
                    title = "${match.score}/100 match for you",
                    body = "${o.title} • ${o.provider} • ${o.country}",
                    opportunityId = o.id
                )
            ) || changed
        }

        val trackedIds = tracker.map { it.opportunityId }.toSet()
        val today = LocalDate.now()
        opportunities.filter { it.id in trackedIds }.forEach { o ->
            val due = parseIsoDate(o.deadline) ?: return@forEach
            val days = ChronoUnit.DAYS.between(today, due).toInt()
            if (days in 0..30) {
                val label = when (days) {
                    0 -> "due today"
                    1 -> "due tomorrow"
                    else -> "due in $days days"
                }
                changed = add(
                    context,
                    AkademiInboxNotification(
                        id = "tracker-deadline:${o.id}:${due}",
                        type = "DEADLINE",
                        title = "Application $label",
                        body = "${o.title} • ${o.provider}",
                        opportunityId = o.id
                    )
                ) || changed
            }
        }
        return changed
    }

    private fun save(context: Context, items: List<AkademiInboxNotification>) {
        val a = JSONArray()
        items.sortedByDescending { it.createdAt }.take(MAX_ITEMS).forEach { item ->
            a.put(
                JSONObject()
                    .put("id", item.id)
                    .put("type", item.type)
                    .put("title", item.title)
                    .put("body", item.body)
                    .put("opportunityId", item.opportunityId)
                    .put("createdAt", item.createdAt)
                    .put("isRead", item.isRead)
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS, a.toString()).apply()
    }

    private fun parseIsoDate(value: String): LocalDate? = runCatching {
        LocalDate.parse(Regex("\\b\\d{4}-\\d{2}-\\d{2}\\b").find(value)?.value ?: value)
    }.getOrNull()
}
