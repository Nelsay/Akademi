package com.akademi.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat

data class AkademiLaunchTarget(
    val opportunityId: String = "",
    val openNotifications: Boolean = false,
    val nonce: Long = System.nanoTime()
)

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_OPEN_NOTIFICATIONS = "akademi_open_notifications"
        const val EXTRA_OPPORTUNITY_ID = "akademi_opportunity_id"
    }

    private var launchTarget by mutableStateOf<AkademiLaunchTarget?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        launchTarget = parseLaunchTarget(intent)
        setContent {
            AkademiApp(
                launchTarget = launchTarget,
                onLaunchTargetConsumed = { launchTarget = null }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        launchTarget = parseLaunchTarget(intent)
    }

    private fun parseLaunchTarget(intent: Intent?): AkademiLaunchTarget? {
        if (intent == null) return null
        val openNotifications = intent.getBooleanExtra(EXTRA_OPEN_NOTIFICATIONS, false)
        val opportunityId = intent.getStringExtra(EXTRA_OPPORTUNITY_ID).orEmpty()
        if (!openNotifications && opportunityId.isBlank()) return null
        return AkademiLaunchTarget(opportunityId, openNotifications)
    }
}
