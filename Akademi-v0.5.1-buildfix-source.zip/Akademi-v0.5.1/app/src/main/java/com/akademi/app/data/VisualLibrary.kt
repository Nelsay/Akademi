package com.akademi.app.data

/**
 * Akademi's bundled editorial image library.
 *
 * Real source imagery always wins when it is available. Generated/editorial
 * assets are only fallbacks and are intentionally varied so a discovery list
 * does not reuse the same picture on multiple cards.
 */
object VisualLibrary {
    val all = listOf(
        "res://akademi_visual_01_candid_welcome_in_a_bright_terminal",
        "res://akademi_visual_02_coastal_campus_walkway_stroll",
        "res://akademi_visual_03_collaborative_high_tech_laboratory_research",
        "res://akademi_visual_04_collaborative_modern_design_studio",
        "res://akademi_visual_05_collaborative_robotics_makerspace_workshop",
        "res://akademi_visual_06_cozy_home_office_video_call",
        "res://akademi_visual_07_cozy_sunlit_bedroom_workspace",
        "res://akademi_visual_08_golden_hour_cyclist_on_historic_campus_street",
        "res://akademi_visual_09_grand_library_reading_room",
        "res://akademi_visual_10_joyful_graduate_in_a_sunlit_campus",
        "res://akademi_visual_11_midnight_coding_in_the_neon_workspace",
        "res://akademi_visual_12_modern_lecture_hall_seminar",
        "res://akademi_visual_13_mountain_train_journey_begins",
        "res://akademi_visual_14_professional_networking_in_a_bright_atrium",
        "res://akademi_visual_15_professor_in_a_bright_research_office",
        "res://akademi_visual_16_rainy_blue_hour_campus_walk",
        "res://akademi_visual_17_rooftop_cafe_workday",
        "res://akademi_visual_18_snowy_tramway_by_the_grand_hall",
        "res://akademi_visual_19_springtime_campus_study_group",
        "res://akademi_visual_20_sunlit_artist_studio_workspace",
        "res://akademi_visual_21_sunlit_greenhouse_plant_science_lab",
        "res://akademi_visual_22_sunlit_travel_themed_study_workspace",
        "res://akademi_visual_23_sunny_campus_courtyard_walkway",
        "res://akademi_visual_24_sunny_waterfront_promenade_stroll",
        "res://akademi_visual_25_travel_planning_desk_flat_lay",
        "res://akademi_visual_26_traveler_checking_airport_departures"
    )

    /** Cropped editorial portraits used only as illustrative researcher avatars. */
    val professorAvatars = listOf(
        "res://akademi_avatar_01", "res://akademi_avatar_02", "res://akademi_avatar_03",
        "res://akademi_avatar_04", "res://akademi_avatar_06", "res://akademi_avatar_07",
        "res://akademi_avatar_09", "res://akademi_avatar_10", "res://akademi_avatar_11",
        "res://akademi_avatar_12", "res://akademi_avatar_13", "res://akademi_avatar_14",
        "res://akademi_avatar_15", "res://akademi_avatar_16",
        "res://akademi_avatar_17", "res://akademi_avatar_18", "res://akademi_avatar_19",
        "res://akademi_avatar_20", "res://akademi_avatar_21", "res://akademi_avatar_22"
    )

    private fun stableIndex(key: String, size: Int): Int {
        val positive = key.fold(17) { acc, c -> (acc * 31 + c.code) and 0x7fffffff }
        return positive % size.coerceAtLeast(1)
    }

    fun generic(key: String): String = all[stableIndex(key, all.size)]
    fun professorAvatar(index: Int): String = professorAvatars[index.mod(professorAvatars.size)]

    fun forOpportunity(o: Opportunity): String = o.imageUrl.ifBlank { fallbackForOpportunity(o) }

    // Scholarship/opportunity fallbacks use a dedicated image pool so they do not
    // visually collide with country or story cards on the same discovery surfaces.
    private fun opportunityFallbackCandidates(o: Opportunity): List<String> {
        val text = "${o.title} ${o.field} ${o.keywords.joinToString(" ")} ${o.country}".lowercase()
        return when {
            listOf("computer", "software", "data", "ai ", "artificial intelligence", "robot", "engineering").any { it in text } ->
                listOf(all[4], all[10], all[3], all[11], all[8])
            listOf("health", "medical", "medicine", "biotech", "genomic", "molecular").any { it in text } ->
                listOf(all[2], all[11], all[8], all[14])
            listOf("plant", "agriculture", "environment", "climate", "ecology", "botany").any { it in text } ->
                listOf(all[20], all[22], all[8], all[11])
            listOf("art", "design", "architecture", "creative", "humanities").any { it in text } ->
                listOf(all[19], all[3], all[8], all[22])
            listOf("business", "finance", "econom", "management", "policy", "law").any { it in text } ->
                listOf(all[8], all[14], all[11], all[22])
            o.level.contains("PhD", true) -> listOf(all[14], all[8], all[11], all[2], all[20])
            else -> listOf(all[22], all[8], all[11], all[2], all[3], all[4], all[10], all[14], all[19], all[20])
        }
    }

    fun fallbackForOpportunity(o: Opportunity): String {
        val candidates = opportunityFallbackCandidates(o)
        return candidates[stableIndex(o.id, candidates.size)]
    }

    /**
     * Produces one image per opportunity without visual repetition in the list.
     * Duplicate source images are replaced with a relevant unused editorial asset.
     */
    fun uniqueOpportunityVisuals(opportunities: List<Opportunity>): Map<String, String> {
        val used = linkedSetOf<String>()
        val result = linkedMapOf<String, String>()
        opportunities.forEach { o ->
            val remote = o.imageUrl.trim()
            val candidates = opportunityFallbackCandidates(o)
            val rotated = if (candidates.isEmpty()) emptyList() else {
                val start = stableIndex(o.id, candidates.size)
                candidates.drop(start) + candidates.take(start)
            }
            val chosen = when {
                remote.isNotBlank() && remote !in used -> remote
                else -> rotated.firstOrNull { it !in used }
                    ?: all.firstOrNull { it !in used }
                    ?: rotated.firstOrNull()
                    ?: generic(o.id)
            }
            used += chosen
            result[o.id] = chosen
        }
        return result
    }

    fun forResearcher(r: Researcher): String = professorAvatar(stableIndex(r.id, professorAvatars.size))

    /** Directions are intentionally text-led in v0.5; retained for other guidance surfaces. */
    fun forDirection(title: String, description: String = ""): String = generic("$title $description")

    // Country cards have their own destination-only pool.
    private val countryPool = listOf(all[1], all[7], all[12], all[15], all[17], all[23])

    private fun preferredCountryVisual(country: String): String = when (country.lowercase()) {
        "germany" -> all[17]
        "canada" -> all[15]
        "australia" -> all[1]
        "new zealand" -> all[12]
        "united kingdom", "uk" -> all[7]
        "ireland" -> all[23]
        "netherlands" -> all[15]
        "sweden", "finland", "denmark", "norway" -> all[17]
        "france" -> all[23]
        else -> countryPool[stableIndex("country-$country", countryPool.size)]
    }

    fun forCountry(country: String): String = preferredCountryVisual(country)

    fun uniqueCountryVisuals(countries: List<String>): Map<String, String> {
        val used = linkedSetOf<String>()
        return countries.associateWith { country ->
            val preferred = preferredCountryVisual(country)
            val startIndex = stableIndex(country, countryPool.size)
            val rotated = countryPool.drop(startIndex) + countryPool.take(startIndex)
            val chosen = if (preferred !in used) preferred else rotated.firstOrNull { it !in used } ?: preferred
            used += chosen
            chosen
        }
    }

    // Story/video fallbacks are intentionally separate from scholarship and destination imagery.
    private val storyPool = listOf(all[0], all[5], all[6], all[9], all[13], all[16], all[18], all[21], all[24], all[25])

    fun forStory(key: String): String = storyPool[stableIndex(key, storyPool.size)]

    fun uniqueStoryVisuals(keys: List<String>): Map<String, String> {
        val used = linkedSetOf<String>()
        return keys.associateWith { key ->
            val startIndex = stableIndex(key, storyPool.size)
            val rotated = storyPool.drop(startIndex) + storyPool.take(startIndex)
            val chosen = rotated.firstOrNull { it !in used } ?: storyPool[startIndex]
            used += chosen
            chosen
        }
    }

    fun forHomeTip(key: String): String = listOf(all[24], all[21], all[6], all[8], all[16], all[5])[stableIndex(key, 6)]

    fun forHero(profile: UserProfile): String {
        if (profile.bannerImagePath.isNotBlank()) return profile.bannerImagePath
        return listOf(all[22], all[1], all[17], all[23], all[15])[profile.bannerStyle % 5]
    }
}
