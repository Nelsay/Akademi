package com.akademi.app.data

data class HomeFeedItem(
    val id: String,
    val type: String,
    val title: String,
    val body: String,
    val source: String,
    val url: String = "",
    val imageUrl: String = "",
    val opportunityId: String = "",
    val badge: String = "For you"
)

object HomeFeedBuilder {
    fun build(profile: UserProfile, opportunities: List<Opportunity>): List<HomeFeedItem> {
        val scored = opportunities.map { MatchEngine.score(profile, it) }.sortedByDescending { it.score }
        val opportunityPosts = scored.take(8).map { s ->
            val o = s.opportunity
            HomeFeedItem(
                id = "op-${o.id}", type = "opportunity", title = o.title,
                body = o.aiSummary.ifBlank { o.summary }.ifBlank { "${o.funding} • ${o.country} • ${o.level}" }, source = "${o.provider} • ${o.country}",
                url = o.sourceUrl, imageUrl = VisualLibrary.forOpportunity(o), opportunityId = o.id,
                badge = "${s.score}/100 match"
            )
        }
        val interest = profile.researchInterests.ifBlank { profile.field.ifBlank { "postgraduate study" } }
        val encoded = java.net.URLEncoder.encode("international scholarship $interest success story", java.nio.charset.StandardCharsets.UTF_8.toString())
        val evergreen = listOf(
            HomeFeedItem("video-radar", "video", "Scholarship video radar", "Watch current application walkthroughs, interviews and awardee experiences related to your interests. Videos open inside Akademi and support full-screen playback.", "YouTube", "https://www.youtube.com/results?search_query=$encoded", imageUrl = VisualLibrary.forStory("video-radar"), badge = "Video"),
            HomeFeedItem("application-tip", "tip", "A better scholarship routine", "Save promising opportunities first, verify the official deadline, then work backwards from references, documents, supervisor contact and your motivation letter. Akademi keeps these steps in your tracker.", "Akademi Guide", imageUrl = VisualLibrary.forHomeTip("application-tip"), badge = "Quick guide"),
            HomeFeedItem("profile-tip", "tip", "Your profile changes the entire app", "Update your CGPA, degree, research interests, target level and preferred countries whenever your plans change. Directions, professors and opportunity rankings refresh around your profile.", "Akademi", imageUrl = VisualLibrary.forHomeTip("profile-tip"), badge = "Profile tip")
        )
        return (opportunityPosts.take(3) + evergreen.take(1) + opportunityPosts.drop(3).take(3) + evergreen.drop(1) + opportunityPosts.drop(6)).distinctBy { it.id }
    }
}
