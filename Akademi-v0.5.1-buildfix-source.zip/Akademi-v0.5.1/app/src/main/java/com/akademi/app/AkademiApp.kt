package com.akademi.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Message
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.akademi.app.data.*
import com.akademi.app.ai.AiInsightCache
import com.akademi.app.ai.GeminiClient
import com.akademi.app.ai.SecureGeminiKeyStore
import com.akademi.app.settings.*
import com.akademi.app.notifications.AkademiNotificationManager
import com.akademi.app.notifications.AkademiInboxNotification
import com.akademi.app.notifications.InAppNotificationStore
import com.akademi.app.push.OptionalFcmPush
import com.akademi.app.update.AppUpdateInfo
import com.akademi.app.update.UpdateManager
import com.akademi.app.ui.AkademiMark
import com.akademi.app.ui.AkademiWordmark
import com.akademi.app.ui.SmartImage
import com.akademi.app.ui.theme.AkademiTheme
import com.akademi.app.ui.theme.Gold
import com.akademi.app.ui.theme.Teal
import com.akademi.app.ui.theme.accentGradient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Screen { HOME, DISCOVER, RESEARCH, TRACKER, PROFILE, SETTINGS, COUNTRIES, STORIES, NOTIFICATIONS, DETAIL, WEB }

@Composable
fun AkademiApp(
    launchTarget: AkademiLaunchTarget? = null,
    onLaunchTargetConsumed: () -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { AppPreferences(context) }
    var settings by remember { mutableStateOf(prefs.loadSettings()) }
    var profile by remember { mutableStateOf(prefs.loadProfile()) }
    var tracker by remember { mutableStateOf(prefs.loadTracker()) }
    var opportunities by remember { mutableStateOf(SeedData.opportunities) }
    var selected by remember { mutableStateOf<Opportunity?>(null) }
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var lastMain by rememberSaveable { mutableStateOf(Screen.HOME) }
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var remoteMessage by remember { mutableStateOf<String?>(null) }
    var discoverQuery by rememberSaveable { mutableStateOf("") }
    var homeRefreshNonce by rememberSaveable { mutableIntStateOf(0) }
    var webUrl by rememberSaveable { mutableStateOf("") }
    var returnScreen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val scope = rememberCoroutineScope()
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    var notificationVersion by remember { mutableIntStateOf(0) }
    val inboxNotifications = remember(notificationVersion, screen, launchTarget?.nonce) { InAppNotificationStore.load(context) }

    fun go(next: Screen) {
        if (next in listOf(Screen.HOME, Screen.DISCOVER, Screen.RESEARCH, Screen.TRACKER, Screen.PROFILE)) lastMain = next
        screen = next
    }
    fun openInside(url: String) {
        returnScreen = screen
        webUrl = url
        screen = Screen.WEB
    }
    fun openOutside(url: String) { openUrl(context, url) }
    fun openLink(url: String) { if (settings.openLinksExternally) openOutside(url) else openInside(url) }
    fun loadRemote(feedOverride: String? = null) {
        val feedUrl = feedOverride?.trim().orEmpty().ifBlank { settings.liveFeedUrl }
        if (feedUrl.isBlank()) {
            remoteMessage = "Add a normalized HTTPS feed URL in Settings to enable live opportunity updates."
            return
        }
        scope.launch {
            remoteMessage = "Refreshing live feed…"
            val result = RemoteOpportunityRepository.fetch(feedUrl)
            result.onSuccess { remote ->
                opportunities = (remote + SeedData.opportunities).distinctBy { it.id }
                remoteMessage = "Loaded ${remote.size} live opportunities."
            }.onFailure { remoteMessage = "Feed refresh failed: ${it.message ?: "unknown error"}" }
        }
    }

    LaunchedEffect(Unit) {
        delay(850)
        showSplash = false
        if (settings.refreshOnLaunch && settings.liveFeedUrl.isNotBlank()) loadRemote()
    }

    LaunchedEffect(settings.notifications, settings.liveFeedUrl) {
        if (settings.notifications) OptionalFcmPush.initialize(context)
        AkademiNotificationManager.schedule(context, settings.notifications && settings.liveFeedUrl.isNotBlank())
        if (settings.notifications && Build.VERSION.SDK_INT >= 33 && !AkademiNotificationManager.canNotify(context)) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Automatic update discovery: checks the signed release channel and surfaces
    // a durable inbox item instead of silently downloading/installing anything.
    LaunchedEffect(settings.autoUpdateCheck, settings.updateApiUrl) {
        if (settings.autoUpdateCheck && settings.updateApiUrl.isNotBlank()) {
            UpdateManager.check(settings.updateApiUrl).onSuccess { info ->
                if (info != null) {
                    val added = InAppNotificationStore.add(
                        context,
                        AkademiInboxNotification(
                            id = "app-update:${info.versionName}",
                            type = "UPDATE",
                            title = "Akademi ${info.versionName} is ready",
                            body = "A signed update is available. Open Settings to review and install it."
                        )
                    )
                    if (added) notificationVersion++
                }
            }
        }
    }

    LaunchedEffect(profile, opportunities, tracker, settings.notifications) {
        if (settings.notifications && InAppNotificationStore.sync(context, profile, opportunities, tracker)) {
            notificationVersion++
        }
    }

    LaunchedEffect(launchTarget?.nonce, opportunities) {
        val target = launchTarget ?: return@LaunchedEffect
        if (target.opportunityId.isNotBlank()) {
            val opportunity = opportunities.firstOrNull { it.id == target.opportunityId }
            if (opportunity != null) {
                InAppNotificationStore.markOpportunityRead(context, target.opportunityId)
                notificationVersion++
                selected = opportunity
                screen = Screen.DETAIL
            } else if (target.openNotifications) {
                screen = Screen.NOTIFICATIONS
            }
        } else if (target.openNotifications) {
            screen = Screen.NOTIFICATIONS
        }
        onLaunchTargetConsumed()
    }

    BackHandler(enabled = !showSplash && screen != Screen.HOME && screen != Screen.WEB) {
        screen = when (screen) {
            Screen.DETAIL, Screen.COUNTRIES, Screen.STORIES, Screen.NOTIFICATIONS -> lastMain
            Screen.SETTINGS -> Screen.PROFILE
            Screen.DISCOVER, Screen.RESEARCH, Screen.TRACKER, Screen.PROFILE -> Screen.HOME
            else -> screen
        }
    }

    AkademiTheme(settings) {
        if (showSplash) {
            SplashScreen()
        } else {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (screen) {
                    Screen.DETAIL -> OpportunityDetailScreen(
                        scored = selected?.let { MatchEngine.score(profile, it) },
                        tracked = selected?.let { o -> tracker.any { it.opportunityId == o.id } } == true,
                        profile = profile,
                        settings = settings,
                        onBack = { screen = lastMain },
                        onOpenInside = { selected?.sourceUrl?.let { openInside(it) } },
                        onOpenExternal = { selected?.sourceUrl?.let { openOutside(it) } },
                        onApplyInside = { selected?.let { openInside(it.applicationUrl.ifBlank { it.sourceUrl }) } },
                        onTrack = {
                            selected?.let { o ->
                                if (tracker.none { it.opportunityId == o.id }) {
                                    tracker = tracker + TrackerItem(o.id)
                                    prefs.saveTracker(tracker)
                                }
                            }
                        }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        settings = settings,
                        onSettings = { settings = it; prefs.saveSettings(it) },
                        remoteMessage = remoteMessage,
                        onRefresh = { url -> loadRemote(url) },
                        onBack = { screen = Screen.PROFILE },
                        onReset = {
                            prefs.reset()
                            InAppNotificationStore.reset(context)
                            notificationVersion++
                            settings = SettingsState()
                            profile = UserProfile()
                            tracker = emptyList()
                            opportunities = SeedData.opportunities
                            remoteMessage = "Local Akademi data reset."
                        }
                    )
                    Screen.COUNTRIES -> CountryInsightsScreen(onBack = { screen = lastMain }, onOpen = { openInside(it) }, onOpenExternal = { openOutside(it) })
                    Screen.STORIES -> SuccessStoriesScreen(profile = profile, onBack = { screen = lastMain }, onOpen = { openInside(it) }, onOpenExternal = { openOutside(it) })
                    Screen.NOTIFICATIONS -> NotificationCenterScreen(
                        settings = settings,
                        notifications = inboxNotifications,
                        opportunities = opportunities,
                        onBack = { screen = lastMain },
                        onMarkAllRead = {
                            InAppNotificationStore.markAllRead(context)
                            notificationVersion++
                        },
                        onClear = {
                            InAppNotificationStore.reset(context)
                            notificationVersion++
                        },
                        onNotification = { notice ->
                            InAppNotificationStore.markRead(context, notice.id)
                            notificationVersion++
                            if (notice.type == "UPDATE") {
                                screen = Screen.SETTINGS
                            } else {
                                opportunities.firstOrNull { it.id == notice.opportunityId }?.let { opportunity ->
                                    selected = opportunity
                                    screen = Screen.DETAIL
                                }
                            }
                        }
                    )
                    Screen.WEB -> WebScreen(url = webUrl, popupsEnabled = settings.webPopupsEnabled, onExternal = { openOutside(webUrl) }, onBack = { screen = returnScreen })
                    else -> MainScaffold(
                        screen = screen,
                        onNavigate = ::go
                    ) { padding, targetScreen ->
                        when (targetScreen) {
                            Screen.HOME -> HomeScreen(
                                modifier = Modifier.padding(padding), profile = profile, settings = settings, opportunities = opportunities,
                                tracker = tracker, onDiscover = { go(Screen.DISCOVER) }, onResearch = { go(Screen.RESEARCH) },
                                onCountries = { screen = Screen.COUNTRIES }, onStories = { screen = Screen.STORIES },
                                unreadNotifications = inboxNotifications.count { !it.isRead },
                                onNotifications = { notificationVersion++; screen = Screen.NOTIFICATIONS },
                                refreshNonce = homeRefreshNonce,
                                onSearch = { q -> discoverQuery = q.trim(); go(Screen.DISCOVER) },
                                onRefresh = { homeRefreshNonce++; loadRemote() }, onOpenWeb = { openInside(it) }, onOpenExternal = { openOutside(it) },
                                onOpportunity = { selected = it; screen = Screen.DETAIL }
                            )
                            Screen.DISCOVER -> DiscoverScreen(
                                modifier = Modifier.padding(padding), profile = profile, opportunities = opportunities, initialQuery = discoverQuery,
                                remoteMessage = remoteMessage, onRefresh = { homeRefreshNonce++; loadRemote() },
                                onOpportunity = { selected = it; screen = Screen.DETAIL }, onOpenExternal = { openOutside(it) }
                            )
                            Screen.RESEARCH -> ResearchScreen(
                                modifier = Modifier.padding(padding), profile = profile,
                                onOpen = { openInside(it) }, onOpenExternal = { openOutside(it) }, onStories = { screen = Screen.STORIES }
                            )
                            Screen.TRACKER -> TrackerScreen(
                                modifier = Modifier.padding(padding), opportunities = opportunities, tracker = tracker,
                                onTracker = { tracker = it; prefs.saveTracker(it) },
                                onOpen = { o -> selected = o; screen = Screen.DETAIL }
                            )
                            Screen.PROFILE -> ProfileScreen(
                                modifier = Modifier.padding(padding), profile = profile, settings = settings,
                                onProfile = { profile = it; prefs.saveProfile(it) },
                                onSettings = { screen = Screen.SETTINGS }, onCountries = { screen = Screen.COUNTRIES }
                            )
                            else -> Unit
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.secondary).systemBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(shape = RoundedCornerShape(30.dp), color = Color.White, shadowElevation = 8.dp) {
                Box(Modifier.padding(14.dp), contentAlignment = Alignment.Center) { AkademiMark(Modifier.size(104.dp)) }
            }
            Spacer(Modifier.height(18.dp))
            Text("Akademi", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.SemiBold)
            Text("OPPORTUNITY INTELLIGENCE", color = Color(0xFF7FD1C9), fontSize = 12.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
            Text("SCHOLARSHIPS • RESEARCH • GLOBAL IMPACT", color = Color.White.copy(alpha = .78f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun MainScaffold(screen: Screen, onNavigate: (Screen) -> Unit, content: @Composable (PaddingValues, Screen) -> Unit) {
    data class NavItem(
        val screen: Screen,
        val label: String,
        val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
        val icon: androidx.compose.ui.graphics.vector.ImageVector
    )
    val tabs = listOf(
        NavItem(Screen.HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home),
        NavItem(Screen.DISCOVER, "Explore", Icons.Filled.TravelExplore, Icons.Outlined.TravelExplore),
        NavItem(Screen.RESEARCH, "Research", Icons.Filled.School, Icons.Outlined.School),
        NavItem(Screen.TRACKER, "Saved", Icons.Filled.Bookmark, Icons.Outlined.BookmarkBorder),
        NavItem(Screen.PROFILE, "Profile", Icons.Filled.Person, Icons.Outlined.Person)
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Surface(
                modifier = Modifier.navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp),
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(28.dp),
                shadowElevation = 12.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(.05f))
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    tabs.forEach { item ->
                        val selected = screen == item.screen
                        Column(
                            modifier = Modifier.width(62.dp).clip(RoundedCornerShape(20.dp)).clickable { onNavigate(item.screen) }.padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (selected) MaterialTheme.colorScheme.primary.copy(.12f) else Color.Transparent
                            ) {
                                Icon(
                                    if (selected) item.selectedIcon else item.icon,
                                    item.label,
                                    modifier = Modifier.padding(7.dp).size(if (selected) 23.dp else 21.dp),
                                    tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.38f)
                                )
                            }
                            AnimatedVisibility(selected) {
                                Text(item.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 1.dp))
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                (fadeIn(tween(180)) + slideInHorizontally(tween(240)) { it / 10 }) togetherWith
                    (fadeOut(tween(130)) + slideOutHorizontally(tween(200)) { -it / 14 })
            },
            label = "pageTransition"
        ) { target -> content(padding, target) }
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineSmall)
            subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f), modifier = Modifier.padding(top = 3.dp)) }
        }
        trailing?.invoke()
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    profile: UserProfile,
    settings: SettingsState,
    opportunities: List<Opportunity>,
    tracker: List<TrackerItem>,
    onDiscover: () -> Unit,
    onResearch: () -> Unit,
    onCountries: () -> Unit,
    onStories: () -> Unit,
    unreadNotifications: Int,
    onNotifications: () -> Unit,
    refreshNonce: Int,
    onSearch: (String) -> Unit,
    onRefresh: () -> Unit,
    onOpenWeb: (String) -> Unit,
    onOpenExternal: (String) -> Unit,
    onOpportunity: (Opportunity) -> Unit
) {
    val scored = remember(profile, opportunities) { opportunities.map { MatchEngine.score(profile, it) }.sortedByDescending { it.score } }
    val baseFeed = remember(profile, opportunities) { HomeFeedBuilder.build(profile, opportunities) }
    val feed = remember(baseFeed, refreshNonce) {
        if (baseFeed.isEmpty()) baseFeed else {
            val offset = (refreshNonce % baseFeed.size).coerceAtLeast(0)
            baseFeed.drop(offset) + baseFeed.take(offset)
        }
    }
    val feedOpportunities = remember(feed, opportunities) {
        feed.mapNotNull { item -> opportunities.firstOrNull { it.id == item.opportunityId } }
    }
    val opportunityVisuals = remember(feedOpportunities) { VisualLibrary.uniqueOpportunityVisuals(feedOpportunities) }
    val otherKeys = remember(feed) { feed.filter { it.opportunityId.isBlank() }.map { it.id } }
    val otherVisuals = remember(otherKeys) { VisualLibrary.uniqueStoryVisuals(otherKeys) }
    val countries = profile.preferredCountries.toList()
    val countryVisuals = remember(countries) { VisualLibrary.uniqueCountryVisuals(countries) }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 36.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AkademiWordmark(compact = true, modifier = Modifier.weight(1f))
                BadgedBox(
                    badge = {
                        if (unreadNotifications > 0) {
                            Badge(containerColor = MaterialTheme.colorScheme.error) {
                                Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString())
                            }
                        }
                    }
                ) {
                    Surface(
                        modifier = Modifier.clip(CircleShape).clickable(onClick = onNotifications),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(.10f)
                    ) {
                        Icon(
                            if (unreadNotifications > 0) Icons.Filled.Notifications else Icons.Outlined.Notifications,
                            "Notifications",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(10.dp).size(20.dp)
                        )
                    }
                }
            }
        }
        item { HomeProfileHero(profile, settings, onSearch) }
        item {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("${scored.count { it.score >= 70 }}", "Strong matches", Modifier.weight(1f))
                StatCard("${opportunities.size}", "Live radar", Modifier.weight(1f))
                StatCard("${tracker.size}", "In tracker", Modifier.weight(1f))
            }
        }
        item { SectionTitle("Explore your route") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                item { TravelActionCard("Opportunities", "Funding", Icons.Outlined.FlightTakeoff, onDiscover) }
                item { TravelActionCard("Professors", "Research", Icons.Outlined.Groups, onResearch) }
                item { TravelActionCard("Countries", "Study paths", Icons.Outlined.Public, onCountries) }
                item { TravelActionCard("Stories", "Experiences", Icons.Outlined.PlayCircle, onStories) }
            }
        }
        if (countries.isNotEmpty()) {
            item { SectionTitle("Countries on your radar") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(countries) { country ->
                        CountryMiniCard(country, countryVisuals[country] ?: VisualLibrary.forCountry(country), onCountries)
                    }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 30.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Akademi Pulse", style = MaterialTheme.typography.titleLarge)
                    Text("Fresh picks for your profile", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 2.dp))
                }
                FilledIconButton(
                    onClick = onRefresh,
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White)
                ) {
                    Icon(Icons.Outlined.Refresh, "Refresh feed")
                }
            }
        }
        items(feed, key = { it.id }) { item ->
            val opportunity = opportunities.firstOrNull { it.id == item.opportunityId }
            HomeFeedCard(
                item = item,
                opportunity = opportunity,
                visualOverride = opportunity?.let { opportunityVisuals[it.id] } ?: otherVisuals[item.id].orEmpty(),
                onOpportunity = onOpportunity,
                onOpenWeb = onOpenWeb,
                onOpenExternal = onOpenExternal
            )
        }
        item {
            InfoBanner(
                "Your feed follows you",
                "Change your degree, CGPA, interests, target level or preferred countries and Akademi re-ranks the experience around your profile."
            )
        }
    }
}


@Composable
private fun NotificationCenterScreen(
    settings: SettingsState,
    notifications: List<AkademiInboxNotification>,
    opportunities: List<Opportunity>,
    onBack: () -> Unit,
    onMarkAllRead: () -> Unit,
    onClear: () -> Unit,
    onNotification: (AkademiInboxNotification) -> Unit
) {
    var unreadOnly by rememberSaveable { mutableStateOf(false) }
    val visible = remember(notifications, unreadOnly) {
        if (unreadOnly) notifications.filter { !it.isRead } else notifications
    }
    val unreadCount = notifications.count { !it.isRead }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 34.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Outlined.ArrowBack, "Back")
                }
                Column(Modifier.weight(1f).padding(start = 4.dp)) {
                    Text("Notifications", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        if (unreadCount == 0) "You're all caught up" else "$unreadCount unread update${if (unreadCount == 1) "" else "s"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(.56f)
                    )
                }
                if (notifications.isNotEmpty()) {
                    IconButton(onClick = onClear) {
                        Icon(Icons.Outlined.DeleteSweep, "Clear notifications", tint = MaterialTheme.colorScheme.onSurface.copy(.52f))
                    }
                }
            }
        }

        item {
            ElevatedCard(
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 5.dp)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = if (settings.notifications) MaterialTheme.colorScheme.primary.copy(.12f) else MaterialTheme.colorScheme.error.copy(.10f)
                    ) {
                        Icon(
                            if (settings.notifications) Icons.Filled.NotificationsActive else Icons.Outlined.NotificationsOff,
                            null,
                            tint = if (settings.notifications) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(10.dp).size(22.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (settings.notifications) "Akademi alerts are active" else "Akademi alerts are paused",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            if (settings.notifications) "Strong matches and tracked deadlines appear here and can also reach your device." else "Turn notifications back on in Settings when you want match and deadline alerts.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !unreadOnly,
                    onClick = { unreadOnly = false },
                    label = { Text("All") },
                    leadingIcon = if (!unreadOnly) {{ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }} else null
                )
                FilterChip(
                    selected = unreadOnly,
                    onClick = { unreadOnly = true },
                    label = { Text("Unread") },
                    leadingIcon = if (unreadOnly) {{ Icon(Icons.Filled.Check, null, Modifier.size(16.dp)) }} else null
                )
                Spacer(Modifier.weight(1f))
                if (unreadCount > 0) {
                    TextButton(onClick = onMarkAllRead) { Text("Mark all read") }
                }
            }
        }

        if (visible.isEmpty()) {
            item {
                ElevatedCard(
                    Modifier.padding(horizontal = 20.dp, vertical = 18.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        SmartImage(VisualLibrary.forHomeTip("notifications-empty"), Modifier.fillMaxWidth().height(180.dp))
                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                if (unreadOnly) "No unread notifications" else "Nothing new yet",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                if (unreadOnly) "Switch to All to revisit earlier alerts." else "When Akademi finds a strong match or a tracked deadline gets close, it will appear here.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                                modifier = Modifier.padding(top = 5.dp)
                            )
                        }
                    }
                }
            }
        } else {
            items(visible, key = { it.id }) { notice ->
                val opportunity = opportunities.firstOrNull { it.id == notice.opportunityId }
                NotificationInboxCard(
                    notice = notice,
                    opportunity = opportunity,
                    onClick = { onNotification(notice) }
                )
            }
        }
    }
}

@Composable
private fun NotificationInboxCard(
    notice: AkademiInboxNotification,
    opportunity: Opportunity?,
    onClick: () -> Unit
) {
    val accent = when (notice.type) {
        "DEADLINE" -> MaterialTheme.colorScheme.error
        "MATCH" -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondary
    }
    ElevatedCard(
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 7.dp).fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (notice.isRead) 3.dp else 7.dp)
    ) {
        Column {
            if (opportunity != null) {
                Box(Modifier.fillMaxWidth().height(128.dp)) {
                    SmartImage(VisualLibrary.forOpportunity(opportunity), Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.48f)))))
                    Surface(
                        modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(.94f)
                    ) {
                        Row(Modifier.padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (notice.type == "DEADLINE") Icons.Outlined.Schedule else Icons.Outlined.Star,
                                null,
                                tint = accent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(if (notice.type == "DEADLINE") "Deadline" else "Match", style = MaterialTheme.typography.labelSmall, color = accent)
                        }
                    }
                    if (!notice.isRead) {
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(12.dp).size(10.dp).clip(CircleShape).background(MaterialTheme.colorScheme.error)
                        )
                    }
                    Text(
                        opportunity.country,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White,
                        modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
                    )
                }
            }
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                if (opportunity == null) {
                    Surface(shape = CircleShape, color = accent.copy(.11f)) {
                        Icon(
                            if (notice.type == "DEADLINE") Icons.Outlined.Schedule else Icons.Outlined.Notifications,
                            null,
                            tint = accent,
                            modifier = Modifier.padding(9.dp).size(20.dp)
                        )
                    }
                    Spacer(Modifier.width(11.dp))
                }
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            notice.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = if (notice.isRead) FontWeight.Medium else FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            notificationAge(notice.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(.42f),
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                    Text(
                        notice.body,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(.62f),
                        modifier = Modifier.padding(top = 4.dp),
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (opportunity != null) {
                        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("View opportunity", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Icon(Icons.Outlined.ArrowForward, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 4.dp).size(15.dp))
                        }
                    } else if (!notice.isRead) {
                        Text("Tap to mark as read", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 9.dp))
                    }
                }
            }
        }
    }
}

private fun notificationAge(createdAt: Long): String {
    val minutes = ((System.currentTimeMillis() - createdAt).coerceAtLeast(0L) / 60_000L).toInt()
    return when {
        minutes < 1 -> "now"
        minutes < 60 -> "${minutes}m"
        minutes < 1_440 -> "${minutes / 60}h"
        minutes < 10_080 -> "${minutes / 1_440}d"
        else -> "${minutes / 10_080}w"
    }
}

@Composable
private fun HomeProfileHero(profile: UserProfile, settings: SettingsState, onSearch: (String) -> Unit) {
    val visual = VisualLibrary.forHero(profile)
    var query by rememberSaveable { mutableStateOf("") }
    Box(Modifier.fillMaxWidth().height(352.dp)) {
        SmartImage(visual, Modifier.fillMaxSize())
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Black.copy(.08f), Color.Black.copy(.06f), Color.Black.copy(.74f)))
            )
        )
        Surface(
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 18.dp),
            shape = CircleShape,
            color = Color.White.copy(.94f),
            shadowElevation = 5.dp
        ) {
            Icon(Icons.Outlined.FlightTakeoff, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(9.dp).size(20.dp))
        }

        Surface(
            modifier = Modifier.align(Alignment.Center).fillMaxWidth().padding(horizontal = 20.dp),
            shape = RoundedCornerShape(18.dp),
            color = Color.White.copy(.96f),
            shadowElevation = 9.dp
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Search route") },
                leadingIcon = { Icon(Icons.Outlined.Search, null, tint = MaterialTheme.colorScheme.onSurface.copy(.42f)) },
                trailingIcon = {
                    FilledIconButton(
                        onClick = { onSearch(query) },
                        modifier = Modifier.padding(end = 5.dp).size(38.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White)
                    ) { Icon(Icons.Outlined.ArrowForward, "Search", Modifier.size(18.dp)) }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch(query) }),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent)
            )
        }

        Row(
            Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 20.dp, vertical = 20.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Surface(
                modifier = Modifier.size(74.dp),
                shape = CircleShape,
                color = Color.White,
                border = BorderStroke(3.dp, Color.White),
                shadowElevation = 8.dp
            ) {
                if (profile.profileImagePath.isNotBlank()) {
                    SmartImage(profile.profileImagePath, Modifier.fillMaxSize().clip(CircleShape))
                } else {
                    Box(
                        Modifier.fillMaxSize().background(Brush.linearGradient(accentGradient(settings.accent))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(profile.name.trim().take(1).ifBlank { "A" }.uppercase(), color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(profile.name.ifBlank { "Your Akademi profile" }, style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text(
                    profile.headline.ifBlank { "Postgraduate opportunity explorer" },
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(.84f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val cgpa = if (profile.cgpa > 0.0) "${profile.cgpa}/${profile.cgpaScale}" else "Add CGPA"
                Text(
                    "${profile.degree.ifBlank { "Add degree" }} • $cgpa • ${profile.targetLevel}",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White.copy(.92f),
                    modifier = Modifier.padding(top = 5.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}


@Composable
private fun TravelActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    ElevatedCard(
        modifier = Modifier.width(146.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.11f)) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(9.dp).size(20.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(.52f), modifier = Modifier.padding(top = 2.dp), maxLines = 1)
            }
        }
    }
}

@Composable
private fun CountryMiniCard(country: String, visual: String, onClick: () -> Unit) {
    ElevatedCard(
        modifier = Modifier.width(146.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            SmartImage(visual, Modifier.fillMaxWidth().height(92.dp))
            Row(Modifier.padding(horizontal = 11.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.LocationOn, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(4.dp))
                Text(country, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun HomeFeedCard(
    item: HomeFeedItem,
    opportunity: Opportunity?,
    visualOverride: String,
    onOpportunity: (Opportunity) -> Unit,
    onOpenWeb: (String) -> Unit,
    onOpenExternal: (String) -> Unit
) {
    var expanded by rememberSaveable(item.id) { mutableStateOf(false) }
    val visual = visualOverride.ifBlank { item.imageUrl.ifBlank { VisualLibrary.generic(item.id) } }
    val clickAction = {
        when {
            opportunity != null -> onOpportunity(opportunity)
            item.url.isNotBlank() && item.type == "video" -> onOpenWeb(item.url)
            else -> expanded = !expanded
        }
    }
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp, vertical = 7.dp).fillMaxWidth()
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
            .clickable(onClick = clickAction),
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 7.dp else 3.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(98.dp).clip(RoundedCornerShape(18.dp))) {
                    SmartImage(
                        visual,
                        Modifier.fillMaxSize(),
                        fallbackSource = opportunity?.let { VisualLibrary.fallbackForOpportunity(it) } ?: VisualLibrary.generic(item.id)
                    )
                    if (item.type == "video") {
                        Surface(Modifier.align(Alignment.Center), shape = CircleShape, color = Color.White.copy(.92f), shadowElevation = 5.dp) {
                            Icon(Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp).size(20.dp))
                        }
                    }
                }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                            Text(item.badge, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), maxLines = 1)
                        }
                    }
                    Text(item.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 7.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        item.body,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(.58f),
                        modifier = Modifier.padding(top = 4.dp),
                        maxLines = if (expanded) 5 else 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(item.source, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
                }
                Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurface.copy(.32f), modifier = Modifier.size(20.dp))
            }
            AnimatedVisibility(expanded && opportunity == null && item.url.isNotBlank()) {
                Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onOpenWeb(item.url) }, modifier = Modifier.weight(1f)) { Text("Open inside") }
                    OutlinedButton(onClick = { onOpenExternal(item.url) }, modifier = Modifier.weight(1f)) { Text("External") }
                }
            }
        }
    }
}


@Composable private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier, shape = RoundedCornerShape(18.dp), elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(.62f), modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable private fun QuickAction(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    ElevatedCard(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(18.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f), maxLines = 2)
        }
    }
}

@Composable private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 12.dp))
}

@Composable
private fun DiscoverScreen(
    modifier: Modifier, profile: UserProfile, opportunities: List<Opportunity>, initialQuery: String, remoteMessage: String?, onRefresh: () -> Unit,
    onOpportunity: (Opportunity) -> Unit, onOpenExternal: (String) -> Unit
) {
    var query by rememberSaveable(initialQuery) { mutableStateOf(initialQuery) }
    var level by rememberSaveable { mutableStateOf("All") }
    var funding by rememberSaveable { mutableStateOf("All") }
    val filtered = remember(query, level, funding, opportunities, profile) {
        opportunities.filter { o ->
            (query.isBlank() || (o.title + o.provider + o.country + o.field).contains(query, true)) &&
                (level == "All" || o.level.contains(level, true)) &&
                (funding == "All" || o.funding.contains(funding, true))
        }.map { MatchEngine.score(profile, it) }.sortedByDescending { it.score }
    }
    val opportunityVisuals = remember(filtered) { VisualLibrary.uniqueOpportunityVisuals(filtered.map { it.opportunity }) }
    Column(modifier.fillMaxSize()) {
        PageHeader("Explore", "Find your next postgraduate destination") {
            FilledIconButton(onClick = onRefresh, colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary.copy(.10f), contentColor = MaterialTheme.colorScheme.primary)) {
                Icon(Icons.Outlined.Refresh, "Refresh")
            }
        }
        Surface(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(18.dp),
            shadowElevation = 2.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(.06f))
        ) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                leadingIcon = { Icon(Icons.Outlined.Search, null) }, placeholder = { Text("Search opportunities") },
                trailingIcon = { Icon(Icons.Outlined.Tune, null, tint = MaterialTheme.colorScheme.primary) },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent)
            )
        }
        Text("Categories", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp))
        Row(Modifier.padding(horizontal = 20.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Master's", "PhD").forEach { v -> FilterChip(selected = level == v, onClick = { level = v }, label = { Text(v) }) }
            listOf("All", "Fully", "Salary", "Partial").forEach { v -> FilterChip(selected = funding == v, onClick = { funding = v }, label = { Text(if (v == "All") "Any funding" else v) }) }
        }
        remoteMessage?.let { Text(it, Modifier.padding(horizontal = 20.dp, vertical = 6.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.58f)) }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("For your profile", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Text("${filtered.size} results", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(filtered, key = { it.opportunity.id }) { s ->
                OpportunityCard(s, visualSource = opportunityVisuals[s.opportunity.id].orEmpty(), onViewDetails = { onOpportunity(s.opportunity) }, onExternal = { onOpenExternal(s.opportunity.sourceUrl) })
            }
        }
    }
}

@Composable
private fun OpportunityCard(s: ScoredOpportunity, visualSource: String, onViewDetails: () -> Unit, onExternal: () -> Unit) {
    val o = s.opportunity
    var expanded by rememberSaveable(o.id) { mutableStateOf(false) }
    val visual = visualSource.ifBlank { VisualLibrary.forOpportunity(o) }
    val fallbackVisual = remember(o.id) { VisualLibrary.fallbackForOpportunity(o) }
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp, vertical = 9.dp).fillMaxWidth()
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(26.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 9.dp else 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(if (expanded) 224.dp else 176.dp)) {
                SmartImage(visual, Modifier.fillMaxSize(), fallbackSource = fallbackVisual)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.48f)))))
                Surface(modifier = Modifier.align(Alignment.TopStart).padding(12.dp), shape = RoundedCornerShape(50), color = Color.White.copy(.94f)) {
                    Text(o.funding, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                }
                Surface(modifier = Modifier.align(Alignment.TopEnd).padding(12.dp), shape = CircleShape, color = Color.White.copy(.95f), shadowElevation = 5.dp) {
                    Column(Modifier.size(52.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("${s.score}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        Text("MATCH", fontSize = 7.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f), fontWeight = FontWeight.Bold)
                    }
                }
                Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
                    Text(o.country, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.92f))
                    Text(o.provider, style = MaterialTheme.typography.bodySmall, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
            Column(Modifier.padding(16.dp)) {
                Text(o.title, style = MaterialTheme.typography.titleMedium)
                Row(Modifier.padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    SmallMeta(Icons.Outlined.School, o.level)
                    SmallMeta(Icons.Outlined.Event, o.deadline)
                }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(o.status, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary, modifier = Modifier.weight(1f))
                    Text(if (expanded) "Less" else "Quick view", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                }
                AnimatedVisibility(expanded) {
                    Column(Modifier.padding(top = 12.dp)) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.07f))
                        Text(o.aiSummary.ifBlank { o.summary }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(.68f), modifier = Modifier.padding(top = 12.dp))
                        if (s.reasons.isNotEmpty()) {
                            Text("Why it matches", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
                            s.reasons.take(3).forEach { reason -> CheckRow(reason) }
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onViewDetails, modifier = Modifier.weight(1f)) { Text("View inside") }
                            OutlinedButton(onClick = onExternal, modifier = Modifier.weight(1f)) { Icon(Icons.Outlined.OpenInNew, null, Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text("Source") }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun SmallMeta(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurface.copy(.55f))
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun OpportunityDetailScreen(
    scored: ScoredOpportunity?,
    tracked: Boolean,
    profile: UserProfile,
    settings: SettingsState,
    onBack: () -> Unit,
    onOpenInside: () -> Unit,
    onOpenExternal: () -> Unit,
    onApplyInside: () -> Unit,
    onTrack: () -> Unit
) {
    if (scored == null) return
    val o = scored.opportunity
    val visual = remember(o.id, o.imageUrl) { VisualLibrary.forOpportunity(o) }
    val fallbackVisual = remember(o.id) { VisualLibrary.fallbackForOpportunity(o) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val keyStore = remember { SecureGeminiKeyStore(context) }
    val aiCache = remember { AiInsightCache(context) }
    val scope = rememberCoroutineScope()
    var aiInsight by remember(o.id, settings.aiModel) {
        mutableStateOf(if (settings.aiCacheEnabled) aiCache.get(o.id, settings.aiModel) else null)
    }
    var aiLoading by remember(o.id) { mutableStateOf(false) }
    var aiMessage by remember(o.id) { mutableStateOf<String?>(null) }
    var aiQuestion by rememberSaveable(o.id) { mutableStateOf("") }
    var aiAnswer by remember(o.id) { mutableStateOf<String?>(null) }
    var questionLoading by remember(o.id) { mutableStateOf(false) }
    val aiConfigured = keyStore.hasKey()
    val sourceBrief = o.aiSummary.ifBlank { o.summary }.ifBlank {
        "Akademi has the structured opportunity data below. Refresh the live feed to pull the latest source brief when available."
    }

    Scaffold(
        topBar = {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }
                Text("Opportunity", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onOpenExternal) { Icon(Icons.Outlined.OpenInNew, "Official source") }
            }
        }
    ) { p ->
        LazyColumn(
            Modifier.padding(p).fillMaxSize(),
            contentPadding = PaddingValues(bottom = 34.dp),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            // Full-bleed hero: banners intentionally touch both horizontal edges.
            item {
                Box(Modifier.fillMaxWidth().height(236.dp)) {
                    SmartImage(visual, Modifier.fillMaxSize(), fallbackSource = fallbackVisual)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.58f)))))
                    Surface(
                        modifier = Modifier.align(Alignment.TopEnd).padding(14.dp),
                        shape = CircleShape,
                        color = Color.White.copy(.94f),
                        shadowElevation = 3.dp
                    ) {
                        Icon(
                            if (tracked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(9.dp).size(20.dp)
                        )
                    }
                    Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                        Text(o.country, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.88f))
                        Text(o.provider, style = MaterialTheme.typography.titleMedium, color = Color.White, maxLines = 2)
                    }
                }
            }

            item {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = {}, label = { Text(o.funding.uppercase(), fontSize = 10.sp) })
                        if (o.verified) AssistChip(
                            onClick = {},
                            leadingIcon = { Icon(Icons.Filled.Verified, null, Modifier.size(15.dp)) },
                            label = { Text("SOURCE CHECKED", fontSize = 10.sp) }
                        )
                    }
                    Text(o.title, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 33.sp, modifier = Modifier.padding(top = 4.dp))
                    Text("${o.provider} • ${o.country}", color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 6.dp))
                    if (o.lastChecked.isNotBlank()) {
                        Text("Source refreshed ${o.lastChecked}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.48f), modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }

            item {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                                    Icon(Icons.Outlined.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(9.dp).size(20.dp))
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Full opportunity brief", style = MaterialTheme.typography.titleMedium)
                                    Text("Updated from the collected source", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                                }
                            }
                            Text(sourceBrief, style = MaterialTheme.typography.bodyMedium, lineHeight = 21.sp, color = MaterialTheme.colorScheme.onSurface.copy(.78f), modifier = Modifier.padding(top = 13.dp))
                            if (o.aiFundingNotes.isNotBlank()) {
                                Text("Funding note", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 13.dp))
                                Text(o.aiFundingNotes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.68f), modifier = Modifier.padding(top = 3.dp))
                            }
                            if (o.aiUpdatedAt.isNotBlank()) {
                                Text("AI source extraction ${o.aiUpdatedAt} • ${o.aiModel}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.45f), modifier = Modifier.padding(top = 10.dp))
                            }
                        }
                    }
                }
            }

            item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("Major details") } }
            item {
                ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(17.dp)) {
                        DetailRow("Type", o.opportunityType)
                        DetailRow("Level", o.level)
                        DetailRow("Field", o.field)
                        DetailRow("Country", o.country)
                        DetailRow("Study mode", o.studyMode)
                        DetailRow("Duration", o.duration)
                        DetailRow("Start", o.startDate)
                        DetailRow("Deadline", o.deadline)
                        DetailRow("Status", o.status)
                        DetailRow("Supervisor", o.requiresSupervisor)
                        DetailRow("App fee", o.applicationFee)
                    }
                }
            }

            item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("Funding & benefits") } }
            item {
                ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(17.dp)) {
                        DetailRow("Funding", o.funding)
                        DetailRow("Tuition", o.tuitionCoverage)
                        DetailRow("Stipend", o.stipend)
                        DetailRow("Living", o.livingAllowance)
                        DetailRow("Travel", o.travelSupport)
                        if (o.benefits.isNotEmpty()) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.06f), modifier = Modifier.padding(vertical = 9.dp))
                            o.benefits.forEach { CheckRow(it) }
                        }
                    }
                }
            }

            if (o.eligibility.isNotEmpty() || o.eligibleNationalities.isNotEmpty()) {
                item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("Eligibility") } }
                item {
                    ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(17.dp)) {
                            if (o.eligibleNationalities.isNotEmpty()) DetailRow("Nationality", o.eligibleNationalities.joinToString(", "))
                            o.eligibility.forEach { CheckRow(it, checked = false) }
                        }
                    }
                }
            }

            item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("Requirements") } }
            item {
                ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(17.dp)) {
                        val reqs = (o.aiRequirements + o.requirements).map { it.trim() }.filter { it.isNotBlank() }.distinct()
                        if (reqs.isEmpty()) {
                            Text("No additional structured requirements were stated in the latest source snapshot.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.62f))
                        } else reqs.forEach { CheckRow(it, checked = false) }
                        if (o.languageRequirements.isNotEmpty()) {
                            Text("Language", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 3.dp))
                            o.languageRequirements.forEach { CheckRow(it, checked = false) }
                        }
                    }
                }
            }

            if (o.documents.isNotEmpty()) {
                item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("Documents") } }
                item {
                    ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(17.dp)) { o.documents.forEach { CheckRow(it, checked = false) } }
                    }
                }
            }

            if (o.howToApply.isNotEmpty()) {
                item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("How to apply") } }
                item {
                    ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(17.dp)) { o.howToApply.forEachIndexed { index, step -> NumberedInfoRow(step, index + 1) } }
                    }
                }
            }

            if (o.selectionProcess.isNotEmpty() || o.aiSelectionSignals.isNotEmpty()) {
                item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("Selection process") } }
                item {
                    ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(17.dp)) {
                            o.selectionProcess.forEach { CheckRow(it, checked = false) }
                            if (o.aiSelectionSignals.isNotEmpty()) {
                                if (o.selectionProcess.isNotEmpty()) HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.06f), modifier = Modifier.padding(vertical = 8.dp))
                                Text("What appears to matter", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 4.dp))
                                o.aiSelectionSignals.forEach { CheckRow(it) }
                            }
                        }
                    }
                }
            }

            if (o.aiRisks.isNotEmpty() || o.aiActions.isNotEmpty()) {
                item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("Application guidance") } }
                item {
                    ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(17.dp)) {
                            if (o.aiRisks.isNotEmpty()) {
                                Text("Watch-outs", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 4.dp))
                                o.aiRisks.forEach { CheckRow(it, checked = false) }
                            }
                            if (o.aiActions.isNotEmpty()) {
                                Text("Suggested next steps", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = if (o.aiRisks.isEmpty()) 0.dp else 12.dp, bottom = 4.dp))
                                o.aiActions.forEachIndexed { index, step -> NumberedInfoRow(step, index + 1) }
                            }
                        }
                    }
                }
            }

            item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("Your match") } }
            item {
                ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Profile fit", fontWeight = FontWeight.SemiBold)
                                Text(matchLabel(scored.score), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                            Text("${scored.score}/100", fontWeight = FontWeight.Bold, fontSize = 24.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator({ scored.score / 100f }, Modifier.fillMaxWidth())
                        Text("Profile-fit score, not an acceptance probability.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.52f), modifier = Modifier.padding(top = 7.dp))
                        if (scored.reasons.isNotEmpty()) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.06f), modifier = Modifier.padding(vertical = 10.dp))
                            scored.reasons.forEach { CheckRow(it) }
                        }
                    }
                }
            }

            item { Column(Modifier.padding(horizontal = 20.dp)) { SectionTitleNoIndent("Personalized Gemini") } }
            item {
                ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Psychology, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Akademi Intelligence", fontWeight = FontWeight.Bold)
                                Text(settings.aiModel, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.52f))
                            }
                        }
                        when {
                            !settings.aiEnabled -> Text("AI is optional and currently off. Enable Gemini in Settings for a profile-specific review.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 10.dp))
                            !aiConfigured -> Text("Gemini is enabled, but no API key is stored. Add your key in Settings → Gemini AI.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 10.dp))
                            aiInsight == null -> {
                                Text("Analyze this source brief against your saved profile. Cached results do not spend another request when you reopen it.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 10.dp))
                                Button(
                                    onClick = {
                                        val key = keyStore.load()
                                        if (key.isNullOrBlank()) aiMessage = "Gemini API key could not be read. Re-save it in Settings."
                                        else scope.launch {
                                            aiLoading = true; aiMessage = null
                                            GeminiClient.analyzeOpportunity(key, settings.aiModel, profile, scored)
                                                .onSuccess {
                                                    aiInsight = it
                                                    if (settings.aiCacheEnabled) aiCache.put(o.id, it)
                                                }
                                                .onFailure { aiMessage = it.message ?: "Gemini analysis failed" }
                                            aiLoading = false
                                        }
                                    },
                                    enabled = !aiLoading,
                                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                                ) {
                                    if (aiLoading) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)) }
                                    Text(if (aiLoading) "Analyzing…" else "Analyze with Gemini")
                                }
                            }
                        }
                        aiMessage?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
                    }
                }
            }

            aiInsight?.let { insight ->
                item {
                    ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text(insight.headline, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(insight.summary, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 6.dp))
                            if (insight.strengths.isNotEmpty()) {
                                Text("Your strengths", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                                insight.strengths.forEach { CheckRow(it) }
                            }
                            if (insight.risks.isNotEmpty()) {
                                Text("Possible gaps", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                                insight.risks.forEach { CheckRow(it, checked = false) }
                            }
                            if (insight.actions.isNotEmpty()) {
                                Text("What to do next", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                                insight.actions.forEachIndexed { index, step -> NumberedInfoRow(step, index + 1) }
                            }
                            if (insight.questionsToVerify.isNotEmpty()) {
                                Text("Still worth verifying", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                                insight.questionsToVerify.forEach { CheckRow(it, checked = false) }
                            }
                        }
                    }
                }
            }

            if (settings.aiEnabled && aiConfigured) {
                item {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                        OutlinedTextField(
                            value = aiQuestion,
                            onValueChange = { aiQuestion = it },
                            label = { Text("Ask Akademi") },
                            placeholder = { Text("Application strategy") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2,
                            maxLines = 5
                        )
                        Button(
                            onClick = {
                                val key = keyStore.load()
                                if (!key.isNullOrBlank() && aiQuestion.isNotBlank()) scope.launch {
                                    questionLoading = true; aiAnswer = null
                                    GeminiClient.askOpportunity(key, settings.aiModel, profile, scored, aiQuestion)
                                        .onSuccess { aiAnswer = it }
                                        .onFailure { aiAnswer = "Gemini request failed: ${it.message ?: "unknown error"}" }
                                    questionLoading = false
                                }
                            },
                            enabled = aiQuestion.isNotBlank() && !questionLoading,
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            if (questionLoading) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)) }
                            Text(if (questionLoading) "Thinking…" else "Ask Gemini")
                        }
                        aiAnswer?.let { answer ->
                            Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Text(answer, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(15.dp))
                            }
                        }
                    }
                }
            }

            item {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Button(onClick = onTrack, enabled = !tracked, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) {
                        Icon(if (tracked) Icons.Filled.Check else Icons.Outlined.BookmarkAdd, null)
                        Spacer(Modifier.width(8.dp)); Text(if (tracked) "Already in tracker" else "Save application")
                    }
                    if (o.applicationUrl.isNotBlank()) {
                        Button(onClick = onApplyInside, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(50.dp), shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Outlined.Send, null); Spacer(Modifier.width(8.dp)); Text("Application page")
                        }
                    }
                    OutlinedButton(onClick = onOpenInside, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(50.dp), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Outlined.Language, null); Spacer(Modifier.width(8.dp)); Text("Official source")
                    }
                    TextButton(onClick = onOpenExternal, modifier = Modifier.fillMaxWidth().padding(top = 3.dp)) {
                        Icon(Icons.Outlined.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text("Open externally")
                    }
                    Text(
                        "Akademi keeps the collected details in-app so you can assess the opportunity without leaving. The official page remains the final authority for any last-minute source change.",
                        fontSize = 10.sp,
                        lineHeight = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(.48f),
                        modifier = Modifier.padding(top = 7.dp)
                    )
                }
            }
        }
    }
}

@Composable private fun NumberedInfoRow(text: String, number: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.12f)) {
            Text(number.toString(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
        }
        Spacer(Modifier.width(9.dp)); Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f), lineHeight = 19.sp)
    }
}

@Composable private fun SectionTitleNoIndent(text: String) = Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 28.dp, bottom = 12.dp))
@Composable private fun CheckRow(text: String, checked: Boolean = true) { Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) { Icon(if (checked) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked, null, tint = if (checked) Teal else MaterialTheme.colorScheme.onSurface.copy(.35f), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f)) } }
private fun normalizedDetailValue(value: String): String {
    val text = value.trim()
    return if (text.isBlank() || text.equals("Check source", true) || text.equals("See source", true)) "Not stated on source" else text
}

@Composable private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.width(92.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
        Text(normalizedDetailValue(value), fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
    }
}
private fun matchLabel(score: Int) = when { score >= 85 -> "Excellent fit"; score >= 70 -> "Strong fit"; score >= 55 -> "Possible fit"; else -> "Needs review" }

@Composable
private fun ResearchScreen(
    modifier: Modifier,
    profile: UserProfile,
    onOpen: (String) -> Unit,
    onOpenExternal: (String) -> Unit,
    onStories: () -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize()) {
        PageHeader("Research", "Professors, papers and directions matched to your profile")
        TabRow(selectedTabIndex = tab) {
            Tab(tab == 0, onClick = { tab = 0 }, text = { Text("Professors") })
            Tab(tab == 1, onClick = { tab = 1 }, text = { Text("Directions") })
            Tab(tab == 2, onClick = { tab = 2 }, text = { Text("Stories") })
        }
        AnimatedContent(targetState = tab, label = "researchTabs", transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) }) { selectedTab ->
            Box(Modifier.fillMaxSize()) {
                when (selectedTab) {
                    0 -> ProfessorFinder(profile, onOpen, onOpenExternal)
                    1 -> ResearchDirections(profile, onOpen, onOpenExternal)
                    else -> StoryPreview(onStories)
                }
            }
        }
    }
}

@Composable
private fun ProfessorFinder(profile: UserProfile, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    val defaultTopic = profile.researchInterests.split(',').map { it.trim() }.firstOrNull { it.isNotBlank() }
        ?: profile.field.ifBlank { "postgraduate research" }
    var query by rememberSaveable { mutableStateOf(defaultTopic) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Search current OpenAlex publications to surface researchers working in any field you choose.") }
    var researchers by remember { mutableStateOf<List<Researcher>>(emptyList()) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Research topic") },
                leadingIcon = { Icon(Icons.Outlined.Search, null) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    loading = true; message = "Searching current research…"
                    scope.launch {
                        OpenAlexRepository.searchResearchers(query)
                            .onSuccess { researchers = it; message = "${it.size} researchers surfaced from publications related to your search." }
                            .onFailure { message = "Search failed: ${it.message}" }
                        loading = false
                    }
                }),
                shape = RoundedCornerShape(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = {
                loading = true; message = "Searching current research…"
                scope.launch {
                    OpenAlexRepository.searchResearchers(query)
                        .onSuccess { researchers = it; message = "${it.size} researchers surfaced from publications related to your search." }
                        .onFailure { message = "Search failed: ${it.message}" }
                    loading = false
                }
            }) { Icon(Icons.Outlined.Search, "Search") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(message, Modifier.padding(horizontal = 20.dp, vertical = 7.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (researchers.isEmpty()) {
                item { InfoBanner("Search any field", "Try a discipline, specific research problem, methodology or interdisciplinary topic. Akademi is not limited to one degree.") }
            }
            itemsIndexed(researchers, key = { _, r -> r.id }) { index, r ->
                ProfessorCard(r, query, VisualLibrary.professorAvatar(index), onOpen, onOpenExternal)
            }
        }
    }
}

@Composable
private fun ProfessorCard(
    r: Researcher,
    query: String,
    avatar: String,
    onOpen: (String) -> Unit,
    onOpenExternal: (String) -> Unit
) {
    var expanded by rememberSaveable(r.id) { mutableStateOf(false) }
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth()
            .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 7.dp else 3.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.08f), shadowElevation = 3.dp) {
                    SmartImage(avatar, Modifier.size(76.dp).clip(CircleShape))
                }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(r.institution, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.58f), maxLines = 2, modifier = Modifier.padding(top = 3.dp))
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (r.country.isNotBlank()) {
                            Icon(Icons.Outlined.Place, null, Modifier.size(13.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(3.dp))
                            Text(r.country, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                            Spacer(Modifier.width(8.dp))
                        }
                        Text("${r.fitScore}% fit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    }
                }
                Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.onSurface.copy(.38f))
            }

            if (r.topics.isNotEmpty()) {
                Text(r.topics.take(3).joinToString(" • "), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp), color = MaterialTheme.colorScheme.onSurface.copy(.66f), maxLines = if (expanded) 4 else 2)
            }

            AnimatedVisibility(expanded) {
                Column(Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.07f))
                    Text("Why this researcher surfaced", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 13.dp))
                    Text(
                        "OpenAlex-indexed publications overlap with your search for “$query”. The circular avatar is an Akademi editorial illustration, not a verified portrait. Use the linked research profiles to confirm current projects and supervision availability.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(.66f),
                        modifier = Modifier.padding(top = 5.dp)
                    )
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = {}, label = { Text("${r.worksCount} works") })
                        AssistChip(onClick = {}, label = { Text("${r.citedByCount} citations") })
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onOpen(r.openAlexUrl) }, modifier = Modifier.weight(1f)) { Text("Research") }
                        OutlinedButton(onClick = { onOpenExternal(r.openAlexUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (r.orcid.isNotBlank()) {
                            val orcidUrl = if (r.orcid.startsWith("http")) r.orcid else "https://orcid.org/${r.orcid}"
                            OutlinedButton(onClick = { onOpen(orcidUrl) }, modifier = Modifier.weight(1f)) { Text("ORCID") }
                        }
                        val linkedIn = "https://www.linkedin.com/search/results/people/?keywords=${Uri.encode(r.name + " " + r.institution)}"
                        OutlinedButton(onClick = { onOpenExternal(linkedIn) }, modifier = Modifier.weight(1f)) { Text("LinkedIn") }
                    }
                }
            }
        }
    }
}


@Composable
private fun ResearchDirections(profile: UserProfile, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    val dirs = remember(profile) { DirectionEngine.recommend(profile) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
        item { InfoBanner("Directions adapt to you", "These routes use your degree, field and interests. Update your profile and the recommendations change automatically.") }
        items(dirs, key = { it.title }) { d ->
            var expanded by rememberSaveable(d.title) { mutableStateOf(false) }
            ElevatedCard(
                Modifier.fillMaxWidth().padding(vertical = 8.dp)
                    .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
                    .clickable { expanded = !expanded },
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 7.dp else 3.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(17.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                            Text(d.category.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
                        }
                        Spacer(Modifier.weight(1f))
                        Text("${d.fitScore}% fit", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    }
                    Text(d.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
                    Text(d.headline, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp))
                    Text(d.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.66f), modifier = Modifier.padding(top = 9.dp), maxLines = if (expanded) 8 else 3, overflow = TextOverflow.Ellipsis)
                    Row(Modifier.fillMaxWidth().padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (expanded) "Show less" else "Explore direction", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                        Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.primary)
                    }
                    AnimatedVisibility(expanded) {
                        Column(Modifier.padding(top = 8.dp)) {
                            Text("Example topics", style = MaterialTheme.typography.titleSmall)
                            d.exampleTopics.forEach { topic -> CheckRow(topic) }
                            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { onOpen(d.externalUrl) }, modifier = Modifier.weight(1f)) { Text("Research") }
                                OutlinedButton(onClick = { onOpenExternal(d.externalUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable private fun StoryPreview(onStories: () -> Unit) {
    Column(Modifier.padding(20.dp)) {
        InfoBanner("Learn from real applicants", "Switch between video experiences and live forum research across Reddit and academic communities.")
        Button(onClick = onStories, modifier = Modifier.fillMaxWidth()) { Text("Open stories") }
    }
}

@Composable
private fun SuccessStoriesScreen(
    profile: UserProfile,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onOpenExternal: (String) -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var forumTopic by rememberSaveable { mutableStateOf("") }
    val focus = profile.researchInterests.split(',').firstOrNull()?.trim().orEmpty().ifBlank { profile.field.ifBlank { "postgraduate scholarship" } }
    val topic = forumTopic.ifBlank { "application experience" }

    val videos = remember(focus) {
        listOf(
            Triple("Scholarship walkthroughs", "Application journeys and practical step-by-step videos", "international scholarship $focus application walkthrough"),
            Triple("Winner interviews", "Hear how successful applicants prepared, wrote and interviewed", "scholarship winner interview $focus international student"),
            Triple("Motivation letters", "Compare scholarship-specific statement and motivation-letter advice", "scholarship motivation letter $focus tips international student"),
            Triple("Supervisor outreach", "Learn how applicants approached potential supervisors for research routes", "PhD supervisor outreach funded research $focus"),
            Triple("Life after award", "Study-abroad, settling-in and post-graduation experiences", "international scholarship student life after graduation $focus")
        )
    }
    val videoVisuals = remember(videos) { VisualLibrary.uniqueStoryVisuals(videos.map { it.first }) }

    val forums = remember(focus, topic) {
        listOf(
            ForumSearchItem(
                "Reddit · GradAdmissions",
                "Admissions decisions, funding packages, interviews and applicant timelines.",
                "https://www.reddit.com/search/?q=${Uri.encode("$focus $topic scholarship graduate admissions")}&sort=relevance&t=year"
            ),
            ForumSearchItem(
                "Reddit · Scholarships",
                "Funding searches, application questions and awardee experiences from scholarship applicants.",
                "https://www.reddit.com/search/?q=${Uri.encode("$focus $topic scholarship international student")}&sort=relevance&t=year"
            ),
            ForumSearchItem(
                "Reddit · PhD",
                "Supervisor contact, funded PhD offers, research fit and doctoral-life discussions.",
                "https://www.reddit.com/search/?q=${Uri.encode("$focus $topic funded PhD supervisor")}&sort=relevance&t=year"
            ),
            ForumSearchItem(
                "The GradCafe",
                "Graduate admissions and funding discussions across programmes and universities.",
                "https://www.google.com/search?q=${Uri.encode("site:forum.thegradcafe.com $focus $topic funding")}" 
            ),
            ForumSearchItem(
                "Academia StackExchange",
                "Focused academic questions about supervisors, research degrees, funding and applications.",
                "https://academia.stackexchange.com/search?q=${Uri.encode("$focus $topic scholarship funding supervisor")}" 
            ),
            ForumSearchItem(
                "The Student Room",
                "Postgraduate and international-student discussions, especially useful for UK study routes.",
                "https://www.google.com/search?q=${Uri.encode("site:thestudentroom.co.uk $focus $topic postgraduate scholarship")}" 
            )
        )
    }

    Scaffold(topBar = { SimpleBackBar("Stories", onBack) }) { p ->
        Column(Modifier.padding(p).fillMaxSize()) {
            TabRow(selectedTabIndex = tab, modifier = Modifier.padding(horizontal = 20.dp)) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Outlined.SmartDisplay, null) }, text = { Text("Video") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Outlined.Forum, null) }, text = { Text("Forum") })
            }
            AnimatedContent(targetState = tab, label = "storyType") { selectedTab ->
                if (selectedTab == 0) {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
                        item { InfoBanner("Real applicant video radar", "Videos are experience and strategy, not official eligibility rules. Open them inside Akademi and use full-screen playback when available.") }
                        items(videos, key = { it.first }) { video ->
                            val url = "https://www.youtube.com/results?search_query=${Uri.encode(video.third)}"
                            VideoStoryCard(
                                title = video.first,
                                body = video.second,
                                visual = videoVisuals[video.first].orEmpty(),
                                url = url,
                                onOpen = onOpen,
                                onOpenExternal = onOpenExternal
                            )
                        }
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
                        item {
                            InfoBanner("Live forum research", "Akademi builds relevance-focused searches around your field and topic. Forum posts are anecdotal; compare several experiences before acting on advice.")
                        }
                        item {
                            OutlinedTextField(
                                value = forumTopic,
                                onValueChange = { forumTopic = it },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                singleLine = true,
                                placeholder = { Text("Forum topic") },
                                leadingIcon = { Icon(Icons.Outlined.Search, null) },
                                shape = RoundedCornerShape(18.dp)
                            )
                        }
                        item {
                            Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                listOf("Applications", "Funding", "Interviews", "Motivation", "Supervisors").forEach { label ->
                                    FilterChip(
                                        selected = forumTopic.equals(label, true),
                                        onClick = { forumTopic = label },
                                        label = { Text(label) }
                                    )
                                }
                            }
                        }
                        items(forums, key = { it.title }) { forum ->
                            ForumStoryCard(forum, onOpen, onOpenExternal)
                        }
                    }
                }
            }
        }
    }
}

private data class ForumSearchItem(val title: String, val body: String, val url: String)

@Composable
private fun VideoStoryCard(
    title: String,
    body: String,
    visual: String,
    url: String,
    onOpen: (String) -> Unit,
    onOpenExternal: (String) -> Unit
) {
    var expanded by rememberSaveable(title) { mutableStateOf(false) }
    ElevatedCard(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).animateContentSize().clickable { expanded = !expanded },
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 7.dp else 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(if (expanded) 194.dp else 148.dp)) {
                SmartImage(visual, Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.42f)))))
                Surface(modifier = Modifier.align(Alignment.Center), shape = CircleShape, color = Color.White.copy(.94f), shadowElevation = 6.dp) {
                    Icon(Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(11.dp).size(24.dp))
                }
            }
            Column(Modifier.padding(16.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.60f), maxLines = if (expanded) 4 else 2, modifier = Modifier.padding(top = 4.dp))
                AnimatedVisibility(expanded) {
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onOpen(url) }, modifier = Modifier.weight(1f)) { Text("Open inside") }
                        OutlinedButton(onClick = { onOpenExternal(url) }, modifier = Modifier.weight(1f)) { Text("External") }
                    }
                }
            }
        }
    }
}

@Composable
private fun ForumStoryCard(item: ForumSearchItem, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    ElevatedCard(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable { onOpen(item.url) },
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.10f)) {
                    Icon(Icons.Outlined.Forum, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp).size(18.dp))
                }
                Spacer(Modifier.width(10.dp))
                Text(item.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurface.copy(.34f))
            }
            Text(item.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.60f), modifier = Modifier.padding(top = 9.dp), maxLines = 3)
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Live relevance search", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                TextButton(onClick = { onOpenExternal(item.url) }) { Text("External") }
            }
        }
    }
}


@Composable
private fun TrackerScreen(modifier: Modifier, opportunities: List<Opportunity>, tracker: List<TrackerItem>, onTracker: (List<TrackerItem>) -> Unit, onOpen: (Opportunity) -> Unit) {
    Column(modifier.fillMaxSize()) {
        PageHeader("My tracker", "Plan, apply and follow up")
        val preparing = tracker.count { it.status == "Preparing" }; val applied = tracker.count { it.status == "Applied" }; val interview = tracker.count { it.status == "Interview" }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("$preparing", "Preparing", Modifier.weight(1f)); StatCard("$applied", "Applied", Modifier.weight(1f)); StatCard("$interview", "Interview", Modifier.weight(1f))
        }
        if (tracker.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Outlined.Bookmarks, null, Modifier.size(52.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(14.dp)); Text("Nothing saved yet", fontWeight = FontWeight.Bold); Text("Open an opportunity and tap “Save & start application”.", textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)) {
                items(tracker, key = { it.opportunityId }) { t ->
                    val o = opportunities.firstOrNull { it.id == t.opportunityId }
                    if (o != null) TrackerCard(o, t, onChange = { changed -> onTracker(tracker.map { if (it.opportunityId == t.opportunityId) changed else it }) }, onRemove = { onTracker(tracker.filterNot { it.opportunityId == t.opportunityId }) }, onOpen = { onOpen(o) })
                }
            }
        }
    }
}

@Composable private fun TrackerCard(o: Opportunity, t: TrackerItem, onChange: (TrackerItem) -> Unit, onRemove: () -> Unit, onOpen: () -> Unit) {
    val visual = remember(o.id, o.imageUrl) { VisualLibrary.forOpportunity(o) }
    val fallbackVisual = remember(o.id) { VisualLibrary.fallbackForOpportunity(o) }
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                SmartImage(visual, Modifier.size(78.dp).clip(RoundedCornerShape(17.dp)), fallbackSource = fallbackVisual)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(o.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(o.provider, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 3.dp))
                    Text(t.status, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 5.dp))
                }
                IconButton(onClick = onRemove) { Icon(Icons.Outlined.Delete, "Remove", tint = MaterialTheme.colorScheme.onSurface.copy(.38f)) }
            }
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 14.dp)) {
                LinearProgressIndicator({ t.progress / 100f }, Modifier.fillMaxWidth().padding(vertical = 7.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${t.progress}%", modifier = Modifier.width(45.dp), style = MaterialTheme.typography.labelMedium)
                    Slider(value = t.progress.toFloat(), onValueChange = { onChange(t.copy(progress = it.toInt())) }, valueRange = 0f..100f, steps = 9, modifier = Modifier.weight(1f))
                }
                Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Preparing", "Applied", "Interview", "Offer").forEach { status -> FilterChip(selected = t.status == status, onClick = { onChange(t.copy(status = status)) }, label = { Text(status, fontSize = 10.sp) }) }
                }
                TextButton(onClick = onOpen, contentPadding = PaddingValues(horizontal = 0.dp)) { Text("Open opportunity"); Spacer(Modifier.width(4.dp)); Icon(Icons.Outlined.ArrowForward, null, Modifier.size(15.dp)) }
            }
        }
    }
}

@Composable
private fun ProfileScreen(
    modifier: Modifier,
    profile: UserProfile,
    settings: SettingsState,
    onProfile: (UserProfile) -> Unit,
    onSettings: () -> Unit,
    onCountries: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var editing by rememberSaveable { mutableStateOf(false) }
    var name by remember(profile.name) { mutableStateOf(profile.name) }
    var headline by remember(profile.headline) { mutableStateOf(profile.headline) }
    var nationality by remember(profile.nationality) { mutableStateOf(profile.nationality) }
    var degree by remember(profile.degree) { mutableStateOf(profile.degree) }
    var field by remember(profile.field) { mutableStateOf(profile.field) }
    var cgpa by remember(profile.cgpa) { mutableStateOf(if (profile.cgpa > 0) profile.cgpa.toString() else "") }
    var cgpaScale by remember(profile.cgpaScale) { mutableStateOf(profile.cgpaScale.toString()) }
    var interests by remember(profile.researchInterests) { mutableStateOf(profile.researchInterests) }
    var publications by remember(profile.publications) { mutableStateOf(profile.publications.toString()) }
    var targetLevel by remember(profile.targetLevel) { mutableStateOf(profile.targetLevel) }
    var researchExperience by remember(profile.researchExperience) { mutableStateOf(profile.researchExperience) }
    var preferredCountries by remember(profile.preferredCountries) { mutableStateOf(profile.preferredCountries) }
    var fullFundingPreferred by remember(profile.fullFundingPreferred) { mutableStateOf(profile.fullFundingPreferred) }
    var prPriority by remember(profile.prPriority) { mutableIntStateOf(profile.prPriority) }

    fun keepUri(uri: Uri?, banner: Boolean) {
        if (uri == null) return
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        onProfile(if (banner) profile.copy(bannerImagePath = uri.toString()) else profile.copy(profileImagePath = uri.toString()))
    }

    val profilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> keepUri(uri, false) }
    val bannerPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> keepUri(uri, true) }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 34.dp)) {
        item { ProfileBannerHero(profile, settings, onSettings) }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { profilePicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Outlined.PhotoCamera, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Photo")
                    }
                    OutlinedButton(onClick = { bannerPicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Outlined.Image, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Banner")
                    }
                }
                Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { onProfile(profile.copy(bannerImagePath = "", bannerStyle = (profile.bannerStyle + 1) % 5)) }) {
                        Icon(Icons.Outlined.AutoAwesome, null, Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Shuffle")
                    }
                    if (profile.profileImagePath.isNotBlank() || profile.bannerImagePath.isNotBlank()) {
                        TextButton(onClick = { onProfile(profile.copy(profileImagePath = "", bannerImagePath = "")) }) { Text("Clear") }
                    }
                }
            }
        }

        item { Text("Academic profile", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) }
        item {
            ElevatedCard(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (editing) {
                        OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(headline, { headline = it }, label = { Text("Headline") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), maxLines = 2)
                        OutlinedTextField(nationality, { nationality = it }, label = { Text("Nationality") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), singleLine = true)
                        OutlinedTextField(degree, { degree = it }, label = { Text("Degree") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), singleLine = true)
                        OutlinedTextField(field, { field = it }, label = { Text("Main field") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), singleLine = true)
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(cgpa, { cgpa = it }, label = { Text("CGPA") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(cgpaScale, { cgpaScale = it }, label = { Text("Scale") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        }
                        Text("Target level", style = MaterialTheme.typography.labelLarge, modifier = Modifier.align(Alignment.Start).padding(top = 15.dp, bottom = 5.dp))
                        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("Master's", "PhD", "Both").forEach { option -> FilterChip(selected = targetLevel == option, onClick = { targetLevel = option }, label = { Text(option) }) }
                        }
                        Text("Preferred destinations", style = MaterialTheme.typography.labelLarge, modifier = Modifier.align(Alignment.Start).padding(top = 15.dp, bottom = 5.dp))
                        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("Germany", "Canada", "Australia", "New Zealand", "Netherlands", "Ireland", "Sweden", "Finland", "Denmark", "United Kingdom", "United States").forEach { country ->
                                FilterChip(
                                    selected = country in preferredCountries,
                                    onClick = { preferredCountries = if (country in preferredCountries) preferredCountries - country else preferredCountries + country },
                                    label = { Text(country) }
                                )
                            }
                        }
                        ToggleRow("Prioritize full funding", "Rank fully funded and salaried research routes more strongly", fullFundingPreferred) { fullFundingPreferred = it }
                        Text("Post-study stay priority: $prPriority%", style = MaterialTheme.typography.labelLarge, modifier = Modifier.align(Alignment.Start).padding(top = 12.dp))
                        Slider(value = prPriority.toFloat(), onValueChange = { prPriority = it.toInt() }, valueRange = 0f..100f, steps = 9)
                        OutlinedTextField(interests, { interests = it }, label = { Text("Study interests") }, minLines = 3, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                        OutlinedTextField(publications, { publications = it }, label = { Text("Publications") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                        ToggleRow("Research experience", "Include this signal in personalized guidance", researchExperience) { researchExperience = it }
                        Button(
                            onClick = {
                                val scale = cgpaScale.toDoubleOrNull()?.takeIf { it > 0 } ?: profile.cgpaScale
                                val grade = cgpa.toDoubleOrNull()?.coerceIn(0.0, scale) ?: profile.cgpa
                                onProfile(
                                    profile.copy(
                                        name = name.trim().ifBlank { "My Profile" }, headline = headline.trim(), nationality = nationality.trim().ifBlank { "Nigeria" },
                                        degree = degree.trim(), field = field.trim(), cgpa = grade, cgpaScale = scale, targetLevel = targetLevel,
                                        researchInterests = interests.trim(), researchExperience = researchExperience,
                                        publications = publications.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                                        preferredCountries = preferredCountries, fullFundingPreferred = fullFundingPreferred, prPriority = prPriority
                                    )
                                )
                                editing = false
                            },
                            modifier = Modifier.fillMaxWidth().padding(top = 14.dp).height(50.dp)
                        ) { Text("Save profile") }
                    } else {
                        ProfileLine("Nationality", profile.nationality)
                        ProfileLine("Degree", profile.degree.ifBlank { "Not set" })
                        ProfileLine("Field", profile.field.ifBlank { "Not set" })
                        ProfileLine("CGPA", if (profile.cgpa > 0.0) "${profile.cgpa}/${profile.cgpaScale}" else "Not set")
                        ProfileLine("Target", profile.targetLevel)
                        ProfileLine("Countries", profile.preferredCountries.joinToString().ifBlank { "Any" })
                        ProfileLine("Funding", if (profile.fullFundingPreferred) "Full funding preferred" else "Any funding")
                        ProfileLine("Stay priority", "${profile.prPriority}%")
                        ProfileLine("Research", if (profile.researchExperience) "Experience added" else "Not added")
                        ProfileLine("Publications", profile.publications.toString())
                        ProfileLine("Interests", profile.researchInterests.ifBlank { "Not set" })
                        Button(onClick = { editing = true }, modifier = Modifier.padding(top = 16.dp).widthIn(min = 210.dp)) {
                            Icon(Icons.Outlined.Edit, null, Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text("Edit profile")
                        }
                    }
                }
            }
        }

        item { Text("Strategy", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) }
        item { Box(Modifier.padding(horizontal = 20.dp)) { SettingAction(Icons.Outlined.Public, "Country insights", "Study and stay-potential planning", onCountries) } }
        item { Box(Modifier.padding(horizontal = 20.dp)) { SettingAction(Icons.Outlined.Settings, "Settings", "Theme, AI, notifications, updates and browsing", onSettings) } }
    }
}

@Composable
private fun ProfileBannerHero(profile: UserProfile, settings: SettingsState, onSettings: () -> Unit) {
    val visual = VisualLibrary.forHero(profile)
    Box(Modifier.fillMaxWidth().height(326.dp)) {
        SmartImage(visual, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.05f), Color.Transparent, Color.Black.copy(.72f)))))
        IconButton(
            onClick = onSettings,
            modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 6.dp, end = 10.dp).background(Color.White.copy(.92f), CircleShape)
        ) { Icon(Icons.Outlined.Settings, "Settings", tint = MaterialTheme.colorScheme.primary) }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(shape = CircleShape, color = Color.White, border = BorderStroke(3.dp, Color.White), shadowElevation = 8.dp) {
                if (profile.profileImagePath.isNotBlank()) {
                    SmartImage(profile.profileImagePath, Modifier.size(86.dp).clip(CircleShape))
                } else {
                    Box(Modifier.size(86.dp).background(Brush.linearGradient(accentGradient(settings.accent))), contentAlignment = Alignment.Center) {
                        Text(profile.name.trim().take(1).ifBlank { "A" }.uppercase(), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text(profile.name.ifBlank { "Your profile" }, style = MaterialTheme.typography.headlineSmall, color = Color.White, modifier = Modifier.padding(top = 9.dp))
            Text(profile.headline.ifBlank { "Postgraduate opportunity explorer" }, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(.86f), modifier = Modifier.padding(top = 3.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
            val cgpa = if (profile.cgpa > 0.0) "${profile.cgpa}/${profile.cgpaScale}" else "CGPA not set"
            Text("${profile.degree.ifBlank { "Degree not set" }} • $cgpa", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.94f), modifier = Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}


@Composable
private fun ProfileLine(label: String, value: String) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            label,
            color = MaterialTheme.colorScheme.onSurface.copy(.48f),
            style = MaterialTheme.typography.labelSmall,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
        )
    }
}

@Composable
private fun CountryInsightsScreen(onBack: () -> Unit, onOpen: (String) -> Unit, onOpenExternal: (String) -> Unit) {
    val countryVisuals = remember { VisualLibrary.uniqueCountryVisuals(SeedData.countries.map { it.country }) }
    Scaffold(topBar = { SimpleBackBar("Country insights", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
            item { InfoBanner("Study destination + long-term strategy", "Stay potential is a planning signal, not immigration advice. Expand each destination, then verify the current rules on the official immigration website.") }
            items(SeedData.countries, key = { it.country }) { c ->
                var expanded by rememberSaveable(c.country) { mutableStateOf(false) }
                val visual = countryVisuals[c.country] ?: VisualLibrary.forCountry(c.country)
                ElevatedCard(
                    Modifier.fillMaxWidth().padding(vertical = 9.dp)
                        .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow))
                        .clickable { expanded = !expanded },
                    shape = RoundedCornerShape(26.dp),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = if (expanded) 9.dp else 4.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        Box(Modifier.fillMaxWidth().height(if (expanded) 220.dp else 168.dp)) {
                            SmartImage(visual, Modifier.fillMaxSize())
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.58f)))))
                            Surface(modifier = Modifier.align(Alignment.TopEnd).padding(12.dp), shape = RoundedCornerShape(50), color = Color.White.copy(.94f)) {
                                Text("${c.stayPotential}/100 stay fit", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                            }
                            Column(Modifier.align(Alignment.BottomStart).padding(15.dp)) {
                                Text(c.country, style = MaterialTheme.typography.headlineSmall, color = Color.White)
                                Text(c.headline, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.86f), modifier = Modifier.padding(top = 2.dp))
                            }
                        }
                        Column(Modifier.padding(16.dp)) {
                            Text(c.detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(.68f), maxLines = if (expanded) 8 else 3, overflow = TextOverflow.Ellipsis)
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (expanded) "Hide destination profile" else "Explore destination", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                                Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown, null, tint = MaterialTheme.colorScheme.primary)
                            }
                            AnimatedVisibility(expanded) {
                                Column(Modifier.padding(top = 8.dp)) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(.07f))
                                    Text("Akademi considers study options, your destination preferences and post-study planning. Immigration rules change, so the official source remains the final authority.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.55f), modifier = Modifier.padding(top = 12.dp))
                                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = { onOpen(c.officialUrl) }, modifier = Modifier.weight(1f)) { Text("View inside") }
                                        OutlinedButton(onClick = { onOpenExternal(c.officialUrl) }, modifier = Modifier.weight(1f)) { Text("External") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    settings: SettingsState,
    onSettings: (SettingsState) -> Unit,
    remoteMessage: String?,
    onRefresh: (String?) -> Unit,
    onBack: () -> Unit,
    onReset: () -> Unit
) {
    var feed by remember(settings.liveFeedUrl) { mutableStateOf(settings.liveFeedUrl) }
    var updateUrl by remember(settings.updateApiUrl) { mutableStateOf(settings.updateApiUrl) }
    val settingsContext = androidx.compose.ui.platform.LocalContext.current
    val instantPushConfigured = remember { settingsContext.resources.getIdentifier("google_app_id", "string", settingsContext.packageName) != 0 }
    val keyStore = remember { SecureGeminiKeyStore(settingsContext) }
    val aiCache = remember { AiInsightCache(settingsContext) }
    val scope = rememberCoroutineScope()
    var apiKeyInput by rememberSaveable { mutableStateOf("") }
    var keyConfigured by remember { mutableStateOf(keyStore.hasKey()) }
    var aiStatus by remember { mutableStateOf<String?>(null) }
    var testingAi by remember { mutableStateOf(false) }
    var updateInfo by remember { mutableStateOf<AppUpdateInfo?>(null) }
    var updateStatus by remember { mutableStateOf<String?>(null) }
    var updateChecking by remember { mutableStateOf(false) }
    var updateDownloading by remember { mutableStateOf(false) }
    var downloadedApk by remember { mutableStateOf<java.io.File?>(null) }

    fun checkUpdates() {
        val endpoint = updateUrl.trim().ifBlank { settings.updateApiUrl }
        if (endpoint.isBlank()) {
            updateStatus = "No update source is configured for this build."
            return
        }
        scope.launch {
            updateChecking = true
            updateStatus = "Checking the signed release channel…"
            UpdateManager.check(endpoint)
                .onSuccess { info ->
                    updateInfo = info
                    updateStatus = if (info == null) "Akademi ${BuildConfig.VERSION_NAME} is up to date." else "Akademi ${info.versionName} is available."
                }
                .onFailure { updateStatus = "Update check failed: ${it.message ?: "unknown error"}" }
            updateChecking = false
        }
    }

    LaunchedEffect(settings.autoUpdateCheck, settings.updateApiUrl) {
        if (settings.autoUpdateCheck && settings.updateApiUrl.isNotBlank()) checkUpdates()
    }

    Scaffold(topBar = { SimpleBackBar("Settings", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
            item { SettingsHeading("Appearance") }
            item {
                SettingsSectionCard {
                    Text("Theme", style = MaterialTheme.typography.titleSmall)
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        ThemeMode.entries.forEach { m ->
                            FilterChip(selected = settings.themeMode == m, onClick = { onSettings(settings.copy(themeMode = m)) }, label = { Text(m.name.lowercase().replaceFirstChar { it.uppercase() }) })
                        }
                    }
                    Text("Accent color", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 18.dp))
                    Text("Choose a lively Akademi palette for buttons, highlights and profile accents.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.56f), modifier = Modifier.padding(top = 3.dp))
                    LazyRow(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(AccentPreset.entries) { a -> AccentPaletteCard(a, settings.accent == a) { onSettings(settings.copy(accent = a)) } }
                    }
                }
            }

            item { SettingsHeading("App behaviour") }
            item {
                SettingsSectionCard {
                    ToggleRow("Notifications", "Master switch for Akademi alerts", settings.notifications) { onSettings(settings.copy(notifications = it)) }
                    SettingsDivider()
                    ToggleRow("New opportunity alerts", "Alert when the collector finds strong profile matches", settings.opportunityAlerts) { onSettings(settings.copy(opportunityAlerts = it)) }
                    SettingsDivider()
                    ToggleRow("Deadline alerts", "Remind you as tracked application deadlines approach", settings.deadlineAlerts) { onSettings(settings.copy(deadlineAlerts = it)) }
                    SettingsDivider()
                    ToggleRow("Refresh on launch", "Refresh the live scholarship feed when Akademi opens", settings.refreshOnLaunch) { onSettings(settings.copy(refreshOnLaunch = it)) }
                    SettingsDivider()
                    ToggleRow("External browser", "Keep off to open sources inside Akademi first", settings.openLinksExternally) { onSettings(settings.copy(openLinksExternally = it)) }
                    SettingsDivider()
                    ToggleRow("Website popups", "Allow new-window and JavaScript popup links inside Akademi", settings.webPopupsEnabled) { onSettings(settings.copy(webPopupsEnabled = it)) }
                    Text(
                        if (instantPushConfigured) "Instant push is configured." else "Instant push is optional; background live-feed alerts still work.",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (instantPushConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.52f),
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            }

            item { SettingsHeading("App updates") }
            item {
                SettingsSectionCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.11f)) {
                            Icon(Icons.Outlined.VerifiedUser, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(9.dp).size(21.dp))
                        }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Signed update channel", style = MaterialTheme.typography.titleSmall)
                            Text("Installed: ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.56f))
                        }
                    }
                    Text(
                        "Release builds use one persistent Akademi signing certificate. Updates are downloaded only over HTTPS and the APK digest is verified when GitHub provides it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(.62f),
                        modifier = Modifier.padding(top = 12.dp)
                    )
                    SettingsDivider()
                    ToggleRow("Check automatically", "Check the release channel when you open Settings", settings.autoUpdateCheck) { onSettings(settings.copy(autoUpdateCheck = it)) }
                    OutlinedTextField(
                        value = updateUrl,
                        onValueChange = { updateUrl = it },
                        label = { Text("Update source") },
                        placeholder = { Text("GitHub releases") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onSettings(settings.copy(updateApiUrl = updateUrl.trim())) },
                            modifier = Modifier.weight(1f)
                        ) { Text("Save source") }
                        Button(onClick = { onSettings(settings.copy(updateApiUrl = updateUrl.trim())); checkUpdates() }, enabled = !updateChecking, modifier = Modifier.weight(1f)) {
                            if (updateChecking) { CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp); Spacer(Modifier.width(6.dp)) }
                            Text(if (updateChecking) "Checking" else "Check now")
                        }
                    }
                    updateStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 9.dp)) }
                    updateInfo?.let { info ->
                        ElevatedCard(
                            Modifier.fillMaxWidth().padding(top = 12.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primary.copy(.06f)),
                            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 0.dp),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Version ${info.versionName} available", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                                if (info.notes.isNotBlank()) Text(info.notes.take(420), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.62f), modifier = Modifier.padding(top = 5.dp), maxLines = 6, overflow = TextOverflow.Ellipsis)
                                Button(
                                    onClick = {
                                        scope.launch {
                                            updateDownloading = true
                                            updateStatus = "Downloading signed update…"
                                            val existing = downloadedApk
                                            if (existing != null && existing.exists()) {
                                                updateStatus = UpdateManager.install(settingsContext, existing)
                                            } else {
                                                UpdateManager.download(settingsContext, info)
                                                    .onSuccess { apk -> downloadedApk = apk; updateStatus = UpdateManager.install(settingsContext, apk) }
                                                    .onFailure { updateStatus = "Update download failed: ${it.message ?: "unknown error"}" }
                                            }
                                            updateDownloading = false
                                        }
                                    },
                                    enabled = !updateDownloading,
                                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                                ) {
                                    if (updateDownloading) { CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp); Spacer(Modifier.width(7.dp)) }
                                    Text(if (updateDownloading) "Preparing update" else "Install update")
                                }
                            }
                        }
                    }
                }
            }

            item { SettingsHeading("Gemini AI") }
            item {
                SettingsSectionCard {
                    ToggleRow("Enable Akademi Intelligence", "Adds source briefs, personalized reviews and scholarship Q&A", settings.aiEnabled) { onSettings(settings.copy(aiEnabled = it)) }
                    SettingsDivider()
                    Text("Model", style = MaterialTheme.typography.titleSmall)
                    Row(Modifier.padding(top = 8.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GeminiClient.supportedModels.forEach { model ->
                            FilterChip(selected = settings.aiModel == model, onClick = { onSettings(settings.copy(aiModel = model)) }, label = { Text(model.removePrefix("gemini-")) })
                        }
                    }
                    Text("API key", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 16.dp))
                    Text(if (keyConfigured) "A Gemini key is encrypted on this device." else "No Gemini key is stored on this device.", style = MaterialTheme.typography.bodySmall, color = if (keyConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.56f), modifier = Modifier.padding(top = 3.dp))
                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it; aiStatus = null },
                        label = { Text(if (keyConfigured) "Replace API key" else "Gemini API key") },
                        placeholder = { Text("Paste API key") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                    Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                runCatching { keyStore.save(apiKeyInput) }
                                    .onSuccess { keyConfigured = true; apiKeyInput = ""; aiStatus = "Gemini key saved securely." }
                                    .onFailure { aiStatus = it.message ?: "Could not save key" }
                            },
                            enabled = apiKeyInput.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Text("Save key") }
                        Button(
                            onClick = {
                                val testKey = apiKeyInput.trim().ifBlank { keyStore.load().orEmpty() }
                                if (testKey.isBlank()) aiStatus = "Add a Gemini API key first."
                                else scope.launch {
                                    testingAi = true; aiStatus = "Testing Gemini…"
                                    GeminiClient.test(testKey, settings.aiModel)
                                        .onSuccess { aiStatus = it }
                                        .onFailure { aiStatus = it.message ?: "Gemini connection failed" }
                                    testingAi = false
                                }
                            },
                            enabled = !testingAi && (apiKeyInput.isNotBlank() || keyConfigured),
                            modifier = Modifier.weight(1f)
                        ) {
                            if (testingAi) { CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp); Spacer(Modifier.width(6.dp)) }
                            Text(if (testingAi) "Testing" else "Test")
                        }
                    }
                    if (keyConfigured) TextButton(onClick = { keyStore.clear(); keyConfigured = false; aiStatus = "Gemini key removed." }) { Text("Remove key") }
                    aiStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = if (it.contains("error", true) || it.contains("failed", true)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(.64f), modifier = Modifier.padding(top = 5.dp)) }
                    SettingsDivider()
                    ToggleRow("Cache AI reviews", "Reuse personalized analysis instead of spending another request", settings.aiCacheEnabled) { onSettings(settings.copy(aiCacheEnabled = it)) }
                    OutlinedButton(onClick = { aiCache.clear(); aiStatus = "AI analysis cache cleared." }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Icon(Icons.Outlined.DeleteSweep, null); Spacer(Modifier.width(8.dp)); Text("Clear AI cache")
                    }
                }
            }

            item { SettingsHeading("Live opportunity feed") }
            item {
                SettingsSectionCard {
                    Text("Collector feed", style = MaterialTheme.typography.titleSmall)
                    Text("The collector publishes normalized scholarship data and can use Gemini to turn source pages into complete in-app opportunity briefs.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.60f), modifier = Modifier.padding(top = 4.dp))
                    OutlinedTextField(feed, { feed = it }, label = { Text("HTTPS feed URL") }, placeholder = { Text("Feed URL") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), singleLine = true)
                    Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onSettings(settings.copy(liveFeedUrl = feed.trim())) }, modifier = Modifier.weight(1f)) { Text("Save") }
                        Button(onClick = { val u = feed.trim(); onSettings(settings.copy(liveFeedUrl = u)); onRefresh(u) }, modifier = Modifier.weight(1f)) { Text("Refresh") }
                    }
                    remoteMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.60f), modifier = Modifier.padding(top = 8.dp)) }
                }
            }

            item { SettingsHeading("Privacy & data") }
            item {
                SettingsSectionCard {
                    Text("Profile, tracker and appearance preferences are stored locally. The Gemini key is encrypted with Android Keystore. Professor searches are sent directly to OpenAlex when requested.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.64f))
                    OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                        Icon(Icons.Outlined.RestartAlt, null); Spacer(Modifier.width(8.dp)); Text("Reset local data")
                    }
                }
            }

            item { SettingsHeading("About") }
            item {
                SettingsSectionCard {
                    AkademiWordmark()
                    Text(
                        "Version ${BuildConfig.VERSION_NAME} • Travel discovery UX • Inter typography • White cards • Gemini source briefs • Live collector • Professor profiles • Video + forum research • Signed in-app updates",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(.55f),
                        modifier = Modifier.padding(top = 9.dp)
                    )
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun SettingsSectionCard(content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        color = MaterialTheme.colorScheme.onSurface.copy(.07f),
        modifier = Modifier.padding(vertical = 8.dp)
    )
}


@Composable
private fun AccentPaletteCard(preset: AccentPreset, selected: Boolean, onClick: () -> Unit) {
    val colors = accentGradient(preset)
    Surface(
        modifier = Modifier.width(132.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.10f)),
        shadowElevation = if (selected) 7.dp else 2.dp,
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.padding(8.dp)) {
            Box(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(colors))) {
                if (selected) Surface(Modifier.align(Alignment.TopEnd).padding(6.dp), shape = CircleShape, color = Color.White.copy(.92f)) { Icon(Icons.Filled.Check, null, tint = colors.first(), modifier = Modifier.padding(4.dp).size(14.dp)) }
            }
            Text(preset.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 3.dp, top = 7.dp, bottom = 2.dp))
        }
    }
}

@Composable private fun SettingsHeading(text: String) { Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp, bottom = 10.dp)) }
@Composable private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onCheck: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f).padding(end = 12.dp)) { Text(title, style = MaterialTheme.typography.titleSmall); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.56f), modifier = Modifier.padding(top = 3.dp)) }; Switch(checked = checked, onCheckedChange = onCheck) } }
@Composable private fun SettingAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) { ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable(onClick = onClick), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleSmall); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.6f), modifier = Modifier.padding(top = 3.dp)) }; Icon(Icons.Outlined.ChevronRight, null) } } }

@Composable private fun SimpleBackBar(title: String, onBack: () -> Unit) { Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }; Text(title, style = MaterialTheme.typography.titleLarge) } }

@Composable private fun InfoBanner(title: String, body: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.Top) { Icon(Icons.Outlined.Info, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp)); Column { Text(title, style = MaterialTheme.typography.titleSmall); Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(.67f), modifier = Modifier.padding(top = 4.dp)) } }
    }
}

@Composable
private fun WebScreen(url: String, popupsEnabled: Boolean, onExternal: () -> Unit, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val activity = context as? android.app.Activity
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageTitle by remember { mutableStateOf("Source") }
    var loading by remember { mutableStateOf(true) }
    var customView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    fun hideFullscreenVideo() {
        val view = customView ?: return
        val decor = activity?.window?.decorView as? ViewGroup
        decor?.removeView(view)
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    fun handleBack() {
        if (customView != null) hideFullscreenVideo()
        else {
            val view = webView
            if (view?.canGoBack() == true) view.goBack() else onBack()
        }
    }

    BackHandler { handleBack() }
    DisposableEffect(Unit) {
        onDispose {
            hideFullscreenVideo()
            webView?.stopLoading()
            webView?.destroy()
        }
    }

    Scaffold(topBar = {
        if (customView == null) {
            Column {
                Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { handleBack() }) { Icon(Icons.Outlined.ArrowBack, "Back") }
                    Column(Modifier.weight(1f)) {
                        Text(pageTitle.ifBlank { "Source" }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(webView?.url ?: url, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                    }
                    IconButton(onClick = { webView?.reload() }) { Icon(Icons.Outlined.Refresh, "Reload") }
                    IconButton(onClick = onExternal) { Icon(Icons.Outlined.OpenInNew, "Open externally") }
                }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        }
    }) { p ->
        AndroidView(
            modifier = Modifier.padding(if (customView == null) p else PaddingValues(0.dp)).fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    webView = this
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadsImagesAutomatically = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.javaScriptCanOpenWindowsAutomatically = popupsEnabled
                    settings.setSupportMultipleWindows(popupsEnabled)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val target = request?.url?.toString().orEmpty()
                            return if (target.startsWith("http://") || target.startsWith("https://")) {
                                view?.loadUrl(target); true
                            } else false
                        }
                        override fun onPageFinished(view: WebView?, url: String?) { loading = false }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) { loading = newProgress < 100 }
                        override fun onReceivedTitle(view: WebView?, title: String?) { pageTitle = title.orEmpty() }
                        override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                            if (view == null || activity == null) { callback?.onCustomViewHidden(); return }
                            if (customView != null) { callback?.onCustomViewHidden(); return }
                            customView = view
                            customViewCallback = callback
                            val decor = activity.window.decorView as ViewGroup
                            decor.addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                            activity.window.decorView.systemUiVisibility =
                                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        }
                        override fun onHideCustomView() { hideFullscreenVideo() }
                        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                            if (!popupsEnabled || view == null || resultMsg == null) return false
                            val popup = WebView(ctx)
                            popup.settings.javaScriptEnabled = true
                            popup.settings.domStorageEnabled = true
                            popup.settings.javaScriptCanOpenWindowsAutomatically = true
                            popup.settings.setSupportMultipleWindows(true)
                            popup.webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                                    val target = request?.url?.toString().orEmpty()
                                    if (target.startsWith("http")) {
                                        view.loadUrl(target)
                                        popup.destroy()
                                        return true
                                    }
                                    return false
                                }
                                override fun onPageStarted(v: WebView?, popupUrl: String?, favicon: android.graphics.Bitmap?) {
                                    if (!popupUrl.isNullOrBlank() && popupUrl != "about:blank") {
                                        view.loadUrl(popupUrl)
                                        popup.destroy()
                                    }
                                }
                            }
                            val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                            transport.webView = popup
                            resultMsg.sendToTarget()
                            return true
                        }
                    }
                    loadUrl(url)
                }
            },
            update = { view ->
                view.settings.javaScriptCanOpenWindowsAutomatically = popupsEnabled
                view.settings.setSupportMultipleWindows(popupsEnabled)
            }
        )
    }
}

private fun openUrl(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
