package com.akademi.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

@Composable
fun SmartImage(
    source: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    placeholderColor: Color = Color(0xFFE9EEF8),
    fallbackSource: String = "",
    fallback: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current
    val bitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(initialValue = null, source, fallbackSource) {
        value = withContext(Dispatchers.IO) {
            fun decode(value: String): Bitmap? {
                if (value.isBlank()) return null
                return runCatching {
                    when {
                        value.startsWith("content://") || value.startsWith("file://") ->
                            context.contentResolver.openInputStream(Uri.parse(value))?.use(BitmapFactory::decodeStream)
                        value.startsWith("res://") -> {
                            val name = value.removePrefix("res://")
                            val id = context.resources.getIdentifier(name, "drawable", context.packageName)
                            if (id == 0) null else BitmapFactory.decodeResource(context.resources, id)
                        }
                        value.startsWith("http://") || value.startsWith("https://") -> {
                            val connection = URL(value).openConnection() as HttpURLConnection
                            connection.connectTimeout = 7000
                            connection.readTimeout = 9000
                            connection.instanceFollowRedirects = true
                            connection.setRequestProperty("User-Agent", "Akademi/0.4")
                            try { connection.inputStream.use { BitmapFactory.decodeStream(it) } }
                            finally { connection.disconnect() }
                        }
                        else -> null
                    }
                }.getOrNull()
            }
            (decode(source) ?: decode(fallbackSource))?.asImageBitmap()
        }
    }

    if (bitmap != null) {
        Image(bitmap = bitmap!!, contentDescription = null, modifier = modifier, contentScale = contentScale)
    } else {
        Box(modifier = modifier.background(placeholderColor), contentAlignment = Alignment.Center) {
            fallback?.invoke()
        }
    }
}
