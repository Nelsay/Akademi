# Akademi Android v0.5.1

Akademi is a personal postgraduate opportunity-intelligence app for scholarships, funded research positions, professors, research directions, country/stay planning, application tracking, success stories and optional Gemini guidance.

## v0.5.1 travel-discovery UX rebuild

- Rebuilt the main visual system around the supplied premium travel-app reference rather than a dashboard/database look.
- Added an icon-first floating bottom navigation: filled active icons, muted outlined inactive icons, soft rounded container, compact labels only on the active destination.
- Home now opens with an image-led profile/travel hero, preserving the LinkedIn-style profile context while making study-abroad exploration the emotional focus.
- Discover now feels like a travel explore screen: clean search field, filter chips, image-first opportunity cards, destination/provider overlays and visible match scores.
- Professor, research-direction, country, success-story and tracker cards now use editorial imagery and expand inside Akademi before any external source is opened.
- Opportunity details now begin with a large visual hero while keeping all extracted scholarship facts, Gemini analysis, tracker actions and source controls.
- Added 26 optimized bundled WebP editorial assets covering campuses, destinations, labs, design, computing, student life, travel, libraries, networking and application planning.
- Real collector/source images are preferred when available. Bundled visuals are automatic fallbacks when a page provides no reliable image or an image fails to load.
- Generic research imagery is explicitly not presented as a real professor portrait.
- Pure `#FFFFFF` card surfaces remain enforced in light mode; dark mode still uses proper dark surfaces.
- Inter typography, generous spacing, soft shadows, spring/fade transitions, in-app browsing, popup support and full-screen YouTube remain intact.

## Existing Akademi capabilities preserved

- Works across academic disciplines; research directions and professor searches adapt to the saved profile.
- Editable CGPA and scale, degree, field, nationality, target level, research interests and experience.
- User-selected profile photo and banner image using Android's document picker.
- Live opportunity collector with source-image metadata and normalized scholarship details.
- Background notifications, deadline tracking and optional Firebase Cloud Messaging.
- Multiple accent palettes, system/light/dark themes and live-feed preferences.
- Optional Gemini Intelligence with an encrypted local API key and local analysis cache.
- Collector can optionally enrich public opportunity metadata with Gemini via the `GEMINI_API_KEY` GitHub secret.

The core app remains usable without Gemini or Firebase.


## v0.5.1 notification center

The Home bell is now functional. It opens a persistent in-app Notification Center with unread badges, strong-match alerts, tracked deadline reminders, mark-all-read/clear actions, opportunity deep links, and Android notification taps that return to the relevant Akademi content.


## v0.5.1 premium discovery + signed updates

- Full-bleed Home and Profile banners with functional Home route search.
- Compact image-left opportunity feed cards and functional blue refresh.
- Non-repeating content-aware editorial image fallbacks; real source imagery wins when available.
- Professor results use circular profile avatars; research Directions remain text-led.
- Stories split into Video and Forum with field-aware relevance searches.
- Opportunity details keep source/Gemini briefs, funding, eligibility, documents, application steps and selection information inside Akademi.
- Profile editing and Settings use larger safe margins and calmer card spacing.
- Persistent release signing begins in v0.5.1. Future releases built with the same private signing key can update the installed app in place.
- Settings includes an HTTPS + SHA-256 aware GitHub Release update checker/downloader.

See `UPDATES.md` before building.
