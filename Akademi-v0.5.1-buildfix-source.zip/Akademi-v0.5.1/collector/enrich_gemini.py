#!/usr/bin/env python3
"""Optional Gemini enrichment for Akademi's public opportunity feed.

Gemini receives only public scholarship-page text collected from official or
high-authority sources. It converts that text into a complete in-app brief so a
user can understand the opportunity inside Akademi before choosing to open the
original page. Values are evidence-bound: missing facts are labelled as not
stated rather than guessed.
"""
from __future__ import annotations
import argparse, json, os, time
from datetime import datetime, timezone
from pathlib import Path
import requests

AI_FIELDS = [
    "aiSummary", "aiRequirements", "aiActions", "aiSelectionSignals", "aiRisks",
    "aiFundingNotes", "aiConfidence", "aiModel", "aiUpdatedAt"
]
ENRICHED_CORE_FIELDS = [
    "requirements", "eligibility", "documents", "howToApply", "selectionProcess",
    "benefits", "languageRequirements", "tuitionCoverage", "stipend",
    "livingAllowance", "travelSupport", "applicationFee", "duration", "startDate",
    "requiresSupervisor"
]

SCHEMA = {
    "type":"object",
    "properties":{
        "full_summary":{"type":"string"},
        "eligibility":{"type":"array","items":{"type":"string"}},
        "requirements":{"type":"array","items":{"type":"string"}},
        "documents":{"type":"array","items":{"type":"string"}},
        "application_steps":{"type":"array","items":{"type":"string"}},
        "selection_process":{"type":"array","items":{"type":"string"}},
        "benefits":{"type":"array","items":{"type":"string"}},
        "language_requirements":{"type":"array","items":{"type":"string"}},
        "funding_notes":{"type":"string"},
        "tuition_coverage":{"type":"string"},
        "stipend":{"type":"string"},
        "living_allowance":{"type":"string"},
        "travel_support":{"type":"string"},
        "application_fee":{"type":"string"},
        "duration":{"type":"string"},
        "start_date":{"type":"string"},
        "supervisor":{"type":"string"},
        "selection_signals":{"type":"array","items":{"type":"string"}},
        "risks":{"type":"array","items":{"type":"string"}},
        "actions":{"type":"array","items":{"type":"string"}},
        "confidence":{"type":"string","enum":["low","medium","high"]}
    },
    "required":[
        "full_summary","eligibility","requirements","documents","application_steps",
        "selection_process","benefits","language_requirements","funding_notes",
        "tuition_coverage","stipend","living_allowance","travel_support","application_fee",
        "duration","start_date","supervisor","selection_signals","risks","actions","confidence"
    ]
}

def load(path):
    try: return json.loads(Path(path).read_text())
    except Exception: return []

def output_text(resp):
    for step in reversed(resp.get("steps") or []):
        if step.get("type") == "model_output":
            parts=[p.get("text","") for p in (step.get("content") or []) if p.get("type") == "text"]
            if parts: return "\n".join(parts)
    raise RuntimeError("Gemini returned no text output")

def stated(value):
    value=(value or "").strip()
    return value if value else "Not stated on source"

def call(api_key, model, item):
    source_text=(item.get("sourceExtract") or "")[:22000]
    prompt = f"""Create a comprehensive, evidence-bound in-app brief for this postgraduate scholarship or funded research opportunity.

RULES:
- Use ONLY the public source text and metadata supplied below.
- Never invent eligibility, deadlines, funding amounts, dates, degree requirements, language scores, benefits, supervisor rules, or acceptance odds.
- If a fact is absent, use the exact phrase: Not stated on source.
- The full_summary should be useful enough that an applicant can understand the opportunity without first opening the webpage. Cover purpose, who it is for, what is funded, key eligibility, application route, deadline/status, and important caveats when the source states them.
- Keep list items factual and concise; do not add generic scholarship advice to factual sections.
- actions may contain practical preparation advice, clearly separated from factual requirements.

METADATA
Title: {item.get('title','')}
Provider: {item.get('provider','')}
Country: {item.get('country','')}
Level: {item.get('level','')}
Field: {item.get('field','')}
Funding classification: {item.get('funding','')}
Deadline extracted: {item.get('deadline','')}
Status: {item.get('status','')}
Existing summary: {item.get('summary','')}

PUBLIC SOURCE PAGE TEXT
---
{source_text}
---
"""
    body={
        "model":model,
        "input":prompt,
        "system_instruction":"You are Akademi's cautious scholarship source analyst. Extract and organize facts from the supplied page only. Never fill gaps with assumptions.",
        "store":False,
        "generation_config":{"max_output_tokens":1800,"thinking_level":"low"},
        "response_format":{"type":"text","mime_type":"application/json","schema":SCHEMA}
    }
    r=requests.post(
        "https://generativelanguage.googleapis.com/v1beta/interactions",
        headers={"x-goog-api-key":api_key,"Content-Type":"application/json"},
        json=body, timeout=75
    )
    if r.status_code >= 300:
        raise RuntimeError(f"Gemini HTTP {r.status_code}: {r.text[:300]}")
    return json.loads(output_text(r.json()))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--current', default='feed/opportunities.json')
    ap.add_argument('--previous', default='')
    ap.add_argument('--max-new', type=int, default=6)
    args=ap.parse_args()
    current=load(args.current)
    previous=load(args.previous) if args.previous else []
    prev={x.get('id') or x.get('sourceUrl'):x for x in previous if isinstance(x,dict)}
    reused=0

    for item in current:
        old=prev.get(item.get('id') or item.get('sourceUrl'))
        same_source=bool(old and old.get('sourceHash') and old.get('sourceHash') == item.get('sourceHash'))
        if same_source and old.get('aiSummary'):
            for f in AI_FIELDS + ENRICHED_CORE_FIELDS:
                if old.get(f) not in (None,"",[]): item[f]=old.get(f)
            reused += 1

    key=os.getenv('GEMINI_API_KEY','').strip()
    model=os.getenv('GEMINI_MODEL','gemini-3.6-flash').strip() or 'gemini-3.6-flash'
    enriched=0
    if key:
        for item in current:
            if enriched >= args.max_new: break
            if item.get('aiSummary'): continue
            if not item.get('sourceExtract'): continue
            try:
                data=call(key,model,item)
                item.update({
                    'aiSummary':data.get('full_summary','').strip(),
                    'aiRequirements':data.get('requirements') or [],
                    'aiActions':data.get('actions') or [],
                    'aiSelectionSignals':data.get('selection_signals') or [],
                    'aiRisks':data.get('risks') or [],
                    'aiFundingNotes':stated(data.get('funding_notes')),
                    'aiConfidence':data.get('confidence',''),
                    'aiModel':model,
                    'aiUpdatedAt':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
                    'requirements':data.get('requirements') or item.get('requirements') or [],
                    'eligibility':data.get('eligibility') or item.get('eligibility') or [],
                    'documents':data.get('documents') or item.get('documents') or [],
                    'howToApply':data.get('application_steps') or item.get('howToApply') or [],
                    'selectionProcess':data.get('selection_process') or item.get('selectionProcess') or [],
                    'benefits':data.get('benefits') or item.get('benefits') or [],
                    'languageRequirements':data.get('language_requirements') or item.get('languageRequirements') or [],
                    'tuitionCoverage':stated(data.get('tuition_coverage')),
                    'stipend':stated(data.get('stipend')),
                    'livingAllowance':stated(data.get('living_allowance')),
                    'travelSupport':stated(data.get('travel_support')),
                    'applicationFee':stated(data.get('application_fee')),
                    'duration':stated(data.get('duration')),
                    'startDate':stated(data.get('start_date')),
                    'requiresSupervisor':stated(data.get('supervisor')),
                })
                enriched += 1
                time.sleep(.4)
            except Exception as e:
                print(f"AI enrichment skipped for {item.get('title','untitled')}: {e}")

    for item in current:
        item.pop('sourceExtract', None)

    Path(args.current).write_text(json.dumps(current,ensure_ascii=False,indent=2)+"\n")
    if key:
        print(f"Gemini source enrichment complete: {enriched} refreshed, {reused} unchanged-source records reused.")
    else:
        print(f"Gemini secret not configured; reused {reused} unchanged-source AI briefs and removed temporary source extracts.")

if __name__ == '__main__': main()
