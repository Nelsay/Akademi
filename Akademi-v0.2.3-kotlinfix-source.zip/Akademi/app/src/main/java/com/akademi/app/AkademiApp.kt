package com.akademi.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Message
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.akademi.app.data.*
import com.akademi.app.settings.*
import com.akademi.app.notifications.AkademiNotificationManager
import com.akademi.app.push.OptionalFcmPush
import com.akademi.app.ui.AkademiMark
import com.akademi.app.ui.AkademiWordmark
import com.akademi.app.ui.theme.AkademiTheme
import com.akademi.app.ui.theme.Gold
import com.akademi.app.ui.theme.Teal
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Screen { HOME, DISCOVER, RESEARCH, TRACKER, PROFILE, SETTINGS, COUNTRIES, STORIES, DETAIL, WEB }

@Composable
fun AkademiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { AppPreferences(context) }
    var settings by remember { mutableStateOf(prefs.loadSettings()) }
    var profile by remember { mutableStateOf(prefs.loadProfile()) }
    var tracker by remember { mutableStateOf(prefs.loadTracker()) }
    var opportunities by remember { mutableStateOf(SeedData.opportunities) }
    var selected by remember { mutableStateOf<Opportunity?>(null) }
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var lastMain by rememberSaveable { mutableStateOf(Screen.HOME) }
    var showSplash by rememberSaveable { mutableStateOf(true) }
    var remoteMessage by remember { mutableStateOf<String?>(null) }
    var webUrl by rememberSaveable { mutableStateOf("") }
    var returnScreen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val scope = rememberCoroutineScope()
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun go(next: Screen) {
        if (next in listOf(Screen.HOME, Screen.DISCOVER, Screen.RESEARCH, Screen.TRACKER, Screen.PROFILE)) lastMain = next
        screen = next
    }
    fun openInside(url: String) {
        returnScreen = screen
        webUrl = url
        screen = Screen.WEB
    }
    fun openOutside(url: String) { openUrl(context, url) }
    fun openLink(url: String) { if (settings.openLinksExternally) openOutside(url) else openInside(url) }
    fun loadRemote(feedOverride: String? = null) {
        val feedUrl = feedOverride?.trim().orEmpty().ifBlank { settings.liveFeedUrl }
        if (feedUrl.isBlank()) {
            remoteMessage = "Add a normalized HTTPS feed URL in Settings to enable live opportunity updates."
            return
        }
        scope.launch {
            remoteMessage = "Refreshing live feed…"
            val result = RemoteOpportunityRepository.fetch(feedUrl)
            result.onSuccess { remote ->
                opportunities = (remote + SeedData.opportunities).distinctBy { it.id }
                remoteMessage = "Loaded ${remote.size} live opportunities."
            }.onFailure { remoteMessage = "Feed refresh failed: ${it.message ?: "unknown error"}" }
        }
    }

    LaunchedEffect(Unit) {
        delay(850)
        showSplash = false
        if (settings.refreshOnLaunch && settings.liveFeedUrl.isNotBlank()) loadRemote()
    }

    LaunchedEffect(settings.notifications, settings.liveFeedUrl) {
        if (settings.notifications) OptionalFcmPush.initialize(context)
        AkademiNotificationManager.schedule(context, settings.notifications && settings.liveFeedUrl.isNotBlank())
        if (settings.notifications && Build.VERSION.SDK_INT >= 33 && !AkademiNotificationManager.canNotify(context)) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    BackHandler(enabled = !showSplash && screen != Screen.HOME && screen != Screen.WEB) {
        screen = when (screen) {
            Screen.DETAIL, Screen.COUNTRIES, Screen.STORIES -> lastMain
            Screen.SETTINGS -> Screen.PROFILE
            Screen.DISCOVER, Screen.RESEARCH, Screen.TRACKER, Screen.PROFILE -> Screen.HOME
            else -> screen
        }
    }

    AkademiTheme(settings) {
        if (showSplash) {
            SplashScreen()
        } else {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (screen) {
                    Screen.DETAIL -> OpportunityDetailScreen(
                        scored = selected?.let { MatchEngine.score(profile, it) },
                        tracked = selected?.let { o -> tracker.any { it.opportunityId == o.id } } == true,
                        onBack = { screen = lastMain },
                        onOpenInside = { selected?.sourceUrl?.let { openInside(it) } },
                        onOpenExternal = { selected?.sourceUrl?.let { openOutside(it) } },
                        onApplyInside = { selected?.let { openInside(it.applicationUrl.ifBlank { it.sourceUrl }) } },
                        onTrack = {
                            selected?.let { o ->
                                if (tracker.none { it.opportunityId == o.id }) {
                                    tracker = tracker + TrackerItem(o.id)
                                    prefs.saveTracker(tracker)
                                }
                            }
                        }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        settings = settings,
                        onSettings = { settings = it; prefs.saveSettings(it) },
                        remoteMessage = remoteMessage,
                        onRefresh = { url -> loadRemote(url) },
                        onBack = { screen = Screen.PROFILE },
                        onReset = {
                            prefs.reset()
                            settings = SettingsState()
                            profile = UserProfile()
                            tracker = emptyList()
                            opportunities = SeedData.opportunities
                            remoteMessage = "Local Akademi data reset."
                        }
                    )
                    Screen.COUNTRIES -> CountryInsightsScreen(onBack = { screen = lastMain }, onOpen = ::openLink)
                    Screen.STORIES -> SuccessStoriesScreen(onBack = { screen = lastMain }, onOpen = ::openLink)
                    Screen.WEB -> WebScreen(url = webUrl, popupsEnabled = settings.webPopupsEnabled, onExternal = { openOutside(webUrl) }, onBack = { screen = returnScreen })
                    else -> MainScaffold(
                        screen = screen,
                        onNavigate = ::go
                    ) { padding ->
                        when (screen) {
                            Screen.HOME -> HomeScreen(
                                modifier = Modifier.padding(padding), profile = profile, opportunities = opportunities,
                                tracker = tracker, onDiscover = { go(Screen.DISCOVER) }, onResearch = { go(Screen.RESEARCH) },
                                onCountries = { screen = Screen.COUNTRIES }, onStories = { screen = Screen.STORIES },
                                onOpportunity = { selected = it; screen = Screen.DETAIL }
                            )
                            Screen.DISCOVER -> DiscoverScreen(
                                modifier = Modifier.padding(padding), profile = profile, opportunities = opportunities,
                                remoteMessage = remoteMessage, onRefresh = { loadRemote() },
                                onOpportunity = { selected = it; screen = Screen.DETAIL }
                            )
                            Screen.RESEARCH -> ResearchScreen(
                                modifier = Modifier.padding(padding), profile = profile,
                                onOpen = ::openLink, onStories = { screen = Screen.STORIES }
                            )
                            Screen.TRACKER -> TrackerScreen(
                                modifier = Modifier.padding(padding), opportunities = opportunities, tracker = tracker,
                                onTracker = { tracker = it; prefs.saveTracker(it) },
                                onOpen = { o -> selected = o; screen = Screen.DETAIL }
                            )
                            Screen.PROFILE -> ProfileScreen(
                                modifier = Modifier.padding(padding), profile = profile,
                                onProfile = { profile = it; prefs.saveProfile(it) },
                                onSettings = { screen = Screen.SETTINGS }, onCountries = { screen = Screen.COUNTRIES }
                            )
                            else -> Unit
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.secondary).systemBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(shape = RoundedCornerShape(30.dp), color = Color.White, shadowElevation = 8.dp) {
                Box(Modifier.padding(14.dp), contentAlignment = Alignment.Center) { AkademiMark(Modifier.size(104.dp)) }
            }
            Spacer(Modifier.height(18.dp))
            Text("Akademi", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.SemiBold)
            Text("OPPORTUNITY INTELLIGENCE", color = Color(0xFF7FD1C9), fontSize = 12.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))
            Text("SCHOLARSHIPS • RESEARCH • GLOBAL IMPACT", color = Color.White.copy(alpha = .78f), fontSize = 10.sp)
        }
    }
}

@Composable
private fun MainScaffold(screen: Screen, onNavigate: (Screen) -> Unit, content: @Composable (PaddingValues) -> Unit) {
    val tabs = listOf(
        Triple(Screen.HOME, "Home", Icons.Outlined.Home),
        Triple(Screen.DISCOVER, "Discover", Icons.Outlined.Search),
        Triple(Screen.RESEARCH, "Research", Icons.Outlined.Science),
        Triple(Screen.TRACKER, "Tracker", Icons.Outlined.Checklist),
        Triple(Screen.PROFILE, "Profile", Icons.Outlined.Person)
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEach { (s, label, icon) ->
                    NavigationBarItem(
                        selected = screen == s,
                        onClick = { onNavigate(s) },
                        icon = { Icon(icon, label) },
                        label = { Text(label, fontSize = 11.sp) }
                    )
                }
            }
        },
        content = content
    )
}

@Composable
private fun PageHeader(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            subtitle?.let { Text(it, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f), fontSize = 13.sp) }
        }
        trailing?.invoke()
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    profile: UserProfile,
    opportunities: List<Opportunity>,
    tracker: List<TrackerItem>,
    onDiscover: () -> Unit,
    onResearch: () -> Unit,
    onCountries: () -> Unit,
    onStories: () -> Unit,
    onOpportunity: (Opportunity) -> Unit
) {
    val scored = remember(profile, opportunities) { opportunities.map { MatchEngine.score(profile, it) }.sortedByDescending { it.score } }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Good day 👋", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f), fontSize = 13.sp)
                    Text("Ready to find your next opportunity?", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
                AkademiMark(Modifier.size(45.dp))
            }
        }
        item {
            ElevatedCard(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(.12f)), contentAlignment = Alignment.Center) {
                        Text(profile.field.take(1).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(profile.name, fontWeight = FontWeight.Bold)
                        Text("${profile.degree} • CGPA ${profile.cgpa}/${profile.cgpaScale}", fontSize = 13.sp)
                        Text(profile.nationality, color = MaterialTheme.colorScheme.onSurface.copy(.6f), fontSize = 12.sp)
                    }
                    Icon(Icons.Outlined.Verified, null, tint = Teal)
                }
            }
        }
        item { SectionTitle("Your overview") }
        item {
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("${scored.count { it.score >= 70 }}", "Strong matches", Modifier.weight(1f))
                StatCard("${opportunities.size}", "Opportunities", Modifier.weight(1f))
                StatCard("${tracker.size}", "In tracker", Modifier.weight(1f))
            }
        }
        item { SectionTitle("Quick actions") }
        item {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickAction("Discover", "Scholarships & funded PhDs", Icons.Outlined.TravelExplore, Modifier.weight(1f), onDiscover)
                    QuickAction("Professors", "Researchers & publications", Icons.Outlined.Groups, Modifier.weight(1f), onResearch)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickAction("Countries", "Study, work & stay insights", Icons.Outlined.Public, Modifier.weight(1f), onCountries)
                    QuickAction("Stories", "Real application experiences", Icons.Outlined.AutoStories, Modifier.weight(1f), onStories)
                }
            }
        }
        item { SectionTitle("Best matches for you") }
        items(scored.take(4)) { s -> OpportunityCard(s, onClick = { onOpportunity(s.opportunity) }) }
        item {
            InfoBanner(
                "Match score ≠ acceptance probability",
                "Akademi scores profile fit using academic strength, field alignment, eligibility, funding preferences and country strategy. Final selection remains competitive."
            )
        }
    }
}

@Composable private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f))
        }
    }
}

@Composable private fun QuickAction(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    ElevatedCard(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f), maxLines = 2)
        }
    }
}

@Composable private fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 10.dp))
}

@Composable
private fun DiscoverScreen(
    modifier: Modifier, profile: UserProfile, opportunities: List<Opportunity>, remoteMessage: String?, onRefresh: () -> Unit,
    onOpportunity: (Opportunity) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var level by rememberSaveable { mutableStateOf("All") }
    var funding by rememberSaveable { mutableStateOf("All") }
    val filtered = remember(query, level, funding, opportunities, profile) {
        opportunities.filter { o ->
            (query.isBlank() || (o.title + o.provider + o.country + o.field).contains(query, true)) &&
                (level == "All" || o.level.contains(level, true)) &&
                (funding == "All" || o.funding.contains(funding, true))
        }.map { MatchEngine.score(profile, it) }.sortedByDescending { it.score }
    }
    Column(modifier.fillMaxSize()) {
        PageHeader("Discover", "Scholarships, fellowships and funded research") {
            IconButton(onClick = onRefresh) { Icon(Icons.Outlined.Refresh, "Refresh") }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            leadingIcon = { Icon(Icons.Outlined.Search, null) }, placeholder = { Text("Search plant science, Germany, PhD…") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)
        )
        Row(Modifier.padding(horizontal = 20.dp, vertical = 10.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Master's", "PhD").forEach { v -> FilterChip(selected = level == v, onClick = { level = v }, label = { Text(v) }) }
            listOf("All", "Fully", "Salary", "Partial").forEach { v -> FilterChip(selected = funding == v, onClick = { funding = v }, label = { Text(if (v == "All") "Any funding" else v) }) }
        }
        remoteMessage?.let { Text(it, Modifier.padding(horizontal = 20.dp, vertical = 4.dp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f)) }
        Text("${filtered.size} opportunities • sorted by your fit", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(filtered) { s -> OpportunityCard(s, onClick = { onOpportunity(s.opportunity) }) }
        }
    }
}

@Composable
private fun OpportunityCard(s: ScoredOpportunity, onClick: () -> Unit) {
    val o = s.opportunity
    ElevatedCard(
        Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    AssistChip(onClick = {}, label = { Text(o.funding.uppercase(), fontSize = 10.sp) })
                    Spacer(Modifier.height(7.dp))
                    Text(o.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(o.provider, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f))
                }
                Box(Modifier.size(54.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(.10f)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${s.score}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("/100", fontSize = 9.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SmallMeta(Icons.Outlined.Place, o.country)
                SmallMeta(Icons.Outlined.School, o.level)
            }
            Spacer(Modifier.height(5.dp))
            SmallMeta(Icons.Outlined.Event, o.deadline)
            Spacer(Modifier.height(10.dp))
            Text(o.status, fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable private fun SmallMeta(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurface.copy(.55f))
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun OpportunityDetailScreen(
    scored: ScoredOpportunity?,
    tracked: Boolean,
    onBack: () -> Unit,
    onOpenInside: () -> Unit,
    onOpenExternal: () -> Unit,
    onApplyInside: () -> Unit,
    onTrack: () -> Unit
) {
    if (scored == null) return
    val o = scored.opportunity
    Scaffold(
        topBar = {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }
                Text("Opportunity details", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onOpenExternal) { Icon(Icons.Outlined.OpenInNew, "Open externally") }
            }
        }
    ) { p ->
        LazyColumn(Modifier.padding(p).fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 32.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = {}, label = { Text(o.funding.uppercase(), fontSize = 10.sp) })
                    if (o.verified) AssistChip(onClick = {}, leadingIcon = { Icon(Icons.Filled.Verified, null, Modifier.size(15.dp)) }, label = { Text("SOURCE CHECKED", fontSize = 10.sp) })
                }
            }
            item { Text(o.title, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 32.sp) }
            item { Text("${o.provider} • ${o.country}", color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 5.dp)) }
            if (o.lastChecked.isNotBlank()) item { Text("Last checked: ${o.lastChecked}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.48f), modifier = Modifier.padding(top = 3.dp)) }
            item {
                ElevatedCard(Modifier.fillMaxWidth().padding(top = 18.dp), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Your match strength", fontWeight = FontWeight.SemiBold)
                                Text(matchLabel(scored.score), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                            Text("${scored.score}/100", fontWeight = FontWeight.Bold, fontSize = 24.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator({ scored.score / 100f }, Modifier.fillMaxWidth())
                    }
                }
            }
            item { SectionTitleNoIndent("Why Akademi matched it") }
            items(scored.reasons) { reason -> CheckRow(reason) }

            item { SectionTitleNoIndent("Major details") }
            item {
                DetailRow("Type", o.opportunityType)
                DetailRow("Level", o.level)
                DetailRow("Field", o.field)
                DetailRow("Country", o.country)
                DetailRow("Study mode", o.studyMode)
                DetailRow("Duration", o.duration)
                DetailRow("Start", o.startDate)
                DetailRow("Deadline", o.deadline)
                DetailRow("Status", o.status)
                DetailRow("Supervisor", o.requiresSupervisor)
                DetailRow("Application fee", o.applicationFee)
            }

            item { SectionTitleNoIndent("Funding & benefits") }
            item {
                DetailRow("Funding", o.funding)
                DetailRow("Tuition", o.tuitionCoverage)
                DetailRow("Stipend", o.stipend)
                DetailRow("Living support", o.livingAllowance)
                DetailRow("Travel", o.travelSupport)
            }
            if (o.benefits.isNotEmpty()) items(o.benefits) { CheckRow(it) }

            if (o.eligibility.isNotEmpty() || o.eligibleNationalities.isNotEmpty()) {
                item { SectionTitleNoIndent("Eligibility") }
                if (o.eligibleNationalities.isNotEmpty()) item { DetailRow("Nationality", o.eligibleNationalities.joinToString(", ")) }
                items(o.eligibility) { CheckRow(it, checked = false) }
            }

            item { SectionTitleNoIndent("Requirements") }
            if (o.requirements.isEmpty()) item { Text("No structured requirements extracted yet. Verify the original source before applying.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f)) }
            items(o.requirements) { CheckRow(it, checked = false) }
            if (o.languageRequirements.isNotEmpty()) {
                item { Text("Language", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp)) }
                items(o.languageRequirements) { CheckRow(it, checked = false) }
            }

            if (o.documents.isNotEmpty()) {
                item { SectionTitleNoIndent("Documents") }
                items(o.documents) { CheckRow(it, checked = false) }
            }
            if (o.howToApply.isNotEmpty()) {
                item { SectionTitleNoIndent("How to apply") }
                items(o.howToApply) { step -> NumberedInfoRow(step, o.howToApply.indexOf(step) + 1) }
            }
            if (o.selectionProcess.isNotEmpty()) {
                item { SectionTitleNoIndent("Selection process") }
                items(o.selectionProcess) { CheckRow(it, checked = false) }
            }

            item { SectionTitleNoIndent("About this opportunity") }
            item { Text(o.summary.ifBlank { "Akademi found this opportunity from its source network. Open the official source below for the original wording and final verification." }, color = MaterialTheme.colorScheme.onSurface.copy(.75f), lineHeight = 22.sp) }
            item {
                Spacer(Modifier.height(22.dp))
                Button(onClick = onTrack, enabled = !tracked, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp)) {
                    Icon(if (tracked) Icons.Filled.Check else Icons.Outlined.BookmarkAdd, null)
                    Spacer(Modifier.width(8.dp)); Text(if (tracked) "Already in tracker" else "Save & start application")
                }
                if (o.applicationUrl.isNotBlank()) {
                    Button(onClick = onApplyInside, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(50.dp), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Outlined.Send, null); Spacer(Modifier.width(8.dp)); Text("Open application page inside Akademi")
                    }
                }
                OutlinedButton(onClick = onOpenInside, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(50.dp), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Outlined.Language, null); Spacer(Modifier.width(8.dp)); Text("View original source inside Akademi")
                }
                TextButton(onClick = onOpenExternal, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Icon(Icons.Outlined.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text("Open original source in external browser")
                }
                Text("The official source is always the final authority for eligibility, deadlines and funding.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(.5f), modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
            }
        }
    }
}

@Composable private fun NumberedInfoRow(text: String, number: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(.12f)) {
            Text(number.toString(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
        }
        Spacer(Modifier.width(9.dp)); Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f), lineHeight = 19.sp)
    }
}

@Composable private fun SectionTitleNoIndent(text: String) = Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 24.dp, bottom = 10.dp))
@Composable private fun CheckRow(text: String, checked: Boolean = true) { Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) { Icon(if (checked) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked, null, tint = if (checked) Teal else MaterialTheme.colorScheme.onSurface.copy(.35f), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f)) } }
@Composable private fun DetailRow(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(label, Modifier.width(92.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f)); Text(value, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f)) } }
private fun matchLabel(score: Int) = when { score >= 85 -> "Excellent fit"; score >= 70 -> "Strong fit"; score >= 55 -> "Possible fit"; else -> "Needs review" }

@Composable
private fun ResearchScreen(modifier: Modifier, profile: UserProfile, onOpen: (String) -> Unit, onStories: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize()) {
        PageHeader("Research", "Professors, papers and research directions")
        TabRow(selectedTabIndex = tab) {
            Tab(tab == 0, onClick = { tab = 0 }, text = { Text("Professors") })
            Tab(tab == 1, onClick = { tab = 1 }, text = { Text("Directions") })
            Tab(tab == 2, onClick = { tab = 2 }, text = { Text("Stories") })
        }
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> ProfessorFinder(profile, onOpen)
                1 -> ResearchDirections()
                else -> StoryPreview(onStories)
            }
        }
    }
}

@Composable
private fun ProfessorFinder(profile: UserProfile, onOpen: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf(profile.researchInterests.substringBefore(",")) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Searches current OpenAlex publications to surface researchers working in your topic.") }
    var researchers by remember { mutableStateOf<List<Researcher>>(emptyList()) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, label = { Text("Research topic") }, placeholder = { Text("plant drought tolerance") })
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = {
                loading = true; message = "Searching OpenAlex…"
                scope.launch {
                    OpenAlexRepository.searchResearchers(query).onSuccess { researchers = it; message = "${it.size} researchers surfaced from relevant publications." }.onFailure { message = "Search failed: ${it.message}" }
                    loading = false
                }
            }) { Icon(Icons.Outlined.Search, "Search") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(message, Modifier.padding(horizontal = 20.dp, vertical = 6.dp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (researchers.isEmpty()) {
                item { InfoBanner("Try a focused topic", "Examples: plant genomics, drought tolerance, plant pathology, biodiversity conservation, crop improvement, restoration ecology.") }
            }
            items(researchers) { r ->
                ElevatedCard(Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(15.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(.12f)), contentAlignment = Alignment.Center) { Text(r.name.take(1), fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) { Text(r.name, fontWeight = FontWeight.Bold); Text(r.institution, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f)); if (r.country.isNotBlank()) Text(r.country, fontSize = 11.sp) }
                            Text("${r.fitScore}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                        if (r.topics.isNotEmpty()) Text(r.topics.joinToString(" • "), fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp), maxLines = 2)
                        OutlinedButton(onClick = { onOpen(r.openAlexUrl) }, modifier = Modifier.padding(top = 10.dp)) { Text("Open research profile") }
                    }
                }
            }
        }
    }
}

@Composable private fun ResearchDirections() {
    val dirs = listOf(
        Triple("Plant biotechnology", "High scholarship/research fit", "Genetics, molecular biology, crop improvement"),
        Triple("Climate & plant stress biology", "Strong global funding relevance", "Drought, heat, salinity and resilient crops"),
        Triple("Plant genomics", "Excellent research career path", "Genetics, sequencing, breeding and bioinformatics"),
        Triple("Ecology & biodiversity", "Strong conservation route", "Ecosystems, restoration and biodiversity science"),
        Triple("Agricultural & crop science", "Strong employment alignment", "Food security, agronomy and sustainable production")
    )
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp)) {
        item { InfoBanner("Your Botany degree is broader than the word “Botany”", "Akademi expands searches into adjacent postgraduate fields so you do not miss funded programmes that match your background.") }
        items(dirs) { (title, label, body) ->
            ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 6.dp), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) { Text(title, fontWeight = FontWeight.Bold); Text(label, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp); Text(body, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f), modifier = Modifier.padding(top = 5.dp)) }
            }
        }
    }
}

@Composable private fun StoryPreview(onStories: () -> Unit) {
    Column(Modifier.padding(20.dp)) {
        InfoBanner("Learn from real applicants", "Akademi keeps official requirements separate from anecdotal experience. Search winner stories, interviews and forum discussions, then verify requirements at the source.")
        Button(onClick = onStories, modifier = Modifier.fillMaxWidth()) { Text("Open success-story hub") }
    }
}

@Composable
private fun SuccessStoriesScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    Scaffold(topBar = { SimpleBackBar("Success stories & application intelligence", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(20.dp)) {
            item { InfoBanner("Official facts vs personal experience", "Forum, YouTube and blog stories are useful for strategy, but Akademi treats them as anecdotal and keeps official programme requirements separate.") }
            item { StoryLink("Erasmus Mundus student stories", "Search YouTube for detailed application walkthroughs", "https://www.youtube.com/results?search_query=Erasmus+Mundus+scholarship+Nigerian+student+experience", onOpen) }
            item { StoryLink("DAAD scholarship experiences", "Find interviews and applicant processes", "https://www.youtube.com/results?search_query=DAAD+scholarship+Nigeria+experience", onOpen) }
            item { StoryLink("Commonwealth scholarship experiences", "Winner advice, essays and interviews", "https://www.youtube.com/results?search_query=Commonwealth+scholarship+Nigeria+winner+experience", onOpen) }
            item { StoryLink("Reddit scholarship discussions", "Search community threads and compare multiple perspectives", "https://www.google.com/search?q=site%3Areddit.com+scholarship+masters+phd+international+student+experience", onOpen) }
            item { StoryLink("Motivation-letter research", "Search scholarship-specific guidance rather than generic templates", "https://www.google.com/search?q=scholarship+motivation+letter+official+university+guidance", onOpen) }
        }
    }
}

@Composable private fun StoryLink(title: String, body: String, url: String, onOpen: (String) -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 7.dp).clickable { onOpen(url) }, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.PlayCircle, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(body, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.62f)) }
            Icon(Icons.Outlined.OpenInNew, null, Modifier.size(18.dp))
        }
    }
}

@Composable
private fun TrackerScreen(modifier: Modifier, opportunities: List<Opportunity>, tracker: List<TrackerItem>, onTracker: (List<TrackerItem>) -> Unit, onOpen: (Opportunity) -> Unit) {
    Column(modifier.fillMaxSize()) {
        PageHeader("My tracker", "Plan, apply and follow up")
        val preparing = tracker.count { it.status == "Preparing" }; val applied = tracker.count { it.status == "Applied" }; val interview = tracker.count { it.status == "Interview" }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("$preparing", "Preparing", Modifier.weight(1f)); StatCard("$applied", "Applied", Modifier.weight(1f)); StatCard("$interview", "Interview", Modifier.weight(1f))
        }
        if (tracker.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Outlined.Bookmarks, null, Modifier.size(52.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp)); Text("Nothing saved yet", fontWeight = FontWeight.Bold); Text("Open an opportunity and tap “Save & start application”.", textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)) {
                items(tracker, key = { it.opportunityId }) { t ->
                    val o = opportunities.firstOrNull { it.id == t.opportunityId }
                    if (o != null) TrackerCard(o, t, onChange = { changed -> onTracker(tracker.map { if (it.opportunityId == t.opportunityId) changed else it }) }, onRemove = { onTracker(tracker.filterNot { it.opportunityId == t.opportunityId }) }, onOpen = { onOpen(o) })
                }
            }
        }
    }
}

@Composable private fun TrackerCard(o: Opportunity, t: TrackerItem, onChange: (TrackerItem) -> Unit, onRemove: () -> Unit, onOpen: () -> Unit) {
    ElevatedCard(Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row { Column(Modifier.weight(1f)) { Text(o.title, fontWeight = FontWeight.Bold); Text(o.provider, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f)) }; IconButton(onClick = onRemove) { Icon(Icons.Outlined.Delete, "Remove") } }
            LinearProgressIndicator({ t.progress / 100f }, Modifier.fillMaxWidth().padding(vertical = 10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${t.progress}%", modifier = Modifier.width(45.dp), fontSize = 12.sp)
                Slider(value = t.progress.toFloat(), onValueChange = { onChange(t.copy(progress = it.toInt())) }, valueRange = 0f..100f, steps = 9, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Preparing", "Applied", "Interview", "Offer").forEach { status -> FilterChip(selected = t.status == status, onClick = { onChange(t.copy(status = status)) }, label = { Text(status, fontSize = 10.sp) }) }
            }
            TextButton(onClick = onOpen) { Text("View opportunity") }
        }
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier, profile: UserProfile, onProfile: (UserProfile) -> Unit, onSettings: () -> Unit, onCountries: () -> Unit) {
    var editing by rememberSaveable { mutableStateOf(false) }
    var name by remember(profile.name) { mutableStateOf(profile.name) }
    var degree by remember(profile.degree) { mutableStateOf(profile.degree) }
    var field by remember(profile.field) { mutableStateOf(profile.field) }
    var interests by remember(profile.researchInterests) { mutableStateOf(profile.researchInterests) }
    Column(modifier.fillMaxSize()) {
        PageHeader("Profile", "Your data powers Akademi's transparent fit scoring") { IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, "Settings") } }
        LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp)) {
            item {
                ElevatedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AkademiMark(Modifier.size(54.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(profile.name, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("${profile.degree} • ${profile.nationality}", fontSize = 12.sp) }
                            Text("${profile.cgpa}/${profile.cgpaScale}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
            item { SectionTitleNoIndent("Academic profile") }
            item {
                if (editing) {
                    OutlinedTextField(name, { name = it }, label = { Text("Name / profile label") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(degree, { degree = it }, label = { Text("Degree") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(field, { field = it }, label = { Text("Field") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    OutlinedTextField(interests, { interests = it }, label = { Text("Research interests") }, minLines = 3, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    Button(onClick = { onProfile(profile.copy(name = name, degree = degree, field = field, researchInterests = interests)); editing = false }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("Save profile") }
                } else {
                    ProfileLine("Nationality", profile.nationality); ProfileLine("Degree", profile.degree); ProfileLine("Field", profile.field); ProfileLine("CGPA", "${profile.cgpa}/${profile.cgpaScale}"); ProfileLine("Target", profile.targetLevel); ProfileLine("Research interests", profile.researchInterests)
                    OutlinedButton(onClick = { editing = true }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("Edit profile") }
                }
            }
            item { SectionTitleNoIndent("Strategy") }
            item { SettingAction(Icons.Outlined.Public, "Country & stay-potential insights", "Compare countries when long-term work/residence matters", onCountries) }
            item { SettingAction(Icons.Outlined.Settings, "Settings", "Theme, accent colors, live feed and app preferences", onSettings) }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable private fun ProfileLine(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) { Text(label, Modifier.width(115.dp), color = MaterialTheme.colorScheme.onSurface.copy(.55f), fontSize = 12.sp); Text(value, Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Medium) } }

@Composable
private fun CountryInsightsScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    Scaffold(topBar = { SimpleBackBar("Country insights", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(20.dp)) {
            item { InfoBanner("Stay potential is a planning signal, not immigration advice", "Rules can change. Akademi links to official immigration sources so you can verify the current pathway before applying or accepting an offer.") }
            items(SeedData.countries) { c ->
                ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 7.dp), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text(c.country, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f)); Text("${c.stayPotential}/100", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
                        Text(c.headline, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        Text(c.detail, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), modifier = Modifier.padding(top = 8.dp), lineHeight = 18.sp)
                        TextButton(onClick = { onOpen(c.officialUrl) }) { Text("Check official immigration source") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    settings: SettingsState, onSettings: (SettingsState) -> Unit, remoteMessage: String?, onRefresh: (String?) -> Unit,
    onBack: () -> Unit, onReset: () -> Unit
) {
    var feed by remember(settings.liveFeedUrl) { mutableStateOf(settings.liveFeedUrl) }
    val settingsContext = androidx.compose.ui.platform.LocalContext.current
    val instantPushConfigured = remember { settingsContext.resources.getIdentifier("google_app_id", "string", settingsContext.packageName) != 0 }
    Scaffold(topBar = { SimpleBackBar("Settings", onBack) }) { p ->
        LazyColumn(Modifier.padding(p), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp)) {
            item { SettingsHeading("Appearance") }
            item {
                Text("Theme", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(Modifier.padding(vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ThemeMode.entries.forEach { m -> FilterChip(selected = settings.themeMode == m, onClick = { onSettings(settings.copy(themeMode = m)) }, label = { Text(m.name.lowercase().replaceFirstChar { it.uppercase() }) }) }
                }
            }
            item {
                Text("Accent color", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(Modifier.padding(vertical = 8.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AccentPreset.entries.forEach { a -> FilterChip(selected = settings.accent == a, onClick = { onSettings(settings.copy(accent = a)) }, label = { Text(a.name.lowercase().replaceFirstChar { it.uppercase() }) }) }
                }
            }
            item { SettingsHeading("App behaviour") }
            item { ToggleRow("Notifications", "Master switch for Akademi alerts", settings.notifications) { onSettings(settings.copy(notifications = it)) } }
            item { ToggleRow("New opportunity alerts", "Notify when the live collector finds new strong profile matches", settings.opportunityAlerts) { onSettings(settings.copy(opportunityAlerts = it)) } }
            item { ToggleRow("Deadline alerts", "Remind you about tracked applications as deadlines approach", settings.deadlineAlerts) { onSettings(settings.copy(deadlineAlerts = it)) } }
            item { ToggleRow("Refresh live feed on launch", "Refresh the collector feed whenever Akademi opens", settings.refreshOnLaunch) { onSettings(settings.copy(refreshOnLaunch = it)) } }
            item { ToggleRow("Allow external browser by default", "Off by default. Opportunity details still open in Akademi first", settings.openLinksExternally) { onSettings(settings.copy(openLinksExternally = it)) } }
            item { ToggleRow("Web-page popups & new-window links", "Allow target=_blank and JavaScript window links while browsing sources inside Akademi", settings.webPopupsEnabled) { onSettings(settings.copy(webPopupsEnabled = it)) } }
            item { Text(if (instantPushConfigured) "Instant push: Firebase Cloud Messaging configured" else "Instant push: optional Firebase config not installed; background live-feed alerts remain active", fontSize = 11.sp, color = if (instantPushConfigured) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(.58f), modifier = Modifier.padding(top = 6.dp)) }
            item { SettingsHeading("Live opportunity feed") }
            item { Text("Akademi does not require a paid AI API. The included collector workflow publishes a normalized HTTPS feed automatically when it is installed beside the source ZIP in GitHub.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f), lineHeight = 18.sp) }
            item {
                OutlinedTextField(feed, { feed = it }, label = { Text("HTTPS feed URL") }, placeholder = { Text("https://…/opportunities.json") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), singleLine = true)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onSettings(settings.copy(liveFeedUrl = feed.trim())) }, modifier = Modifier.weight(1f)) { Text("Save feed") }
                    Button(onClick = { val u = feed.trim(); onSettings(settings.copy(liveFeedUrl = u)); onRefresh(u) }, modifier = Modifier.weight(1f)) { Text("Save & refresh") }
                }
                remoteMessage?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f), modifier = Modifier.padding(top = 6.dp)) }
            }
            item { SettingsHeading("Privacy & data") }
            item { Text("Profile, tracker and appearance preferences are stored locally on the device in this MVP. Professor searches are sent directly to OpenAlex when you request them.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.68f)) }
            item { OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Icon(Icons.Outlined.RestartAlt, null); Spacer(Modifier.width(8.dp)); Text("Reset local app data") } }
            item { SettingsHeading("About") }
            item { AkademiWordmark(); Text("Version 0.2.1 • Live collector • Background alerts • In-app details & browsing", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.55f), modifier = Modifier.padding(top = 8.dp, bottom = 30.dp)) }
        }
    }
}

@Composable private fun SettingsHeading(text: String) { Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(top = 18.dp, bottom = 10.dp)) }
@Composable private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onCheck: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Medium); Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.58f)) }; Switch(checked = checked, onCheckedChange = onCheck) } }
@Composable private fun SettingAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) { ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable(onClick = onClick), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f)) }; Icon(Icons.Outlined.ChevronRight, null) } } }

@Composable private fun SimpleBackBar(title: String, onBack: () -> Unit) { Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }; Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp) } }

@Composable private fun InfoBanner(title: String, body: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(.08f)), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.Top) { Icon(Icons.Outlined.Info, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp)); Column { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(body, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(.67f), modifier = Modifier.padding(top = 4.dp), lineHeight = 16.sp) } }
    }
}

@Composable
private fun WebScreen(url: String, popupsEnabled: Boolean, onExternal: () -> Unit, onBack: () -> Unit) {
    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageTitle by remember { mutableStateOf("Source") }
    var loading by remember { mutableStateOf(true) }

    fun handleBack() {
        val view = webView
        if (view?.canGoBack() == true) view.goBack() else onBack()
    }

    BackHandler { handleBack() }

    Scaffold(topBar = {
        Column {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { handleBack() }) { Icon(Icons.Outlined.ArrowBack, "Back") }
                Column(Modifier.weight(1f)) {
                    Text(pageTitle.ifBlank { "Source" }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(webView?.url ?: url, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(.55f))
                }
                IconButton(onClick = onExternal) { Icon(Icons.Outlined.OpenInNew, "Open externally") }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        }
    }) { p ->
        AndroidView(
            modifier = Modifier.padding(p).fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    webView = this
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.loadsImagesAutomatically = true
                    settings.javaScriptCanOpenWindowsAutomatically = popupsEnabled
                    settings.setSupportMultipleWindows(popupsEnabled)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val target = request?.url?.toString().orEmpty()
                            return if (target.startsWith("http://") || target.startsWith("https://")) {
                                view?.loadUrl(target); true
                            } else false
                        }
                        override fun onPageFinished(view: WebView?, url: String?) { loading = false }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) { loading = newProgress < 100 }
                        override fun onReceivedTitle(view: WebView?, title: String?) { pageTitle = title.orEmpty() }
                        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                            if (!popupsEnabled || view == null || resultMsg == null) return false
                            val popup = WebView(ctx)
                            popup.settings.javaScriptEnabled = true
                            popup.webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                                    val target = request?.url?.toString().orEmpty()
                                    if (target.startsWith("http")) {
                                        view.loadUrl(target)
                                        popup.destroy()
                                        return true
                                    }
                                    return false
                                }
                                override fun onPageStarted(v: WebView?, popupUrl: String?, favicon: android.graphics.Bitmap?) {
                                    if (!popupUrl.isNullOrBlank() && popupUrl != "about:blank") {
                                        view.loadUrl(popupUrl)
                                        popup.destroy()
                                    }
                                }
                            }
                            val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                            transport.webView = popup
                            resultMsg.sendToTarget()
                            return true
                        }
                    }
                    loadUrl(url)
                }
            },
            update = { view ->
                view.settings.javaScriptCanOpenWindowsAutomatically = popupsEnabled
                view.settings.setSupportMultipleWindows(popupsEnabled)
            }
        )
    }
}

private fun openUrl(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
