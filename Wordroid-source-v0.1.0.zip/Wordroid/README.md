# Wordroid v0.1.0

Wordroid is a tablet-first Android word processor with a desktop-style workspace. This source package is intentionally dependency-light and is built with the Android framework rather than a large third-party UI stack so ZIP-based GitHub builds remain predictable.

## Identity

- App name: **Wordroid**
- Application ID: `com.nelsay.wordroid`
- Version: `0.1.0` / versionCode `1`
- Minimum Android: API 26
- Target / compile SDK: API 36
- Release signing alias: `wordroid`
- Release certificate SHA-256: `5A:82:51:E2:A5:67:52:24:BE:4F:D6:CB:D5:FB:CE:FD:DF:05:DA:DD:95:EC:6A:B4:C5:C5:91:6F:E4:09:29:A5`

## Implemented in this first build

- Desktop-style top command bar, document tabs, ribbon tabs, ruler, page workspace and status bar.
- Multiple open documents in tabs. New/open documents create fresh tabs.
- Phone/tablet safe-area handling for status bars, display cutouts and gesture/navigation insets.
- Rich-text editing: bold, italic, underline, size, text colour, highlight, alignment and bullets.
- Undo / redo history plus keyboard shortcuts such as Ctrl+Z, Ctrl+Y, Ctrl+B, Ctrl+I, Ctrl+U, Ctrl+F, Ctrl+H, Ctrl+S, Ctrl+T and Ctrl+W.
- Draggable horizontal ruler margins plus margin presets, A4/Letter and portrait/landscape page sizing.
- Heading 1–3 markers and basic automatic Table of Contents generation.
- Find, Find Previous/Next, Replace One, Replace All and Match Case.
- Insert image, clipped image frames, simple shapes, simple table text grid, text-box style block, links and page-break marker.
- Interface accent palettes plus custom HEX colour and document style presets.
- On-demand Google Font downloads (Inter, Poppins, Playfair Display, Lora and Montserrat) with offline reuse after download.
- DOCX import to editable text and DOCX export.
- PDF export and Android print flow.
- PDF tab viewing with page navigation and basic note annotation/export.
- Local autosave recovery for dirty documents.
- Light/dark chrome and focus view.
- Wordroid W artwork used as the launcher icon.

## Important v0.1 limitations

This is a functional first build, not a claim of full Microsoft Word parity. DOCX import/export currently preserves the editable text/paragraph structure but does **not** round-trip all Word formatting, floating objects, comments, headers/footers, advanced tables, tracked changes or embedded media. PDF mode supports viewing and a basic annotation/export flow; it is not yet direct object-level PDF text/image editing. The page canvas is desktop-like but is not yet a full professional pagination/layout engine.

Those are the main areas to harden after the first install/build has been verified on the target tablet.

## GitHub ZIP build

Use the separately supplied `build-wordroid-from-zip.yml` workflow. The intended repository layout is:

```text
YOUR-PRIVATE-REPOSITORY/
├── Wordroid-source-v0.1.0.zip
└── .github/
    └── workflows/
        └── build-wordroid-from-zip.yml
```

Then open **Actions → Build Signed Wordroid from ZIP → Run workflow**. The workflow extracts the ZIP before Gradle setup, installs the API 36 build stack, verifies the permanent release certificate, builds `assembleRelease`, verifies the APK signature and uploads `Wordroid-v0.1.0-signed.apk` as a workflow artifact.

### Keep the repository private

The source ZIP contains Wordroid's permanent release keystore because this is a personal app and future builds need the same certificate for Android to install updates over the existing app. Do not publish the ZIP, keystore or `signing/keystore.properties` in a public repository.

### Future updates

For every update:

1. Keep `applicationId 'com.nelsay.wordroid'` unchanged.
2. Keep `signing/wordroid-release.jks` unchanged.
3. Increase `versionCode` in the GitHub workflow input (2, 3, 4...).
4. Change `versionName` as desired (0.1.1, 0.2.0...).
5. Replace the source ZIP in the private repository and run the same workflow.

The workflow refuses to build if the signing certificate changes, protecting in-place update compatibility.
