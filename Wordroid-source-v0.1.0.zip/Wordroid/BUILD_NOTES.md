# Wordroid build notes

The GitHub workflow is deliberately based on the more reliable pattern used after earlier ZIP-build failures:

- Extract the Android source ZIP **before** Gradle/project discovery.
- Use **JDK 17**.
- Use **Android Gradle Plugin 8.13.2 + Gradle 8.13**.
- Compile/target **Android API 36** and use **Build Tools 35.0.0**.
- Use the runner's preinstalled Android command-line tools rather than `android-actions/setup-android`, avoiding old/retired SDK package requests.
- Pin and verify the Gradle 8.13 distribution SHA-256.
- Verify the permanent Wordroid signing certificate before compiling.
- Verify the resulting APK with `apksigner` before uploading it.
- Upload the Gradle diagnostic log when a workflow run fails.

The source intentionally has no third-party runtime dependencies, reducing Maven-resolution and version-conflict failure points.
