package com.nelsay.wordroid;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.text.Editable;
import android.text.Layout;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.AlignmentSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.text.style.MetricAffectingSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_OPEN = 100;
    private static final int REQ_SAVE_DOCX = 101;
    private static final int REQ_SAVE_PDF = 102;
    private static final int REQ_IMAGE = 103;
    private static final int REQ_PDF_ANNOTATED = 104;

    private final ArrayList<DocumentModel> docs = new ArrayList<>();
    private long nextDocId = 1;
    private int activeIndex = -1;
    private int untitledCount = 1;
    private boolean switchingDoc = false;
    private boolean applyingHistory = false;
    private String pendingImageMode = "image";

    private LinearLayout root;
    private LinearLayout tabRow;
    private LinearLayout ribbonTabs;
    private HorizontalScrollView ribbonScroll;
    private LinearLayout ribbonPanel;
    private RulerView ruler;
    private FrameLayout workspace;
    private ScrollView docVertical;
    private HorizontalScrollView docHorizontal;
    private FrameLayout page;
    private EditText editor;
    private TextView statusText;
    private TextView zoomText;
    private LinearLayout pdfPanel;
    private ImageView pdfImage;
    private TextView pdfPageText;
    private TextView pdfNoteText;

    private ParcelFileDescriptor pdfFd;
    private PdfRenderer pdfRenderer;
    private int pdfPageIndex = 0;
    private int currentAccent = Color.rgb(23, 105, 232);
    private boolean darkChrome = false;
    private int zoomPercent = 100;
    private String activeRibbon = "Home";

    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();

    private final Map<String, String> googleFonts = new LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        googleFonts.put("Inter", "https://raw.githubusercontent.com/google/fonts/main/ofl/inter/Inter%5Bopsz,wght%5D.ttf");
        googleFonts.put("Poppins", "https://raw.githubusercontent.com/google/fonts/main/ofl/poppins/Poppins-Regular.ttf");
        googleFonts.put("Playfair Display", "https://raw.githubusercontent.com/google/fonts/main/ofl/playfairdisplay/PlayfairDisplay%5Bwght%5D.ttf");
        googleFonts.put("Lora", "https://raw.githubusercontent.com/google/fonts/main/ofl/lora/Lora%5Bwght%5D.ttf");
        googleFonts.put("Montserrat", "https://raw.githubusercontent.com/google/fonts/main/ofl/montserrat/Montserrat%5Bwght%5D.ttf");

        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= 26) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        else if (Build.VERSION.SDK_INT >= 23) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);

        buildUi();
        installSafeInsets();
        newDocument();
        offerRecoveredDocuments();
        handleIncomingIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri uri = intent.getData();
        String mime = intent.getType();
        openUri(uri, mime);
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(242, 244, 247));
        setContentView(root);

        root.addView(buildTopBar(), lpMatch(dp(48)));
        root.addView(buildTabStrip(), lpMatch(dp(42)));
        root.addView(buildRibbonTabs(), lpMatch(dp(38)));
        ribbonScroll = new HorizontalScrollView(this);
        ribbonScroll.setHorizontalScrollBarEnabled(false);
        ribbonPanel = new LinearLayout(this);
        ribbonPanel.setOrientation(LinearLayout.HORIZONTAL);
        ribbonPanel.setGravity(Gravity.CENTER_VERTICAL);
        ribbonPanel.setPadding(dp(8), dp(4), dp(8), dp(4));
        ribbonScroll.addView(ribbonPanel, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(ribbonScroll, lpMatch(dp(58)));

        ruler = new RulerView(this);
        ruler.setListener((left, right) -> {
            DocumentModel d = currentDoc();
            if (d != null && d.kind == DocumentModel.Kind.DOCUMENT) {
                d.leftMarginDp = left;
                d.rightMarginDp = right;
                applyEditorMargins(d);
                markDirty();
            }
        });
        root.addView(ruler, lpMatch(dp(34)));

        workspace = new FrameLayout(this);
        workspace.setBackgroundColor(Color.rgb(226, 230, 235));
        root.addView(workspace, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        buildDocumentWorkspace();
        buildPdfWorkspace();
        root.addView(buildStatusBar(), lpMatch(dp(32)));
        showRibbon("Home");
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), 0, dp(8), 0);
        bar.setBackgroundColor(Color.WHITE);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.nelsay.wordroid.R.drawable.wordroid_mark);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bar.addView(logo, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView title = label("Wordroid", 18, true);
        title.setPadding(dp(8), 0, dp(16), 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        bar.addView(topAction("↶", v -> undoLike()));
        bar.addView(topAction("↷", v -> redoLike()));
        bar.addView(topAction("⌕", v -> showFindReplace(false)));
        bar.addView(topAction("Save", v -> saveCurrent()));
        bar.addView(topAction("⋮", v -> showFileMenu()));
        return bar;
    }

    private View buildTabStrip() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setBackgroundColor(Color.rgb(245, 246, 248));
        tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setGravity(Gravity.BOTTOM);
        Button plus = button("＋", 14);
        plus.setOnClickListener(v -> newDocument());
        tabRow.addView(plus, new LinearLayout.LayoutParams(dp(46), dp(38)));
        scroll.addView(tabRow, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return scroll;
    }

    private View buildRibbonTabs() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setBackgroundColor(Color.WHITE);
        ribbonTabs = new LinearLayout(this);
        ribbonTabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"File", "Home", "Insert", "Design", "Layout", "References", "Review", "View"};
        for (String n : names) {
            TextView b = ribbonTab(n);
            b.setOnClickListener(v -> showRibbon(n));
            ribbonTabs.addView(b, new LinearLayout.LayoutParams(dp(n.equals("References") ? 104 : 82), ViewGroup.LayoutParams.MATCH_PARENT));
        }
        scroll.addView(ribbonTabs, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return scroll;
    }

    private void buildDocumentWorkspace() {
        docHorizontal = new HorizontalScrollView(this);
        docHorizontal.setFillViewport(true);
        docVertical = new ScrollView(this);
        docVertical.setFillViewport(true);
        LinearLayout canvas = new LinearLayout(this);
        canvas.setOrientation(LinearLayout.VERTICAL);
        canvas.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        canvas.setPadding(dp(28), dp(28), dp(28), dp(36));

        page = new FrameLayout(this);
        GradientDrawable pageBg = rounded(Color.WHITE, Color.rgb(209, 214, 221), 0, 1);
        page.setBackground(pageBg);
        int pageWidth = dp(794);
        int pageHeight = dp(1123);
        canvas.addView(page, new LinearLayout.LayoutParams(pageWidth, pageHeight));

        editor = new EditText(this);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setBackgroundColor(Color.TRANSPARENT);
        editor.setTextColor(Color.rgb(24, 28, 33));
        editor.setHintTextColor(Color.rgb(160, 165, 172));
        editor.setHint("Start typing…");
        editor.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        editor.setLineSpacing(0, 1.25f);
        editor.setPadding(dp(72), dp(72), dp(72), dp(72));
        editor.setSingleLine(false);
        editor.setHorizontallyScrolling(false);
        editor.setSelectAllOnFocus(false);
        editor.setTextIsSelectable(true);
        editor.setGravity(Gravity.TOP);
        page.addView(editor, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        editor.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {
                if (!switchingDoc && !applyingHistory) {
                    DocumentModel d = currentDoc();
                    if (d != null && d.kind == DocumentModel.Kind.DOCUMENT) {
                        SpannableStringBuilder snapshot = new SpannableStringBuilder(s);
                        boolean duplicate = !d.undoStack.isEmpty() && d.undoStack.get(d.undoStack.size() - 1).toString().equals(snapshot.toString());
                        if (!duplicate) {
                            d.undoStack.add(snapshot);
                            while (d.undoStack.size() > 80) d.undoStack.remove(0);
                        }
                        d.redoStack.clear();
                    }
                }
            }
            public void onTextChanged(CharSequence s, int st, int before, int count) {
                if (!switchingDoc && !applyingHistory) { markDirty(); refreshStatus(); scheduleAutosave(); }
            }
            public void afterTextChanged(Editable s) {}
        });
        editor.setOnKeyListener((v, keyCode, event) -> handleEditorKey(keyCode, event));

        docVertical.addView(canvas, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        docHorizontal.addView(docVertical, new HorizontalScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        workspace.addView(docHorizontal, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void buildPdfWorkspace() {
        pdfPanel = new LinearLayout(this);
        pdfPanel.setOrientation(LinearLayout.VERTICAL);
        pdfPanel.setGravity(Gravity.CENTER_HORIZONTAL);
        pdfPanel.setPadding(dp(18), dp(12), dp(18), dp(18));
        pdfPanel.setVisibility(View.GONE);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        Button prev = button("‹ Previous", 12);
        Button next = button("Next ›", 12);
        Button note = button("Add note", 12);
        Button export = button("Export annotated", 12);
        pdfPageText = label("Page 1", 12, false);
        controls.addView(prev);
        controls.addView(next);
        controls.addView(pdfPageText, new LinearLayout.LayoutParams(0, dp(42), 1f));
        controls.addView(note);
        controls.addView(export);
        prev.setOnClickListener(v -> changePdfPage(-1));
        next.setOnClickListener(v -> changePdfPage(1));
        note.setOnClickListener(v -> editPdfNote());
        export.setOnClickListener(v -> beginSaveAnnotatedPdf());
        pdfPanel.addView(controls, lpMatch(dp(46)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        holder.setGravity(Gravity.CENTER_HORIZONTAL);
        pdfImage = new ImageView(this);
        pdfImage.setAdjustViewBounds(true);
        pdfImage.setBackgroundColor(Color.WHITE);
        holder.addView(pdfImage, new LinearLayout.LayoutParams(dp(720), ViewGroup.LayoutParams.WRAP_CONTENT));
        pdfNoteText = label("", 13, false);
        pdfNoteText.setPadding(dp(20), dp(14), dp(20), dp(14));
        holder.addView(pdfNoteText, lpMatch(ViewGroup.LayoutParams.WRAP_CONTENT));
        scroll.addView(holder);
        pdfPanel.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        workspace.addView(pdfPanel, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private View buildStatusBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), 0, dp(10), 0);
        bar.setBackgroundColor(Color.WHITE);
        statusText = label("Page 1 of 1  •  0 words", 11, false);
        zoomText = label("100%", 11, false);
        Button minus = button("−", 12);
        Button plus = button("+", 12);
        minus.setOnClickListener(v -> setZoom(zoomPercent - 10));
        plus.setOnClickListener(v -> setZoom(zoomPercent + 10));
        bar.addView(statusText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        bar.addView(minus, new LinearLayout.LayoutParams(dp(38), dp(30)));
        bar.addView(zoomText, new LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.MATCH_PARENT));
        bar.addView(plus, new LinearLayout.LayoutParams(dp(38), dp(30)));
        return bar;
    }

    private void installSafeInsets() {
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int left, top, right, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                left = bars.left; top = bars.top; right = bars.right; bottom = bars.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft(); top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight(); bottom = insets.getSystemWindowInsetBottom();
            }
            int extra = dp(5);
            v.setPadding(left + extra, top + extra, right + extra, bottom + extra);
            return insets;
        });
        root.requestApplyInsets();
    }

    private void newDocument() {
        captureCurrentDocument();
        DocumentModel d = new DocumentModel(nextDocId++, "Untitled " + untitledCount++);
        d.content.append("");
        docs.add(d);
        rebuildTabs();
        selectDoc(docs.size() - 1);
    }

    private void rebuildTabs() {
        while (tabRow.getChildCount() > 1) tabRow.removeViewAt(1);
        for (int i = 0; i < docs.size(); i++) {
            final int index = i;
            DocumentModel d = docs.get(i);
            LinearLayout tab = new LinearLayout(this);
            tab.setGravity(Gravity.CENTER_VERTICAL);
            tab.setPadding(dp(10), 0, dp(4), 0);
            tab.setBackground(rounded(i == activeIndex ? Color.WHITE : Color.rgb(235, 238, 242), Color.TRANSPARENT, 7, 0));
            TextView name = label((d.dirty ? "● " : "") + d.title, 12, i == activeIndex);
            name.setSingleLine(true);
            tab.addView(name, new LinearLayout.LayoutParams(dp(154), dp(38)));
            TextView close = label("×", 18, false);
            close.setGravity(Gravity.CENTER);
            close.setOnClickListener(v -> closeDocument(index));
            tab.addView(close, new LinearLayout.LayoutParams(dp(28), dp(38)));
            tab.setOnClickListener(v -> selectDoc(index));
            tabRow.addView(tab, new LinearLayout.LayoutParams(dp(192), dp(38)));
        }
    }

    private void selectDoc(int index) {
        if (index < 0 || index >= docs.size()) return;
        captureCurrentDocument();
        closePdf();
        activeIndex = index;
        DocumentModel d = docs.get(index);
        switchingDoc = true;
        if (d.kind == DocumentModel.Kind.PDF) {
            docHorizontal.setVisibility(View.GONE);
            ruler.setVisibility(View.GONE);
            pdfPanel.setVisibility(View.VISIBLE);
            openPdf(d.uri);
            pdfNoteText.setText(d.pdfNote);
        } else {
            pdfPanel.setVisibility(View.GONE);
            docHorizontal.setVisibility(View.VISIBLE);
            ruler.setVisibility(View.VISIBLE);
            editor.setText(new SpannableStringBuilder(d.content));
            int max = editor.length();
            editor.setSelection(Math.min(d.selectionStart, max), Math.min(d.selectionEnd, max));
            ruler.setMarginsDp(d.leftMarginDp, d.rightMarginDp);
            applyEditorMargins(d);
        }
        switchingDoc = false;
        rebuildTabs();
        refreshStatus();
    }

    private void captureCurrentDocument() {
        DocumentModel d = currentDoc();
        if (d == null) return;
        if (d.kind == DocumentModel.Kind.DOCUMENT && editor != null) {
            d.content = new SpannableStringBuilder(editor.getText());
            d.selectionStart = Math.max(0, editor.getSelectionStart());
            d.selectionEnd = Math.max(0, editor.getSelectionEnd());
        }
    }

    private void closeDocument(int index) {
        if (index < 0 || index >= docs.size()) return;
        DocumentModel d = docs.get(index);
        if (d.dirty) {
            new AlertDialog.Builder(this).setTitle("Close " + d.title + "?")
                    .setMessage("This document has unsaved changes.")
                    .setPositiveButton("Close anyway", (x, w) -> removeDoc(index))
                    .setNegativeButton("Cancel", null).show();
        } else removeDoc(index);
    }

    private void removeDoc(int index) {
        if (index == activeIndex) captureCurrentDocument();
        DocumentModel removed = docs.get(index);
        deleteRecovery(removed);
        docs.remove(index);
        if (docs.isEmpty()) { activeIndex = -1; newDocument(); return; }
        activeIndex = Math.min(index, docs.size() - 1);
        rebuildTabs();
        selectDoc(activeIndex);
    }

    private DocumentModel currentDoc() {
        return activeIndex >= 0 && activeIndex < docs.size() ? docs.get(activeIndex) : null;
    }

    private void showRibbon(String name) {
        activeRibbon = name;
        ribbonPanel.removeAllViews();
        if ("File".equals(name)) {
            addRibbonAction("New", v -> newDocument());
            addRibbonAction("Open", v -> chooseOpen());
            addRibbonAction("Save", v -> saveCurrent());
            addRibbonAction("Save as DOCX", v -> beginSaveDocx());
            addRibbonAction("Export PDF", v -> beginSavePdf());
            addRibbonAction("Print", v -> printDocument());
        } else if ("Home".equals(name)) {
            addRibbonAction("B", v -> applyStyle(Typeface.BOLD));
            addRibbonAction("I", v -> applyStyle(Typeface.ITALIC));
            addRibbonAction("U", v -> applyUnderline());
            addRibbonAction("Text color", v -> showTextColorPicker(false));
            addRibbonAction("Highlight", v -> showTextColorPicker(true));
            addRibbonAction("Font", v -> showFontPicker());
            addRibbonAction("Size", v -> showFontSizePicker());
            addRibbonAction("Left", v -> align(Layout.Alignment.ALIGN_NORMAL));
            addRibbonAction("Center", v -> align(Layout.Alignment.ALIGN_CENTER));
            addRibbonAction("Right", v -> align(Layout.Alignment.ALIGN_OPPOSITE));
            addRibbonAction("• List", v -> insertBullet());
        } else if ("Insert".equals(name)) {
            addRibbonAction("Table", v -> insertTable());
            addRibbonAction("Image", v -> pickImage("image"));
            addRibbonAction("Image frame", v -> pickFrameType());
            addRibbonAction("Shape", v -> insertShapeDialog());
            addRibbonAction("Text box", v -> insertTextBoxLike());
            addRibbonAction("Link", v -> insertLinkText());
            addRibbonAction("Page break", v -> insertPageBreak());
        } else if ("Design".equals(name)) {
            addRibbonAction("Theme color", v -> showThemeColors());
            addRibbonAction("Document style", v -> showDocumentStyles());
            addRibbonAction("Page color", v -> showPageColors());
        } else if ("Layout".equals(name)) {
            addRibbonAction("Margins", v -> showMarginDialog());
            addRibbonAction("A4", v -> setPageRatio(794, 1123));
            addRibbonAction("Letter", v -> setPageRatio(816, 1056));
            addRibbonAction("Portrait", v -> setPortrait(true));
            addRibbonAction("Landscape", v -> setPortrait(false));
            addRibbonAction("Ruler", v -> ruler.setVisibility(ruler.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        } else if ("References".equals(name)) {
            addRibbonAction("Heading 1", v -> applyHeading(1));
            addRibbonAction("Heading 2", v -> applyHeading(2));
            addRibbonAction("Heading 3", v -> applyHeading(3));
            addRibbonAction("Table of contents", v -> insertToc());
            addRibbonAction("Footnote", v -> insertFootnote());
        } else if ("Review".equals(name)) {
            addRibbonAction("Find", v -> showFindReplace(false));
            addRibbonAction("Replace", v -> showFindReplace(true));
            addRibbonAction("Word count", v -> showWordCount());
            addRibbonAction("Formatting marks", v -> toggleFormattingMarksHint());
        } else if ("View".equals(name)) {
            addRibbonAction("Focus", v -> toggleFocusMode());
            addRibbonAction("Light / Dark", v -> toggleChromeTheme());
            addRibbonAction("Page width", v -> setZoom(85));
            addRibbonAction("100%", v -> setZoom(100));
        }
        refreshRibbonSelection();
    }

    private void refreshRibbonSelection() {
        for (int i = 0; i < ribbonTabs.getChildCount(); i++) {
            TextView t = (TextView) ribbonTabs.getChildAt(i);
            boolean selected = activeRibbon.contentEquals(t.getText());
            t.setTextColor(selected ? currentAccent : Color.rgb(72, 78, 88));
            t.setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    private void addRibbonAction(String text, View.OnClickListener click) {
        Button b = button(text, 11);
        b.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46));
        p.setMargins(dp(3), 0, dp(3), 0);
        ribbonPanel.addView(b, p);
    }

    private void applyStyle(int style) {
        if (!ensureDocument()) return;
        int[] r = selectionRange();
        if (r[0] == r[1]) { toast("Select text first"); return; }
        editor.getText().setSpan(new StyleSpan(style), r[0], r[1], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        markDirty();
    }

    private void applyUnderline() {
        if (!ensureDocument()) return;
        int[] r = selectionRange();
        if (r[0] == r[1]) { toast("Select text first"); return; }
        editor.getText().setSpan(new UnderlineSpan(), r[0], r[1], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        markDirty();
    }

    private void showTextColorPicker(boolean highlight) {
        final int[] colors = {Color.BLACK, Color.rgb(23,105,232), Color.rgb(20,130,90), Color.rgb(180,45,45), Color.rgb(120,65,175), Color.rgb(235,130,20), Color.rgb(255,230,90), Color.LTGRAY};
        String[] names = {"Black", "Blue", "Green", "Red", "Purple", "Orange", "Yellow", "Light gray"};
        new AlertDialog.Builder(this).setTitle(highlight ? "Highlight" : "Text color").setItems(names, (d, which) -> {
            int[] r = selectionRange();
            if (r[0] == r[1]) { toast("Select text first"); return; }
            CharacterStyle span = highlight ? new BackgroundColorSpan(colors[which]) : new ForegroundColorSpan(colors[which]);
            editor.getText().setSpan(span, r[0], r[1], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            markDirty();
        }).show();
    }

    private void showFontSizePicker() {
        String[] sizes = {"8", "9", "10", "11", "12", "14", "16", "18", "20", "24", "28", "32", "36", "48", "60", "72"};
        new AlertDialog.Builder(this).setTitle("Font size").setItems(sizes, (d, i) -> {
            int[] r = selectionRange();
            if (r[0] == r[1]) { toast("Select text first"); return; }
            editor.getText().setSpan(new AbsoluteSizeSpan(Integer.parseInt(sizes[i]), true), r[0], r[1], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            markDirty();
        }).show();
    }

    private void showFontPicker() {
        ArrayList<String> names = new ArrayList<>(Arrays.asList("System Sans", "Serif", "Monospace"));
        File fontsDir = new File(getFilesDir(), "fonts");
        if (fontsDir.exists()) {
            File[] files = fontsDir.listFiles();
            if (files != null) for (File f : files) if (f.getName().endsWith(".ttf")) names.add("Downloaded: " + f.getName().replace(".ttf", ""));
        }
        names.add("Download Google Font…");
        new AlertDialog.Builder(this).setTitle("Fonts").setItems(names.toArray(new String[0]), (d, i) -> {
            String n = names.get(i);
            if ("Download Google Font…".equals(n)) { showGoogleFontDownload(); return; }
            if (n.startsWith("Downloaded: ")) {
                File f = new File(fontsDir, n.substring("Downloaded: ".length()) + ".ttf");
                applyCustomTypeface(Typeface.createFromFile(f));
            } else {
                String family = "System Sans".equals(n) ? "sans" : n.toLowerCase(Locale.US);
                applyCustomTypeface(Typeface.create(family, Typeface.NORMAL));
            }
        }).show();
    }

    private void showGoogleFontDownload() {
        String[] names = googleFonts.keySet().toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Google Fonts").setMessage("Fonts are downloaded on demand and then work offline.")
                .setItems(names, (d, i) -> downloadFont(names[i], googleFonts.get(names[i]))).show();
    }

    private void downloadFont(String name, String url) {
        toast("Downloading " + name + "…");
        ioExecutor.submit(() -> {
            try {
                File dir = new File(getFilesDir(), "fonts");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create font folder");
                File out = new File(dir, name.replace(" ", "_") + ".ttf");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setInstanceFollowRedirects(true);
                try (InputStream in = c.getInputStream(); FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) fos.write(b, 0, n);
                }
                Typeface tf = Typeface.createFromFile(out);
                runOnUiThread(() -> { toast(name + " downloaded"); applyCustomTypeface(tf); });
            } catch (Exception e) { runOnUiThread(() -> toast("Font download failed: " + e.getMessage())); }
        });
    }

    private void applyCustomTypeface(Typeface tf) {
        if (!ensureDocument()) return;
        int[] r = selectionRange();
        if (r[0] == r[1]) { editor.setTypeface(tf); return; }
        editor.getText().setSpan(new CustomTypefaceSpan(tf), r[0], r[1], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        markDirty();
    }

    private void align(Layout.Alignment alignment) {
        if (!ensureDocument()) return;
        int[] p = paragraphRange();
        editor.getText().setSpan(new AlignmentSpan.Standard(alignment), p[0], p[1], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        markDirty();
    }

    private void insertBullet() {
        if (!ensureDocument()) return;
        int pos = Math.max(0, editor.getSelectionStart());
        editor.getText().insert(pos, "• ");
    }

    private void insertTable() {
        if (!ensureDocument()) return;
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); box.setPadding(dp(20),0,dp(20),0);
        NumberPicker rows = new NumberPicker(this); rows.setMinValue(1); rows.setMaxValue(10); rows.setValue(3);
        NumberPicker cols = new NumberPicker(this); cols.setMinValue(1); cols.setMaxValue(8); cols.setValue(3);
        box.addView(rows, new LinearLayout.LayoutParams(0, dp(130), 1f)); box.addView(cols, new LinearLayout.LayoutParams(0, dp(130), 1f));
        new AlertDialog.Builder(this).setTitle("Insert table — rows / columns").setView(box).setPositiveButton("Insert", (d,w)-> {
            StringBuilder s = new StringBuilder();
            int start = editor.getSelectionStart();
            for (int r=0;r<rows.getValue();r++) { for (int c=0;c<cols.getValue();c++) { if (c>0) s.append("\t"); s.append("Cell ").append(r+1).append('.').append(c+1); } s.append('\n'); }
            editor.getText().insert(start, s.toString());
            editor.getText().setSpan(new CustomTypefaceSpan(Typeface.MONOSPACE), start, start+s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }).setNegativeButton("Cancel",null).show();
    }

    private void pickImage(String mode) {
        pendingImageMode = mode;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, REQ_IMAGE);
    }

    private void pickFrameType() {
        String[] items = {"Rounded rectangle", "Circle", "Square"};
        new AlertDialog.Builder(this).setTitle("Image frame").setItems(items, (d,i) -> pickImage(i==1 ? "circle" : (i==2 ? "square" : "rounded"))).show();
    }

    private void insertPickedImage(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            Bitmap raw = android.graphics.BitmapFactory.decodeStream(in);
            if (raw == null) throw new Exception("Unsupported image");
            Bitmap bmp = prepareImage(raw, pendingImageMode);
            int pos = Math.max(0, editor.getSelectionStart());
            editor.getText().insert(pos, "\uFFFC\n");
            editor.getText().setSpan(new ImageSpan(this, bmp, ImageSpan.ALIGN_BOTTOM), pos, pos+1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            markDirty();
        } catch (Exception e) { toast("Could not insert image: " + e.getMessage()); }
    }

    private Bitmap prepareImage(Bitmap raw, String mode) {
        int maxW = dp(520);
        float scale = Math.min(1f, maxW / (float) raw.getWidth());
        int w = Math.max(1, Math.round(raw.getWidth()*scale));
        int h = Math.max(1, Math.round(raw.getHeight()*scale));
        Bitmap scaled = Bitmap.createScaledBitmap(raw, w, h, true);
        if ("image".equals(mode)) return scaled;
        int size = "circle".equals(mode) || "square".equals(mode) ? Math.min(w,h) : w;
        int outH = "circle".equals(mode) || "square".equals(mode) ? size : h;
        Bitmap out = Bitmap.createBitmap(size, outH, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Path path = new Path(); RectF r = new RectF(0,0,size,outH);
        if ("circle".equals(mode)) path.addOval(r, Path.Direction.CW); else if ("rounded".equals(mode)) path.addRoundRect(r, dp(28), dp(28), Path.Direction.CW); else path.addRect(r, Path.Direction.CW);
        c.clipPath(path);
        Matrix m = new Matrix();
        float s = Math.max(size/(float)scaled.getWidth(), outH/(float)scaled.getHeight());
        m.setScale(s,s); m.postTranslate((size-scaled.getWidth()*s)/2f,(outH-scaled.getHeight()*s)/2f);
        c.drawBitmap(scaled,m,p);
        return out;
    }

    private void insertShapeDialog() {
        String[] items = {"Rectangle", "Rounded rectangle", "Circle", "Line"};
        new AlertDialog.Builder(this).setTitle("Insert shape").setItems(items, (d,i) -> insertShape(items[i])).show();
    }

    private void insertShape(String type) {
        if (!ensureDocument()) return;
        int w = dp(220), h = "Line".equals(type) ? dp(22) : dp(120);
        Bitmap b = Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); Canvas c = new Canvas(b); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(currentAccent); p.setStyle(Paint.Style.FILL);
        if ("Circle".equals(type)) c.drawOval(new RectF(dp(50),0,w-dp(50),h),p);
        else if ("Rounded rectangle".equals(type)) c.drawRoundRect(new RectF(0,0,w,h),dp(22),dp(22),p);
        else if ("Line".equals(type)) { p.setStrokeWidth(dp(3)); c.drawLine(0,h/2f,w,h/2f,p); }
        else c.drawRect(0,0,w,h,p);
        int pos = editor.getSelectionStart(); editor.getText().insert(pos,"\uFFFC\n"); editor.getText().setSpan(new ImageSpan(this,b),pos,pos+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void insertTextBoxLike() {
        if (!ensureDocument()) return;
        int pos = editor.getSelectionStart(); String text = "[Text box — type here]";
        editor.getText().insert(pos, text);
        editor.getText().setSpan(new BackgroundColorSpan(0xFFEFF4FF), pos, pos+text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        editor.getText().setSpan(new ForegroundColorSpan(currentAccent), pos, pos+text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        editor.setSelection(pos+1, pos+text.length()-1);
    }

    private void insertLinkText() {
        if (!ensureDocument()) return;
        EditText input = new EditText(this); input.setHint("https://example.com");
        new AlertDialog.Builder(this).setTitle("Insert link").setView(input).setPositiveButton("Insert",(d,w)-> {
            int pos=editor.getSelectionStart(); String s=input.getText().toString().trim(); editor.getText().insert(pos,s);
            editor.getText().setSpan(new ForegroundColorSpan(currentAccent),pos,pos+s.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            editor.getText().setSpan(new UnderlineSpan(),pos,pos+s.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }).setNegativeButton("Cancel",null).show();
    }

    private void insertPageBreak() { if (ensureDocument()) editor.getText().insert(editor.getSelectionStart(), "\n──────── PAGE BREAK ────────\n"); }

    private void showThemeColors() {
        final int[] colors = {0xFF1769E8,0xFF0B5B9A,0xFF0B7D65,0xFF6A43B5,0xFFB23A48,0xFFCB6D17,0xFF222222,0xFF00838F};
        String[] names={"Wordroid Blue","Navy","Teal","Purple","Burgundy","Orange","Graphite","Cyan","Custom HEX…"};
        new AlertDialog.Builder(this).setTitle("Interface accent").setItems(names,(d,i)->{
            if(i<colors.length){currentAccent=colors[i];showRibbon(activeRibbon);refreshRibbonSelection();}
            else showCustomAccent();
        }).show();
    }

    private void showCustomAccent(){
        EditText input=new EditText(this);input.setHint("#1769E8");input.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Custom accent color").setView(input).setPositiveButton("Apply",(d,w)->{
            try{String value=input.getText().toString().trim();if(!value.startsWith("#"))value="#"+value;currentAccent=Color.parseColor(value);showRibbon(activeRibbon);refreshRibbonSelection();}
            catch(Exception e){toast("Enter a valid HEX color, e.g. #1769E8");}
        }).setNegativeButton("Cancel",null).show();
    }

    private void showDocumentStyles() {
        String[] names={"Minimal","Academic","Corporate","Editorial","Modern","Classic"};
        new AlertDialog.Builder(this).setTitle("Document style").setItems(names,(d,i)->{
            if (!ensureDocument()) return;
            if (i==1) { editor.setTypeface(Typeface.SERIF); editor.setTextSize(12); editor.setLineSpacing(0,1.35f); }
            else if (i==2) { editor.setTypeface(Typeface.create("sans",Typeface.NORMAL)); editor.setTextSize(11); editor.setLineSpacing(0,1.2f); }
            else if (i==3) { editor.setTypeface(Typeface.SERIF); editor.setTextSize(12); editor.setLineSpacing(0,1.5f); }
            else { editor.setTypeface(Typeface.create("sans",Typeface.NORMAL)); editor.setTextSize(12); editor.setLineSpacing(0,1.28f); }
            markDirty();
        }).show();
    }

    private void showPageColors() {
        final int[] colors={Color.WHITE,0xFFFFFCF4,0xFFF7FAFC,0xFFF5F8F2,0xFFF9F3F3,0xFFF4F3F9};
        String[] names={"White","Warm ivory","Cool gray","Soft sage","Soft rose","Soft lavender"};
        new AlertDialog.Builder(this).setTitle("Page color").setItems(names,(d,i)->page.setBackground(rounded(colors[i],Color.rgb(209,214,221),0,1))).show();
    }

    private void showMarginDialog() {
        String[] names={"Normal — 1 in","Narrow — 0.5 in","Moderate — 0.75 in","Wide — 1.5 in"};
        float[] vals={72f,36f,54f,108f};
        new AlertDialog.Builder(this).setTitle("Margins").setItems(names,(d,i)->{
            DocumentModel m=currentDoc(); if(m==null)return; m.leftMarginDp=vals[i];m.rightMarginDp=vals[i];ruler.setMarginsDp(vals[i],vals[i]);applyEditorMargins(m);markDirty();
        }).show();
    }

    private void setPageRatio(int widthDp, int heightDp) {
        LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)page.getLayoutParams(); p.width=dp(widthDp);p.height=dp(heightDp);page.setLayoutParams(p);
    }
    private void setPortrait(boolean portrait) { setPageRatio(portrait?794:1123,portrait?1123:794); }

    private void applyHeading(int level) {
        if (!ensureDocument()) return;
        int[] r=paragraphRange(); Editable e=editor.getText();
        HeadingSpan[] old=e.getSpans(r[0],r[1],HeadingSpan.class); for(HeadingSpan h:old)e.removeSpan(h);
        e.setSpan(new HeadingSpan(level),r[0],r[1],Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        e.setSpan(new StyleSpan(Typeface.BOLD),r[0],r[1],Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        e.setSpan(new AbsoluteSizeSpan(level==1?20:(level==2?16:14),true),r[0],r[1],Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        markDirty();
    }

    private void insertToc() {
        if (!ensureDocument()) return;
        Spannable e=editor.getText(); HeadingSpan[] hs=e.getSpans(0,e.length(),HeadingSpan.class);
        if(hs.length==0){toast("Apply Heading 1–3 styles first");return;}
        Arrays.sort(hs,(a,b)->Integer.compare(e.getSpanStart(a),e.getSpanStart(b)));
        StringBuilder toc=new StringBuilder("Table of Contents\n\n");
        for(HeadingSpan h:hs){int s=e.getSpanStart(h),en=e.getSpanEnd(h);String t=e.subSequence(s,en).toString().trim();for(int i=1;i<h.level;i++)toc.append("    ");toc.append(t).append("  ................................\n");}
        toc.append('\n');
        int pos=editor.getSelectionStart();editor.getText().insert(pos,toc.toString());editor.getText().setSpan(new StyleSpan(Typeface.BOLD),pos,pos+"Table of Contents".length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void insertFootnote() {
        if(!ensureDocument())return;int pos=editor.getSelectionStart();String marker="[1]";editor.getText().insert(pos,marker);editor.getText().setSpan(new AbsoluteSizeSpan(8,true),pos,pos+marker.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void showFindReplace(boolean replaceMode) {
        if(!ensureDocument())return;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),0,dp(22),0);
        EditText find=new EditText(this);find.setHint("Find");box.addView(find);
        EditText repl=new EditText(this);repl.setHint("Replace with");if(replaceMode)box.addView(repl);
        CheckBox match=new CheckBox(this);match.setText("Match case");box.addView(match);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(replaceMode?"Find and replace":"Find").setView(box)
                .setPositiveButton(replaceMode?"Replace all":"Find next",null).setNeutralButton(replaceMode?"Replace one":"Previous",null).setNegativeButton("Close",null).create();
        dialog.setOnShowListener(x->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{ if(replaceMode) replaceAll(find.getText().toString(),repl.getText().toString(),match.isChecked()); else findNext(find.getText().toString(),match.isChecked(),true); });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{ if(replaceMode) replaceOne(find.getText().toString(),repl.getText().toString(),match.isChecked()); else findNext(find.getText().toString(),match.isChecked(),false); });
        });dialog.show();
    }

    private void findNext(String query, boolean matchCase, boolean forward) {
        if(query.isEmpty())return;String text=editor.getText().toString();String hay=matchCase?text:text.toLowerCase(Locale.ROOT);String needle=matchCase?query:query.toLowerCase(Locale.ROOT);
        int pos=forward?Math.max(editor.getSelectionEnd(),0):Math.max(editor.getSelectionStart()-1,0);int found=forward?hay.indexOf(needle,pos):hay.lastIndexOf(needle,pos);
        if(found<0)found=forward?hay.indexOf(needle):hay.lastIndexOf(needle);if(found>=0){editor.requestFocus();editor.setSelection(found,found+query.length());}else toast("No matches");
    }

    private void replaceOne(String find,String repl,boolean matchCase){ if(find.isEmpty())return;int s=editor.getSelectionStart(),e=editor.getSelectionEnd();String selected=s>=0&&e>s?editor.getText().subSequence(s,e).toString():"";if((matchCase&&selected.equals(find))||(!matchCase&&selected.equalsIgnoreCase(find))){editor.getText().replace(s,e,repl);}else findNext(find,matchCase,true); }
    private void replaceAll(String find,String repl,boolean matchCase){ if(find.isEmpty())return;String original=editor.getText().toString();String hay=matchCase?original:original.toLowerCase(Locale.ROOT);String needle=matchCase?find:find.toLowerCase(Locale.ROOT);StringBuilder out=new StringBuilder();int p=0,count=0,idx;while((idx=hay.indexOf(needle,p))>=0){out.append(original,p,idx).append(repl);p=idx+find.length();count++;}out.append(original.substring(p));if(count>0)editor.setText(out.toString());toast(count+" replacement"+(count==1?"":"s")); }

    private void showWordCount(){String s=editor.getText().toString().trim();int words=s.isEmpty()?0:s.split("\\s+").length;int chars=editor.length();new AlertDialog.Builder(this).setTitle("Document statistics").setMessage(words+" words\n"+chars+" characters\n"+Math.max(1,(chars/1800)+1)+" estimated pages").setPositiveButton("OK",null).show();}
    private void toggleFormattingMarksHint(){toast("Formatting marks: paragraph and page-break markers are shown when inserted.");}

    private void toggleFocusMode(){int vis=ribbonTabs.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE;ribbonTabs.setVisibility(vis);ribbonScroll.setVisibility(vis);if(vis==View.GONE)toast("Focus mode — tap View after leaving focus with Back");}
    private void toggleChromeTheme(){darkChrome=!darkChrome;int chrome=darkChrome?0xFF17191D:Color.WHITE;int bg=darkChrome?0xFF262A30:0xFFE2E6EB;root.setBackgroundColor(chrome);workspace.setBackgroundColor(bg);getWindow().setStatusBarColor(chrome);getWindow().setNavigationBarColor(chrome);if(Build.VERSION.SDK_INT>=26)getWindow().getDecorView().setSystemUiVisibility(darkChrome?0:(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));else if(Build.VERSION.SDK_INT>=23)getWindow().getDecorView().setSystemUiVisibility(darkChrome?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);}

    private void chooseOpen(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/pdf","text/plain","text/markdown"});startActivityForResult(i,REQ_OPEN);}

    private void openUri(Uri uri,String mime){
        if(uri==null)return;String type=mime;if(type==null)type=getContentResolver().getType(uri);final String resolvedType=type;String name=queryName(uri);
        if("application/pdf".equals(resolvedType)||name.toLowerCase(Locale.ROOT).endsWith(".pdf")){captureCurrentDocument();docs.add(DocumentModel.pdf(nextDocId++,name,uri));selectDoc(docs.size()-1);return;}
        ioExecutor.submit(()->{try{String text;if(name.toLowerCase(Locale.ROOT).endsWith(".docx")||"application/vnd.openxmlformats-officedocument.wordprocessingml.document".equals(resolvedType)){text=DocxUtil.readDocx(getContentResolver(),uri);}else{text=readText(uri);}String finalText=text;runOnUiThread(()->{captureCurrentDocument();DocumentModel d=new DocumentModel(nextDocId++,name);d.uri=uri;d.content.append(finalText);d.dirty=false;docs.add(d);selectDoc(docs.size()-1);});}catch(Exception e){runOnUiThread(()->toast("Open failed: "+e.getMessage()));}});
    }

    private String readText(Uri uri)throws Exception{try(InputStream in=getContentResolver().openInputStream(uri)){byte[] b=new byte[8192];int n;java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();while((n=in.read(b))>0)out.write(b,0,n);return out.toString("UTF-8");}}

    private void saveCurrent(){DocumentModel d=currentDoc();if(d==null)return;if(d.kind==DocumentModel.Kind.PDF){beginSaveAnnotatedPdf();return;}beginSaveDocx();}
    private void beginSaveDocx(){if(!ensureDocument())return;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");String n=currentDoc().title;i.putExtra(Intent.EXTRA_TITLE,n.toLowerCase(Locale.ROOT).endsWith(".docx")?n:n+".docx");startActivityForResult(i,REQ_SAVE_DOCX);}
    private void beginSavePdf(){if(!ensureDocument())return;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");String n=currentDoc().title.replaceAll("(?i)\\.docx$","");i.putExtra(Intent.EXTRA_TITLE,n+".pdf");startActivityForResult(i,REQ_SAVE_PDF);}
    private void beginSaveAnnotatedPdf(){DocumentModel d=currentDoc();if(d==null||d.kind!=DocumentModel.Kind.PDF)return;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,d.title.replaceAll("(?i)\\.pdf$","")+"-annotated.pdf");startActivityForResult(i,REQ_PDF_ANNOTATED);}

    private void saveDocx(Uri uri){captureCurrentDocument();DocumentModel d=currentDoc();ioExecutor.submit(()->{try{DocxUtil.writeDocx(getContentResolver(),uri,d.content);runOnUiThread(()->{d.uri=uri;d.dirty=false;d.title=queryName(uri);deleteRecovery(d);rebuildTabs();toast("DOCX saved");});}catch(Exception e){runOnUiThread(()->toast("Save failed: "+e.getMessage()));}});}

    private void exportPdf(Uri uri){captureCurrentDocument();final String text=currentDoc().content.toString();ioExecutor.submit(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){PdfDocument pdf=new PdfDocument();Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.rgb(25,28,32));paint.setTextSize(12*getResources().getDisplayMetrics().scaledDensity);TextPaint tp=new TextPaint(paint);int pageW=595,pageH=842,margin=54,contentW=pageW-margin*2;StaticLayout all=new StaticLayout(text,tp,contentW,Layout.Alignment.ALIGN_NORMAL,1.25f,0,false);int yOffset=0,pageNo=1;while(yOffset<all.getHeight()||pageNo==1){PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create();PdfDocument.Page p=pdf.startPage(info);Canvas c=p.getCanvas();c.drawColor(Color.WHITE);c.save();c.translate(margin,margin-yOffset);all.draw(c);c.restore();pdf.finishPage(p);yOffset+=pageH-margin*2;pageNo++;}pdf.writeTo(out);pdf.close();runOnUiThread(()->toast("PDF exported"));}catch(Exception e){runOnUiThread(()->toast("PDF export failed: "+e.getMessage()));}});}

    private void printDocument(){
        if(!ensureDocument())return;
        captureCurrentDocument();
        DocumentModel d=currentDoc();
        String html="<html><head><meta charset=\"utf-8\"><style>@page{margin:1in}body{font-family:sans-serif;font-size:12pt;line-height:1.35;white-space:pre-wrap;color:#181c21}</style></head><body>"+TextUtils.htmlEncode(d.content.toString())+"</body></html>";
        WebView web=new WebView(this);
        web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){
            PrintManager manager=(PrintManager)getSystemService(PRINT_SERVICE);
            String jobName="Wordroid - "+d.title;
            manager.print(jobName,view.createPrintDocumentAdapter(d.title),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
        }});
        web.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);
    }

    private void openPdf(Uri uri){try{pdfFd=getContentResolver().openFileDescriptor(uri,"r");if(pdfFd==null)throw new Exception("Cannot open PDF");pdfRenderer=new PdfRenderer(pdfFd);pdfPageIndex=0;renderPdfPage();}catch(Exception e){toast("PDF open failed: "+e.getMessage());}}
    private void renderPdfPage(){if(pdfRenderer==null||pdfRenderer.getPageCount()==0)return;pdfPageIndex=Math.max(0,Math.min(pdfPageIndex,pdfRenderer.getPageCount()-1));try(PdfRenderer.Page p=pdfRenderer.openPage(pdfPageIndex)){int width=Math.min(1600,Math.max(720,p.getWidth()*2));int height=Math.round(width*(p.getHeight()/(float)p.getWidth()));Bitmap b=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);pdfImage.setImageBitmap(b);}pdfPageText.setText("Page "+(pdfPageIndex+1)+" of "+pdfRenderer.getPageCount());}
    private void changePdfPage(int delta){if(pdfRenderer==null)return;pdfPageIndex=Math.max(0,Math.min(pdfRenderer.getPageCount()-1,pdfPageIndex+delta));renderPdfPage();}
    private void editPdfNote(){DocumentModel d=currentDoc();if(d==null)return;EditText input=new EditText(this);input.setText(d.pdfNote);input.setHint("Annotation note");new AlertDialog.Builder(this).setTitle("PDF note").setView(input).setPositiveButton("Save",(x,w)->{d.pdfNote=input.getText().toString();d.dirty=true;pdfNoteText.setText(d.pdfNote);rebuildTabs();}).setNegativeButton("Cancel",null).show();}

    private void exportAnnotatedPdf(Uri outUri){DocumentModel d=currentDoc();if(d==null||d.kind!=DocumentModel.Kind.PDF||d.uri==null)return;ioExecutor.submit(()->{try(ParcelFileDescriptor fd=getContentResolver().openFileDescriptor(d.uri,"r");PdfRenderer r=new PdfRenderer(fd);OutputStream out=getContentResolver().openOutputStream(outUri,"w")){PdfDocument pdf=new PdfDocument();for(int i=0;i<r.getPageCount();i++){try(PdfRenderer.Page src=r.openPage(i)){int w=src.getWidth(),h=src.getHeight();Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);src.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT);PdfDocument.Page p=pdf.startPage(new PdfDocument.PageInfo.Builder(w,h,i+1).create());p.getCanvas().drawBitmap(b,0,0,null);if(i==pdfPageIndex&&!d.pdfNote.trim().isEmpty()){Paint box=new Paint(Paint.ANTI_ALIAS_FLAG);box.setColor(0xEFFFF7C7);p.getCanvas().drawRect(24,h-100,w-24,h-24,box);Paint txt=new Paint(Paint.ANTI_ALIAS_FLAG);txt.setColor(Color.DKGRAY);txt.setTextSize(18);p.getCanvas().drawText(d.pdfNote.substring(0,Math.min(d.pdfNote.length(),120)),36,h-58,txt);}pdf.finishPage(p);b.recycle();}}pdf.writeTo(out);pdf.close();r.close();runOnUiThread(()->toast("Annotated PDF exported"));}catch(Exception e){runOnUiThread(()->toast("PDF save failed: "+e.getMessage()));}});}

    private void closePdf(){try{if(pdfRenderer!=null)pdfRenderer.close();}catch(Exception ignored){}try{if(pdfFd!=null)pdfFd.close();}catch(Exception ignored){}pdfRenderer=null;pdfFd=null;}

    private void showFileMenu(){String[] items={"New document","Open…","Save as DOCX","Export PDF","Print","Find / Replace","Close tab"};new AlertDialog.Builder(this).setTitle("Wordroid").setItems(items,(d,i)->{if(i==0)newDocument();else if(i==1)chooseOpen();else if(i==2)beginSaveDocx();else if(i==3)beginSavePdf();else if(i==4)printDocument();else if(i==5)showFindReplace(true);else if(i==6)closeDocument(activeIndex);}).show();}

    private void applyEditorMargins(DocumentModel d){int top=dp(72),bottom=dp(72);editor.setPadding(dp((int)d.leftMarginDp),top,dp((int)d.rightMarginDp),bottom);}

    private void markDirty(){DocumentModel d=currentDoc();if(d==null||switchingDoc)return;d.dirty=true;rebuildTabs();}
    private void refreshStatus(){DocumentModel d=currentDoc();if(d==null)return;if(d.kind==DocumentModel.Kind.PDF){statusText.setText("PDF document");return;}String s=editor.getText().toString().trim();int words=s.isEmpty()?0:s.split("\\s+").length;int pages=Math.max(1,(editor.length()/1800)+1);statusText.setText("Page 1 of "+pages+"  •  "+words+" words  •  "+editor.length()+" characters");zoomText.setText(zoomPercent+"%");}
    private void setZoom(int z){zoomPercent=Math.max(50,Math.min(200,z));float scale=zoomPercent/100f;page.setScaleX(scale);page.setScaleY(scale);page.setPivotX(page.getWidth()/2f);page.setPivotY(0);zoomText.setText(zoomPercent+"%");}

    private void scheduleAutosave(){root.removeCallbacks(autosaveRunnable);root.postDelayed(autosaveRunnable,1200);}
    private final Runnable autosaveRunnable=()->{
        captureCurrentDocument();
        DocumentModel d=currentDoc();
        if(d==null||d.kind!=DocumentModel.Kind.DOCUMENT||!d.dirty)return;
        try{
            File dir=new File(getFilesDir(),"recovery");if(!dir.exists())dir.mkdirs();
            String payload=d.title+"\n---WORDROID-RECOVERY---\n"+d.content;
            try(FileOutputStream out=new FileOutputStream(new File(dir,"doc-"+d.id+".wrrec"))){out.write(payload.getBytes("UTF-8"));}
        }catch(Exception ignored){}
    };

    private void offerRecoveredDocuments(){
        File dir=new File(getFilesDir(),"recovery");
        File[] files=dir.listFiles((d,n)->n.endsWith(".wrrec"));
        if(files==null||files.length==0)return;
        new AlertDialog.Builder(this).setTitle("Recovered documents")
                .setMessage(files.length+" autosaved document"+(files.length==1?" was":"s were")+" found from an earlier session.")
                .setPositiveButton("Recover",(dialog,which)->{
                    for(File f:files){
                        try{
                            byte[] bytes=java.nio.file.Files.readAllBytes(f.toPath());
                            String payload=new String(bytes,"UTF-8");
                            String split="\n---WORDROID-RECOVERY---\n";int at=payload.indexOf(split);
                            String title=at>=0?payload.substring(0,at):"Recovered document";
                            String body=at>=0?payload.substring(at+split.length()):payload;
                            DocumentModel d=new DocumentModel(nextDocId++,title+" (Recovered)");d.content.append(body);d.dirty=true;docs.add(d);
                        }catch(Exception ignored){}
                        f.delete();
                    }
                    rebuildTabs();if(docs.size()>1)selectDoc(docs.size()-1);
                })
                .setNegativeButton("Discard",(dialog,which)->{for(File f:files)f.delete();}).show();
    }

    private void deleteRecovery(DocumentModel d){if(d==null)return;File f=new File(new File(getFilesDir(),"recovery"),"doc-"+d.id+".wrrec");if(f.exists())f.delete();}

    private void showPageColorsDeprecated() {}

    private int[] selectionRange(){int s=Math.max(0,editor.getSelectionStart()),e=Math.max(0,editor.getSelectionEnd());return s<=e?new int[]{s,e}:new int[]{e,s};}
    private int[] paragraphRange(){Editable e=editor.getText();int s=Math.max(0,editor.getSelectionStart()),en=Math.max(0,editor.getSelectionEnd());while(s>0&&e.charAt(s-1)!='\n')s--;while(en<e.length()&&e.charAt(en)!='\n')en++;return new int[]{s,en};}
    private boolean ensureDocument(){DocumentModel d=currentDoc();if(d==null||d.kind!=DocumentModel.Kind.DOCUMENT){toast("This command is available in document tabs");return false;}return true;}

    private boolean handleEditorKey(int keyCode,KeyEvent e){
        if(e.getAction()!=KeyEvent.ACTION_DOWN)return false;
        if(e.isCtrlPressed()){
            if(keyCode==KeyEvent.KEYCODE_F){showFindReplace(false);return true;}
            if(keyCode==KeyEvent.KEYCODE_H){showFindReplace(true);return true;}
            if(keyCode==KeyEvent.KEYCODE_B){applyStyle(Typeface.BOLD);return true;}
            if(keyCode==KeyEvent.KEYCODE_I){applyStyle(Typeface.ITALIC);return true;}
            if(keyCode==KeyEvent.KEYCODE_U){applyUnderline();return true;}
            if(keyCode==KeyEvent.KEYCODE_S){saveCurrent();return true;}
            if(keyCode==KeyEvent.KEYCODE_Z){if(e.isShiftPressed())redoLike();else undoLike();return true;}
            if(keyCode==KeyEvent.KEYCODE_Y){redoLike();return true;}
            if(keyCode==KeyEvent.KEYCODE_T){newDocument();return true;}
            if(keyCode==KeyEvent.KEYCODE_W){closeDocument(activeIndex);return true;}
            if(keyCode==KeyEvent.KEYCODE_TAB){int n=e.isShiftPressed()?-1:1;selectDoc((activeIndex+n+docs.size())%docs.size());return true;}
        }
        return false;
    }

    private void undoLike(){
        DocumentModel d=currentDoc();
        if(d==null||d.kind!=DocumentModel.Kind.DOCUMENT||d.undoStack.isEmpty()){toast("Nothing to undo");return;}
        SpannableStringBuilder current=new SpannableStringBuilder(editor.getText());
        SpannableStringBuilder previous=d.undoStack.remove(d.undoStack.size()-1);
        d.redoStack.add(current);
        applyingHistory=true;
        editor.setText(new SpannableStringBuilder(previous));
        editor.setSelection(editor.length());
        applyingHistory=false;
        d.content=new SpannableStringBuilder(editor.getText());
        d.dirty=true;
        rebuildTabs();refreshStatus();scheduleAutosave();
    }

    private void redoLike(){
        DocumentModel d=currentDoc();
        if(d==null||d.kind!=DocumentModel.Kind.DOCUMENT||d.redoStack.isEmpty()){toast("Nothing to redo");return;}
        SpannableStringBuilder current=new SpannableStringBuilder(editor.getText());
        SpannableStringBuilder next=d.redoStack.remove(d.redoStack.size()-1);
        d.undoStack.add(current);
        applyingHistory=true;
        editor.setText(new SpannableStringBuilder(next));
        editor.setSelection(editor.length());
        applyingHistory=false;
        d.content=new SpannableStringBuilder(editor.getText());
        d.dirty=true;
        rebuildTabs();refreshStatus();scheduleAutosave();
    }

    private String queryName(Uri uri){String result="Document";android.database.Cursor c=null;try{c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null);if(c!=null&&c.moveToFirst()){int idx=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(idx>=0)result=c.getString(idx);}}catch(Exception ignored){}finally{if(c!=null)c.close();}return result==null?"Document":result;}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();if(requestCode==REQ_OPEN)openUri(uri,data.getType());else if(requestCode==REQ_SAVE_DOCX)saveDocx(uri);else if(requestCode==REQ_SAVE_PDF)exportPdf(uri);else if(requestCode==REQ_IMAGE)insertPickedImage(uri);else if(requestCode==REQ_PDF_ANNOTATED)exportAnnotatedPdf(uri);}

    @Override protected void onPause(){super.onPause();captureCurrentDocument();autosaveRunnable.run();}
    @Override protected void onDestroy(){closePdf();ioExecutor.shutdownNow();super.onDestroy();}

    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private LinearLayout.LayoutParams lpMatch(int h){return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,h);}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private TextView label(String text,float sp,boolean bold){TextView v=new TextView(this);v.setText(text);v.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);v.setTextColor(Color.rgb(38,42,48));v.setGravity(Gravity.CENTER_VERTICAL);v.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);return v;}
    private Button button(String text,float sp){Button b=new Button(this);b.setText(text);b.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);b.setTextColor(Color.rgb(45,50,58));b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setPadding(dp(10),0,dp(10),0);b.setBackground(rounded(Color.WHITE,Color.rgb(218,222,228),8,1));return b;}
    private View topAction(String text,View.OnClickListener l){Button b=button(text,11);b.setOnClickListener(l);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(34));p.setMargins(dp(3),0,dp(3),0);b.setLayoutParams(p);return b;}
    private TextView ribbonTab(String text){TextView t=label(text,11.5f,false);t.setGravity(Gravity.CENTER);return t;}
    private GradientDrawable rounded(int fill,int stroke,float radius,int strokeDp){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp((int)radius));if(strokeDp>0)g.setStroke(dp(strokeDp),stroke);return g;}

    static class HeadingSpan extends CharacterStyle {
        final int level; HeadingSpan(int level){this.level=level;} @Override public void updateDrawState(TextPaint tp){}
    }

    static class CustomTypefaceSpan extends MetricAffectingSpan {
        private final Typeface typeface; CustomTypefaceSpan(Typeface tf){typeface=tf;}
        @Override public void updateDrawState(TextPaint ds){apply(ds);}
        @Override public void updateMeasureState(TextPaint paint){apply(paint);}
        private void apply(TextPaint p){Typeface old=p.getTypeface();int oldStyle=old==null?0:old.getStyle();int fake=oldStyle&~typeface.getStyle();if((fake&Typeface.BOLD)!=0)p.setFakeBoldText(true);if((fake&Typeface.ITALIC)!=0)p.setTextSkewX(-0.25f);p.setTypeface(typeface);}
    }
}
