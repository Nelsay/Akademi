package com.nelsay.wordroid;

import android.net.Uri;
import android.text.SpannableStringBuilder;

import java.util.ArrayList;

final class DocumentModel {
    enum Kind { DOCUMENT, PDF }

    final long id;
    String title;
    Kind kind;
    SpannableStringBuilder content;
    Uri uri;
    boolean dirty;
    int selectionStart;
    int selectionEnd;
    float leftMarginDp = 72f;
    float rightMarginDp = 72f;
    String pdfNote = "";
    final ArrayList<SpannableStringBuilder> undoStack = new ArrayList<>();
    final ArrayList<SpannableStringBuilder> redoStack = new ArrayList<>();

    DocumentModel(long id, String title) {
        this.id = id;
        this.title = title;
        this.kind = Kind.DOCUMENT;
        this.content = new SpannableStringBuilder();
    }

    static DocumentModel pdf(long id, String title, Uri uri) {
        DocumentModel d = new DocumentModel(id, title);
        d.kind = Kind.PDF;
        d.uri = uri;
        return d;
    }
}
