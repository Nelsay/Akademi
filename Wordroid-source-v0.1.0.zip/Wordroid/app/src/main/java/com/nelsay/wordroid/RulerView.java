package com.nelsay.wordroid;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class RulerView extends View {
    public interface Listener { void onMarginsChanged(float leftDp, float rightDp); }
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float leftDp = 72f;
    private float rightDp = 72f;
    private int dragging = 0;
    private Listener listener;

    public RulerView(Context context) { super(context); init(); }
    public RulerView(Context context, AttributeSet attrs) { super(context, attrs); init(); }

    private void init() {
        setBackgroundColor(Color.WHITE);
        setMinimumHeight(dp(34));
    }

    public void setListener(Listener listener) { this.listener = listener; }
    public void setMarginsDp(float left, float right) { leftDp = left; rightDp = right; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth(), h = getHeight();
        float density = getResources().getDisplayMetrics().density;
        paint.setColor(Color.rgb(218, 222, 228));
        paint.setStrokeWidth(dpF(1));
        c.drawLine(0, h - dpF(1), w, h - dpF(1), paint);
        paint.setTextSize(dpF(9));
        paint.setColor(Color.rgb(105, 112, 122));
        float step = dpF(24);
        int idx = 0;
        for (float x = 0; x <= w; x += step) {
            float len = (idx % 4 == 0) ? dpF(10) : (idx % 2 == 0 ? dpF(7) : dpF(4));
            c.drawLine(x, h - len, x, h, paint);
            if (idx % 4 == 0 && idx > 0) c.drawText(String.valueOf(idx / 4), x + dpF(2), dpF(11), paint);
            idx++;
        }
        float lx = Math.min(w - dpF(30), leftDp * density);
        float rx = Math.max(dpF(30), w - rightDp * density);
        paint.setColor(Color.rgb(23, 105, 232));
        drawHandle(c, lx, h, false);
        drawHandle(c, rx, h, true);
        paint.setColor(0x142069E8);
        c.drawRect(0, 0, lx, h, paint);
        c.drawRect(rx, 0, w, h, paint);
    }

    private void drawHandle(Canvas c, float x, int h, boolean inverted) {
        Path p = new Path();
        float s = dpF(7);
        if (!inverted) {
            p.moveTo(x, h - dpF(3)); p.lineTo(x - s, h - dpF(13)); p.lineTo(x + s, h - dpF(13));
        } else {
            p.moveTo(x, h - dpF(13)); p.lineTo(x - s, h - dpF(3)); p.lineTo(x + s, h - dpF(3));
        }
        p.close(); c.drawPath(p, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float density = getResources().getDisplayMetrics().density;
        float lx = leftDp * density;
        float rx = getWidth() - rightDp * density;
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            if (Math.abs(e.getX() - lx) < dpF(28)) dragging = 1;
            else if (Math.abs(e.getX() - rx) < dpF(28)) dragging = 2;
            else return false;
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_MOVE && dragging != 0) {
            if (dragging == 1) leftDp = Math.max(24f, Math.min(180f, e.getX() / density));
            else rightDp = Math.max(24f, Math.min(180f, (getWidth() - e.getX()) / density));
            if (leftDp + rightDp > getWidth() / density - 120f) {
                if (dragging == 1) leftDp -= 2f; else rightDp -= 2f;
            }
            invalidate();
            if (listener != null) listener.onMarginsChanged(leftDp, rightDp);
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { dragging = 0; return true; }
        return true;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private float dpF(float v) { return v * getResources().getDisplayMetrics().density; }
}
